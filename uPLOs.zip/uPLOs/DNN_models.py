# -*- coding: utf-8 -*-
"""
Created on Tue Aug 17 21:51:35 2021

@author: User
"""
import os
import batch_loss
import tensorflow_probability as tfp
import tensorflow_addons as tfa
os.environ["CUDA_VISIBLE_DEVICES"] = "-1" #Disable GPU: -1

import tensorflow as tf
import numpy as np

dt_type=tf.float64

def plain_modular_model(cfd_type=None,inputs=None,width={'ps':{'Bottom_Size':None,'No_Gens':None,'Growth_Type':None,'Growth_Rate':None},'ko':{},'Bu':{}},depth={'ps':None,'ko':None,'Bu':None},\
                        config={'ps':None,'ko':None,'Bu':None,'qs':None},kernel={'Init':None,'Regu':None},hlayer_activation_func={'ps':None,'Bu':None,'ko':None,'qr':None,'sl':None},olayer_activation_func=None, batch_norm={}, \
                        residual_module_par={'NStacks':3,'Kernel_Init':'glorot_normal','Batch_Norm':{},'Activation_Func':tf.nn.relu},poly_coeff_Bu=None,grid_dim=None,train_stats=None):
    # Data Arrangement:
    # Type 0: Three outputs--pressure, gas saturation and condensate saturation
    # Type 1: Seven outputs--pressure, gas saturation, condensate saturation, gas FVF, condensate FVF, gas viscosity and condensate viscosity
    # Type 2: Three outputs--pressure, (gas saturation/(gas FVF*gas viscosity)), (condensate saturation/(condensate FVF*condensate viscosity))

    def iden_fun(x):
        return x
    # Quantity of Interest (QoI)-pressure ANN
    residual_module_par_ps=residual_module_par
    residual_module_par_ps['Network_Type']=config['ps'][0].upper()
    ps=dnn_sub_block(inputs=inputs,width=width['ps'],depth=depth['ps'][0],activation_func=hlayer_activation_func['ps'],kernel_init=kernel['Init'],kernel_regu=None,name='pre_sat_group',residual_module_par=residual_module_par_ps)

    # Intermediate split--pressure and saturation
    # Pressure
    residual_module_par_ps['Network_Type']=config['ps'][1].upper()

    p_hlayer=dnn_sub_block(inputs=ps,width=width['ps'],depth=depth['ps'][1],activation_func=hlayer_activation_func['ps'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['p'],name='pre_split',residual_module_par=residual_module_par_ps,layer_LSTM=depth['LSTM'],layer_CNN=depth['CNN'])
    
    # Gas Saturation
    residual_module_par_ps['Network_Type']=config['ps'][2].upper()
    sg_hlayer=dnn_sub_block(inputs=ps,width=width['ps'],depth=depth['ps'][2],activation_func=hlayer_activation_func['ps'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['sg'],name='gsat_split',residual_module_par=residual_module_par_ps)
    
    # Add slack layer variable for optimization of gas rate
    if cfd_type['Type'].upper()=='PINN':
        residual_module_par_ps['Network_Type']=config['qs'][0].upper()
        qg_hlayer=dnn_sub_block(inputs=ps,width=width['qs'],depth=depth['qs'][0],activation_func=hlayer_activation_func['qr'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['qr'],name='grate_split',residual_module_par=residual_module_par_ps)
        
        residual_module_par_ps['Network_Type']=config['qs'][1].upper()
        s1_hlayer=dnn_sub_block(inputs=ps,width=width['qs'],depth=depth['qs'][1],activation_func=hlayer_activation_func['sl'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['sl'],name='slack1_split',residual_module_par=residual_module_par_ps)

    if cfd_type['Fluid_Type']=='gas-cond':
        residual_module_par_ps['Network_Type']=config['ps'][3].upper()
        so_hlayer=dnn_sub_block(inputs=ps,width=width['ps'],depth=depth['ps'][3],activation_func=hlayer_activation_func['ps'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['so'],name='osat_split',residual_module_par=residual_module_par_ps)
 
    if config['ko'][0] in ['plain','resn',None]:
        # Constitutive property (permeability) ANN
        residual_module_par_ko=residual_module_par
        residual_module_par_ko['Network_Type']=config['ko'][0].upper()
        if cfd_type['Aux_Layer']['ko']:
            phik=dnn_sub_block(inputs=inputs,width=width['ko'],depth=depth['ko'],activation_func=hlayer_activation_func['ko'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['phik'],name='poro-perm',residual_module_par=residual_module_par_ko)
            phi_out=tf.keras.layers.Dense(1, activation=olayer_activation_func['phi'], kernel_initializer=kernel['Init'], name='porosity')(phik)
            k_out=tf.keras.layers.Dense(1, activation=olayer_activation_func['k'], kernel_initializer=kernel['Init'], name='permeability')(phik)
    
    # Check if output of p,s is a Conv2D
    if config['ps'][0]!='cnn2d' or config['ps'][1]!='cnn2d':
        p_int=tf.keras.layers.Dense(1, activation=olayer_activation_func['p'], kernel_initializer=kernel['Init'], name='pressure')(p_hlayer)
    else:
        p_int=p_hlayer

    # Pressure output could be transformed
    if olayer_activation_func['p']!='linear':  
        def p_transform(x={'Value':None,'Min':None,'Max':None},y={'Min':None,'Max':None}):
            xmin=tf.convert_to_tensor(x['Min'],dtype=x['Value'].dtype)
            xmax=tf.convert_to_tensor(x['Max'],dtype=x['Value'].dtype)
            ymin=tf.convert_to_tensor(y['Min'],dtype=x['Value'].dtype)
            ymax=tf.convert_to_tensor(y['Max'],dtype=x['Value'].dtype)

            return ymin+((x['Value']-xmin)/(xmax-xmin))*(ymax-ymin)
        if olayer_activation_func['p'].__name__[0:3]=='elu':
            xmin=olayer_activation_func['p'].alpha
        else:
            xmin=0.

        p_int=tf.keras.layers.Lambda(lambda x: p_transform(x={'Value':x[0],'Min':x[1],'Max':x[2]},y={'Min':x[3],'Max':x[4]}),name='p_transform')([p_int,-xmin,1.,cfd_type['Min_BHP'],cfd_type['Pi']])    


        #p_int1=tf.keras.layers.Dense(1, activation=olayer_activation_func['p'], kernel_initializer=kernel['Init'], name='pressure_1')(p_hlayer)
        #p_int2=tf.keras.layers.Dense(1, activation=olayer_activation_func['p'], kernel_initializer=kernel['Init'], name='pressure_2')(p_hlayer)
        #p_int=tf.keras.layers.Lambda(lambda x: x[0]*x[1],name='layer_p1_p2')([p_int1,p_int2])    
    
    # Add a batch normalization after the pressure node with output that connects to the fluid property DNN model  
    if batch_norm['Use_Batch_Norm_After_Pressure']:
        p_int=tf.keras.layers.BatchNormalization(axis=1, momentum=batch_norm['Momentum'], epsilon=1e-6, name='batch_norm_pressure')(p_int)
        
    if batch_norm['Pre_Rect']['Use_Pre_Rect']:
        rect_func=batch_norm['Pre_Rect']['Act_Func']
        p_int=tf.keras.layers.Lambda(lambda x: rect_func(x),name='pre_rect_layer')(p_int)
        
    
    # Create a Lambda to transform the pressure output
    p=tf.keras.layers.Lambda(lambda x: iden_fun(x),name='identity_layer_pressure')(p_int)

    # Add the Pressure dependent layer for Formation Volume Factor (FVF) and viscosity
    if cfd_type['Aux_Layer']['Bu']:
        if config['ps'][0]=='cnn2d':
            # Flatten the 2D CNN (auto encoder) 
            cnn2d_shape=p_hlayer.shape
            p_int=tf.keras.layers.Flatten()(p_hlayer)

            # Expand the inner dimension -- the suit the custom layer
            p_int=tf.keras.layers.Reshape((*tuple(p_int.shape[1:]),1), name='Reshaped_InvBu_layer_CNV2D')(p_int)
            p_int=tf.keras.layers.Lambda(lambda x: tf.transpose(x,perm=[1,0,2]),name='Transpose_InvBu_layer_CNV2D')(p_int)

        if config['Bu'][0] in ['plain','res','cnn2d']:
            residual_module_par_bu=residual_module_par
            residual_module_par_bu['Network_Type']=config['Bu'][0].upper()
            # Constitutive behaviour (viscosity-FVF related to pseudopressure) ANN
            invBu=dnn_sub_block(inputs=p_int,width=width['Bu'],depth=depth['Bu'][0],activation_func=hlayer_activation_func['Bu'],kernel_init=kernel['Init'],kernel_regu=None,name='invB_invu_group',residual_module_par=residual_module_par_bu)
            # Intermediate splits--(1/Bg),(1/Bo),(1/ug),(1/uo)
            # (1/Bg)
            invBg_hlayer=dnn_sub_block(inputs=invBu,width=width['Bu'],depth=depth['Bu'][1],activation_func=hlayer_activation_func['Bu'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['Bu'],name='invBg_split',residual_module_par=residual_module_par_bu)
            
            # (1/ug)
            invug_hlayer=dnn_sub_block(inputs=invBu,width=width['Bu'],depth=depth['Bu'][3],activation_func=hlayer_activation_func['Bu'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['Bu'],name='invug_split',residual_module_par=residual_module_par_bu)
        
            invBg=tf.keras.layers.Dense(1, activation=olayer_activation_func['invB'], kernel_initializer=kernel['Init'], name='invBg')(invBg_hlayer)
            invug=tf.keras.layers.Dense(1, activation=olayer_activation_func['invu'], kernel_initializer=kernel['Init'], name='invug')(invug_hlayer)
            if cfd_type['Fluid_Type']=='gas-cond':
                # (1/Bo)
                invBo_hlayer=dnn_sub_block(inputs=invBu,width=width['Bu'],depth=depth['Bu'][2],activation_func=hlayer_activation_func['Bu'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['Bu'],name='invBo_split',residual_module_par=residual_module_par_bu)
                # (1/uo)
                invuo_hlayer=dnn_sub_block(inputs=invBu,width=width['Bu'],depth=depth['Bu'][4],activation_func=hlayer_activation_func['Bu'],kernel_init=kernel['Init'],kernel_regu=kernel['Regu']['Bu'],name='invuo_split',residual_module_par=residual_module_par_bu)
        
                invBo=tf.keras.layers.Dense(1, activation=olayer_activation_func['invB'], kernel_initializer=kernel['Init'], name='invBo')(invBo_hlayer)
                invuo=tf.keras.layers.Dense(1, activation=olayer_activation_func['invu'], kernel_initializer=kernel['Init'], name='invuo')(invuo_hlayer)
        else:  # has numerical value
            # Use an approximating function--a polynomial is used in this case
            order_Bg=int(config['Bu'][1][-1])
            order_ug=int(config['Bu'][3][-1])
            invBg=viscosity_FVF_inverse(pweights=poly_coeff_Bu['InvBg'],cname='invBg_polynomial')(p_int)
            invug=viscosity_FVF_inverse(pweights=poly_coeff_Bu['Invug'],cname='invug_polynomial')(p_int)
           
            if cfd_type['Fluid_Type']=='gas_cond':
                order_Bo=int(config['Bu'][2][-1])
                order_uo=int(config['Bu'][4][-1])
                invBo=viscosity_FVF_inverse(pweights=poly_coeff_Bu['InvBo'],cname='invBo_polynomial')(p_int)
                invuo=viscosity_FVF_inverse(pweights=poly_coeff_Bu['Invuo'],cname='invuo_polynomial')(p_int)

        if config['ps'][0]=='cnn2d':  #Reshapes the FVF and viscosity if it is 2D layer
            # Reshape the FVF and viscosity if pressure layer is a CNN2D
            invBg=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_InvBg_layer_CNV2D')(invBg)
            invug=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_Invug_layer_CNV2D')(invug)
            
            # Condensates/Oils
            if cfd_type['Fluid_Type']=='gas-cond':
                invBo=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_InvBo_layer_CNV2D')(invBo)
                invuo=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_Invuo_layer_CNV2D')(invuo)
            
            # Add the reshaped derivatives if using a polynomial function
            '''
            if not config['Bu'][0] in ['plain','res','cnn2d']:
                dinvBg=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_dInvBg_layer_CNV2D')(dinvBg)
                dinvug=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_dInvug_layer_CNV2D')(dinvug)
                if cfd_type['Fluid_Type']=='gas-cond':
                    dinvBo=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_dInvBo_layer_CNV2D')(dinvBo)
                    dinvuo=tf.keras.layers.Reshape(cnn2d_shape[1:], name='Reshaped_dInvuo_layer_CNV2D')(dinvuo)'''
            
    # Gas Saturation
    if config['ps'][2]!='cnn2d':
        sg_int=tf.keras.layers.Dense(1, activation=olayer_activation_func['s'], kernel_initializer=kernel['Init'], name='gsaturation')(sg_hlayer)
        sg=tf.keras.layers.Lambda(lambda x: iden_fun(x),name='identity_layer_gsaturation')(sg_int)
        if cfd_type['Type'].upper()=='PINN':
            qg_int=tf.keras.layers.Dense(1, activation=olayer_activation_func['qr'], kernel_initializer=kernel['Init'], name='grate')(qg_hlayer)
            s1_int=tf.keras.layers.Dense(1, activation=olayer_activation_func['sl'], kernel_initializer=kernel['Init'], name='slack1')(s1_hlayer)
            qg=tf.keras.layers.Lambda(lambda x: iden_fun(x),name='identity_layer_grate')(qg_int)
            s1=tf.keras.layers.Lambda(lambda x: iden_fun(x),name='identity_layer_slack1')(s1_int)
    else:
        sg=sg_hlayer
        qg=qg_hlayer
        s1=s1_hlayer
   
    # Condensate/Oil Saturation
    if cfd_type['Fluid_Type']=='gas-cond':
        if config['ps'][3]!='cnn2d':
            so_int=tf.keras.layers.Dense(1, activation=olayer_activation_func['s'], kernel_initializer=kernel['Init'], name='osaturation')(so_hlayer)
            so=tf.keras.layers.Lambda(lambda x: iden_fun(x),name='identity_layer_osaturation')(so_int)
        else:
            so=so_hlayer
    #breakpoint()
    
    '''
    # Compute Pressure and Rate
    def model_wrapper (cfd_type,train_stats): 
        model_wrapper.cfd_type=cfd_type
        model_wrapper.ts=train_stats
        return model_wrapper
    
    model=model_wrapper(cfd_type,train_stats)
    # Create the Connection Index Tensor for the wells
    grid_zero_idx=np.zeros(model.cfd_type['Dimension']['Reshape'])
    for idx in model.cfd_type['Conn_Idx']:
        grid_zero_idx[idx]=1.
    grid_zero_idx=tf.convert_to_tensor(grid_zero_idx,dtype=inputs.dtype)
    
    if config['ps'][0]=='cnn2d' or config['ps'][1]=='cnn2d':
        q_well_idx=tf.keras.layers.Lambda(lambda x:x[0]*x[1],name='q_well_index')([grid_zero_idx,inputs[...,:1]])
    
    def compute_rate(model,q_well_idx,rw,dx_ij,dy_ij,dz_ij,kx_ij,ky_ij,kz_ij,invBgug_n1_ij,p_n1_ij):
        rw=0.1905/2
        C=tf.constant(0.001127, dtype=dt_type, shape=(), name='const1')
        D=tf.constant(5.6145833334, dtype=dt_type, shape=(), name='const2')
        rw=tf.constant(rw, dtype=dt_type, shape=(), name='rw')
        ro=0.28*(tf.math.pow((((tf.math.pow(ky_ij/kx_ij,0.5))*(tf.math.pow(dx_ij,2)))+((tf.math.pow(kx_ij/ky_ij,0.5))*(tf.math.pow(dy_ij,2)))),0.5))/(tf.math.pow((ky_ij/kx_ij),0.25)+tf.math.pow((kx_ij/ky_ij),0.25))
        qmax_n1_ij_min_BHP=q_well_idx*((2*(22/7)*kx_ij*dz_ij*C)*(1/(tf.math.log(ro/rw)))*(invBgug_n1_ij)*(p_n1_ij-model.cfd_type['Min_BHP']))
        tstep=model.cfd_type['Timestep']*(1-((1-model.cfd_type['Timestep_Fac'])*tf.cast(tf.math.reduce_mean(kx_ij)>model.cfd_type['K_Timestep'],model.dtype)))
        tstep_norm=normalize_diff(model,tstep,stat_idx=3,compute=True)
        t0_norm=normalize(model,0.,stat_idx=3,compute=True)
        qmax_n1_ij_min_BHP=q_well_idx*((2*(22/7)*kx_ij*dz_ij*C)*(1/(tf.math.log(ro/rw)))*(invBgug_n1_ij)*(p_n1_ij-model.cfd_type['Min_BHP']))
        q_n1_ij=tf.math.minimum(q_well_idx*model.cfd_type['Init_Grate'],qmax_n1_ij_min_BHP)
    '''


    # List outputs  
    if cfd_type['Data_Arr']==0:
        outputs=[p,sg]
    elif cfd_type['Data_Arr']==1:
        outputs=[p,sg]
        if cfd_type['Aux_Layer']['Bu']:
            outputs=outputs+[invBg,invug]
    else:
        # Create a Lambda layer to perform operation (s/Bu) for Arrangement Type 2
        sbu_g=tf.keras.layers.Lambda(lambda x: (x[0]*x[1]*x[2]),name='sbu_gas_layer')([sg_int,invBg,invug])
        outputs=[p,sbu_g]
        
    # Append to the output list if condensate is trained along side other labels 
    if cfd_type['Fluid_Type']=='gas-cond':
        if cfd_type['Data_Arr']==0:
            outputs.append(so)
        elif cfd_type['Data_Arr']==1:
            outputs.insert(2,so)
            if cfd_type['Aux_Layer']['Bu']:
                outputs.insert(2,so)
                outputs.insert(4,invBo)
                outputs.insert(6,invuo)
        elif cfd_type['Data_Arr']==2:
            sbu_o=tf.keras.layers.Lambda(lambda x: (x[0]*x[1]*x[2]),name='sbu_oil_layer')([so_int,invBo,invuo])
            outputs.append(sbu_o)
    
    # Append rates and slack variables
    if cfd_type['Type'].upper()=='PINN':
         outputs=outputs+[qg,s1]
    
    return outputs

def residual_module(inputs=None, width=None, depth=None, kernel_init=None,kernel_regu=None,batch_norm={'Use_Batch_Norm':False,'Before_Activation':True,'Momentum':0.99}, activation_func=None, dropout={'Add':False,'Dropout_Idx_Stack':0,'Rate':0.05},block_name=None ): 
    # The RELU activation function which is computationally cost effective is usually used due to a resulting deeper network configuration
    if depth<=0:
        outputs=inputs
    else:
        for i in range(0,depth):
            if i==0:
                int_outputs = tf.keras.layers.Dense(width, activation=None, kernel_initializer=kernel_init, kernel_regularizer=kernel_regu, name=block_name+'_sub_hlayer_'+str(i+1))(inputs)
            else:
                int_outputs = tf.keras.layers.Dense(width, activation=None, kernel_initializer=kernel_init, kernel_regularizer=kernel_regu, name=block_name+'_sub_hlayer_'+str(i+1))(int_outputs)
            
            # Apply Batch Normalization, usually before activation -- although some ML enthusisists show BN after activation gives a better match
            if i<(depth-1):
                if batch_norm['Use_Batch_Norm']:
                    if batch_norm['Before_Activation']:
                        int_outputs = tf.keras.layers.BatchNormalization(axis=1, momentum=batch_norm['Momentum'], epsilon=1e-6, name=block_name+'_batch_norm_sub_hlayer_'+str(i+1))(int_outputs) 
                        int_outputs = tf.keras.layers.Activation(activation_func, name=block_name+'_activation_sub_hlayer_'+str(i+1))(int_outputs)
                    else:
                        int_outputs = tf.keras.layers.Activation(activation_func, name=block_name+'_activation_sub_hlayer_'+str(i+1))(int_outputs)
                        int_outputs = tf.keras.layers.BatchNormalization(axis=1, momentum=batch_norm['Momentum'], epsilon=1e-6, name=block_name+'_batch_norm_sub_hlayer_'+str(i+1))(int_outputs) 
                else:
                    int_outputs = tf.keras.layers.Activation(activation_func, name=block_name+'_activation_sub_hlayer_'+str(i+1))(int_outputs)
            else:   
                if batch_norm['Use_Batch_Norm']:
                    if batch_norm['Before_Activation']:
                        int_outputs = tf.keras.layers.BatchNormalization(axis=1, momentum=batch_norm['Momentum'], epsilon=1e-6, name=block_name+'_batch_norm_sub_hlayer_'+str(i+1))(int_outputs) 
                    else:
                        int_outputs = tf.keras.layers.Activation(activation_func, name=block_name+'_activation_sub_hlayer_'+str(i+1))(int_outputs)
                else:
                    # If Batch Normalization is not used, the nth layer output, is the dense layer output
                    continue

        # Check the Input-Output dimensions. If input dimension = output dimension -- Identity block, else Dense block
        if inputs.shape[-1]!=int_outputs.shape[-1]:
            # Add a dense layer
            proj_inputs = tf.keras.layers.Dense(int_outputs.shape[-1], activation=None, kernel_initializer=kernel_init, kernel_regularizer=kernel_regu, name=block_name+'_proj_inputs')(inputs)
            if batch_norm['Use_Batch_Norm']:
                if batch_norm['Before_Activation']: 
                    # Add a Batch Normalization layer
                    proj_inputs=tf.keras.layers.BatchNormalization(axis=-1, momentum=batch_norm['Momentum'], epsilon=1e-6, name=block_name+'_batch_norm_proj_inputs')(proj_inputs) 
                else:
                    proj_inputs = tf.keras.layers.Activation(activation_func, name=block_name+'_activation_proj_inputs')(proj_inputs)
        else:
            proj_inputs = inputs
        
        outputs=tf.keras.layers.add([int_outputs,proj_inputs])
        # Output Layer
        if batch_norm['Use_Batch_Norm']:
            if batch_norm['Before_Activation']:
                outputs=tf.keras.layers.Activation(activation_func, name=block_name+'_output_layer_activation')(outputs)
            else: 
                outputs=tf.keras.layers.BatchNormalization(axis=1, momentum=batch_norm['Momentum'], epsilon=1e-6, name=block_name+'_output_layer_batch_norm')(outputs) 
        else:
            outputs=tf.keras.layers.Activation(activation_func, name=block_name+'_output_layer_activation')(outputs)
            
        # Apply dropout regularization -- this is usually after the activation
        if dropout['Add'] in [True,1] and dropout['Dropout_Idx_Stack']==1:
            # Add a dropout layer
            outputs=tf.keras.layers.Dropout(dropout['Rate'], noise_shape=None, seed=None)(outputs)
  
    return outputs

def encoder_decoder(inputs=None, depth=None,width=None,residual_module_par={},name=None,nstack_idx=None):
    filter_list_enc=network_width_list(depth=depth,width=width['Bottom_Size'],ngens=depth,growth_rate=width['Growth_Rate'],growth_type='smooth',network_type='plain')              # Use of network_width_list function--ngens is equal to depth; growth type is set to smooth; network type as plain

    if residual_module_par['Skip_Connections']['Add'][nstack_idx-1]:
        skip_conn={}
        
    def pad_stack_skip_conn(skip_conn=None, conv2d_hlayer=None, name=None, depth_idx=None,residual_module_par=None):
        if np.prod(skip_conn.shape[1:2])!=np.prod(conv2d_hlayer.shape[1:2]):
            # Pad the layer with offset starting left
            layer_diff=tf.math.abs(skip_conn.shape[1]-conv2d_hlayer.shape[1])
            pad_no=int(layer_diff/2)
            if layer_diff%2==0:  # Even
                skip_pad=tf.keras.layers.ZeroPadding2D(padding=((pad_no,pad_no),(pad_no,pad_no)), data_format=None, name=name+'_skipad_layer_'+str(depth_idx))(skip_conn)
            else:
                skip_pad=tf.keras.layers.ZeroPadding2D(padding=((pad_no+1,pad_no),(pad_no+1,pad_no)), data_format=None, name=name+'_skipad_layer_'+str(depth_idx))(skip_conn)   
        else:
            skip_pad=skip_conn
        if skip_conn.shape[-1]!=conv2d_hlayer.shape[-1]:
            # Pad the channels with a 1x1 convolution filter
            skip_conn_proj=tf.keras.layers.Conv2D(hlayer.shape[-1], 1, strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_DEC_skipconn_layer_'+str(depth_idx))(skip_pad)
        else:
            skip_conn_proj=skip_pad
        return skip_conn_proj
    # Encoder
    import numpy as np
    for i in range(0,depth):
       
        if i==0:
            hlayer=tf.keras.layers.Conv2D(filter_list_enc[i], residual_module_par['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None, name=name+'_CNV2D_ENC_layer_'+str(i+1))(inputs)
        else:
            if i<depth-1:
                # Pads the tensor
                hlayer=tf.keras.layers.ZeroPadding2D(padding=((1,1),(1,1)), data_format=None, name=name+'_CNV2D_ENC_pad_layer_'+str(i+1))(hlayer)
                hlayer=tf.keras.layers.Conv2D(filter_list_enc[i], residual_module_par['Kernel_Size']+2, strides=2, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_ENC_layer_'+str(i+1))(hlayer)
            else:
                hlayer=tf.keras.layers.ZeroPadding2D(padding=((1,1),(1,1)), data_format=None, name=name+'_CNV2D_ENC_pad_layer_'+str(i+1))(hlayer)
                hlayer=tf.keras.layers.Conv2D(filter_list_enc[i], residual_module_par['Kernel_Size'], strides=2, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_ENC_layer_'+str(i+1))(hlayer)
            
            # Add convolution layer
            # hlayer=tf.keras.layers.Conv2D(filter_list_enc[i], residual_module_par['Kernel_Size'], strides=1, padding='same',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_ENC_layer_'+str(i+1)+'_1')(hlayer)

        # hlayer=tf.keras.layers.Activation(residual_module_par['Activation_Func'],name=name+'_CNV2D_ENC_activation_layer_'+str(i+1))(hlayer)
        if residual_module_par['Skip_Connections']['Add'][nstack_idx-1] and residual_module_par['Skip_Connections']['Layers'][nstack_idx-1][i] not in [None,0]:
            skip_conn[i+1]=hlayer

        hlayer=tf.keras.layers.Activation(residual_module_par['Activation_Func'],name=name+'_CNV2D_ENC_activation_layer_'+str(i+1))(hlayer)
        
        if residual_module_par['Dropout']['Add'] in [True,'encoder'] and residual_module_par['Dropout']['Layer'][i]==1:
            # Add a dropout layer
            hlayer=tf.keras.layers.Dropout(residual_module_par['Dropout']['Rate'], noise_shape=None, seed=None)(hlayer)
    else:
        # Latent properties Last layer:
        #   Add MaxPooling1D
        #   Flatten
        #   Connect to Dense Layer
        #   hlayer=tf.keras.layers.MaxPool1D(pool_size=2, strides=None, padding='valid',data_format='channels_last')(hlayer)
        if residual_module_par['Dense_Latent_Layer']['Flatten'] and residual_module_par['Dense_Latent_Layer']['Depth']!=0:
            vol=hlayer.shape
            hlayer=tf.keras.layers.Flatten()(hlayer)
        if residual_module_par['Dense_Latent_Layer']['Depth']!=0:
            if not residual_module_par['Dense_Latent_Layer']['Skip_Conn']:
                width_list_latent=network_width_list(depth=residual_module_par['Dense_Latent_Layer']['Depth'],width=residual_module_par['Dense_Latent_Layer']['Width'],ngens=residual_module_par['Dense_Latent_Layer']['NStacks'][nstack_idx-1],\
                                              growth_rate=residual_module_par['Dense_Latent_Layer']['Growth_Rate'],growth_type=residual_module_par['Dense_Latent_Layer']['Growth_Type'],network_type='plain')
                #breakpoint()
                for j in range(0,residual_module_par['Dense_Latent_Layer']['Depth']):
                    if j==0:
                        latent=tf.keras.layers.Dense(width_list_latent[j], activation=residual_module_par['Dense_Latent_Layer']['Activation'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_Latent_layer_'+str(j+1))(hlayer)
                    else:
                        latent=tf.keras.layers.Dense(width_list_latent[j], activation=residual_module_par['Dense_Latent_Layer']['Activation'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_Latent_layer_'+str(j+1))(latent)
            else:
                # Create the stack list
                stack_list_latent=sparse_pad_list(depth=residual_module_par['Dense_Latent_Layer']['Depth'],nstacks=residual_module_par['Dense_Latent_Layer']['NStacks'][nstack_idx-1])
                width_list_latent=network_width_list(depth=residual_module_par['Dense_Latent_Layer']['Depth'],width=residual_module_par['Dense_Latent_Layer']['Width'],ngens=residual_module_par['Dense_Latent_Layer']['NStacks'][nstack_idx-1],\
                                              growth_rate=residual_module_par['Dense_Latent_Layer']['Growth_Rate'],growth_type=residual_module_par['Dense_Latent_Layer']['Growth_Type'],network_type='resn')
         
                for j in range(0,residual_module_par['Dense_Latent_Layer']['Depth']):
                    if j==0:
                        # Check if residual layer is to be added at index from stack_list
                        if stack_list_latent[j]!=0:
                            latent=residual_module(inputs=hlayer, width=width_list_latent[j], depth=stack_list_latent[j], kernel_init=residual_module_par['Kernel_Init'], batch_norm=residual_module_par['Batch_Norm'], activation_func=residual_module_par['Dense_Latent_Layer']['Activation'], block_name=name+'_Dense_latent_res_block_'+str(j+1))
                        else:
                            continue
                    else:
                        # Check if residual layer is to be added at index from stack_list
                        if stack_list_latent[j]!=0:
                            latent=residual_module(inputs=latent, width=width_list_latent[j], depth=stack_list_latent[j], kernel_init=residual_module_par['Kernel_Init'], batch_norm=residual_module_par['Batch_Norm'], activation_func=residual_module_par['Dense_Latent_Layer']['Activation'], block_name=name+'_Dense_latent_res_block_'+str(j+1))
                        else:
                            continue 
        else:
            latent=hlayer
    # Decoder
    for i in range(0,depth):
        import numpy as np
        if i==0:
            if residual_module_par['Dense_Latent_Layer']['Flatten'] and residual_module_par['Dense_Latent_Layer']['Depth']!=0:
                hlayer=tf.keras.layers.Dense(np.prod(vol[1:]), activation=None, kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_DEC_layer_CNV2D_'+str(depth-i))(latent)
                hlayer=tf.keras.layers.Reshape((vol[1],vol[2],vol[3]), name=name+'_Reshape_DEC_layer_CNV2D_'+str(depth-i))(hlayer)
            else:
                hlayer=latent
            #hlayer=tf.keras.layers.ZeroPadding2D(padding=((1,1),(1,1)), data_format=None, name=name+'_CNV2D_DEC_pad_layer_'+str(i+1))(latent)
            #hlayer=tf.keras.layers.Conv2DTranspose(filter_list_enc[-2-i], residual_module_par['Kernel_Size'], strides=2, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2DT_DEC_layer_'+str(depth-i-1))(hlayer)
        else:
            if i<depth-1:
                #hlayer=tf.keras.layers.ZeroPadding2D(padding=((1,1),(1,1)), data_format=None, name=name+'_CNV2D_DEC_pad_layer_'+str(i+1))(hlayer)
                hlayer=tf.keras.layers.Conv2DTranspose(int(filter_list_enc[-1-i]*residual_module_par['Decoder_Filter_Fac']), residual_module_par['Kernel_Size'], strides=2, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2DT_DEC_layer_'+str(depth-i))(hlayer)
            else:
                hlayer=tf.keras.layers.Conv2DTranspose(int(filter_list_enc[-1-i]*residual_module_par['Decoder_Filter_Fac']), residual_module_par['Kernel_Size'], strides=2, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2DT_DEC_layer_'+str(depth-i))(hlayer)
                #hlayer=tf.keras.layers.Dense(filter_list_enc[-1], activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_DEC_layer_CNV2D_'+str(i+1))(hlayer)
                #hlayer=tf.keras.layers.Conv2DTranspose(filter_list_enc[-1-i], residual_module_par['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Out_Activation_Func'],name=name+'_CNV2D_DEC_layer_'+str(i+1))(hlayer)
                # Exponential Linear Unit is used as the activation function for the output filter
                #hlayer=tf.keras.layers.Conv2DTranspose(filter_list_enc[-depth], residual_module_par['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_DEC_layer_'+str(depth-i-1))(hlayer)


        if residual_module_par['Skip_Connections']['Add'][nstack_idx-1] and residual_module_par['Skip_Connections']['Layers'][nstack_idx-1][depth-1-i] not in [None,0]:
            # nstack_idx-1 is used as there is no combined network for pressure+saturation in the CNN
            skip_conn_proj=pad_stack_skip_conn(skip_conn=skip_conn[depth-i], conv2d_hlayer=hlayer, name=name, depth_idx=depth-i,residual_module_par=residual_module_par)
            
            '''if np.prod(skip_conn[depth-i].shape[1:2])!=np.prod(hlayer.shape[1:2]):
                # Pad the layer with offset starting left
                layer_diff=tf.math.abs(skip_conn[depth-i].shape[1]-hlayer.shape[1])
                pad_no=int(layer_diff/2)
                if layer_diff%2==0:  # Even
                    skip_pad=tf.keras.layers.ZeroPadding2D(padding=((pad_no,pad_no),(pad_no,pad_no)), data_format=None, name=name+'_skipad_layer_'+str(depth-i))(skip_conn[depth-i])
                else:
                    skip_pad=tf.keras.layers.ZeroPadding2D(padding=((pad_no+1,pad_no),(pad_no+1,pad_no)), data_format=None, name=name+'_skipad_layer_'+str(depth-i))(skip_conn[depth-i])   
            else:
                skip_pad=skip_conn[depth-i]
            if skip_conn[depth-i].shape[-1]!=hlayer.shape[-1]:
                # Pad the channels with a 1x1 convolution filter
                skip_conn_proj=tf.keras.layers.Conv2D(hlayer.shape[-1], 1, strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_DEC_skipconn_layer_'+str(depth-i))(skip_pad)
            else:
                skip_conn_proj=skip_pad
            '''
            # Add the skip connection
            if i==0:
                if residual_module_par['Dense_Latent_Layer']['Depth']!=0: #and residual_module_par['Dense_Latent_Layer']['Flatten']:
                    hlayer=tf.keras.layers.Add()([skip_conn_proj,hlayer])
            else:
                hlayer=tf.keras.layers.Add()([skip_conn_proj,hlayer])

        # Add the Activation Layer
        if i==0:
            if residual_module_par['Dense_Latent_Layer']['Flatten'] and residual_module_par['Dense_Latent_Layer']['Depth']!=0:
            #if residual_module_par['Dense_Latent_Layer']['Depth']!=0:
                hlayer=tf.keras.layers.Activation(residual_module_par['Activation_Func'],name=name+'_CNV2DT_DEC_activation_layer_'+str(depth-i))(hlayer)
        else:
            hlayer=tf.keras.layers.Activation(residual_module_par['Activation_Func'],name=name+'_CNV2DT_DEC_activation_layer_'+str(depth-i))(hlayer)
        
        # Add Dense Layer
        # hlayer=tf.keras.layers.Dense(filter_list_enc[-1-i] ,activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'CNV2D_DEC_Dense_layer_'+str(i+1))(hlayer)

        # Add Dropout Layer if any
        if residual_module_par['Dropout']['Add'] in [True,'decoder'] and residual_module_par['Dropout']['Layer'][-1-i]==i:
            # Add a dropout layer
            hlayer=tf.keras.layers.Dropout(residual_module_par['Dropout']['Rate'], noise_shape=None, seed=None)(hlayer)
    else:
        #hlayer=tf.keras.layers.Conv2D(int(filter_list_enc[-depth]/2), residual_module_par['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Activation_Func'],name=name+'_CNV2D_DEC_output_layer_2')(hlayer)
            #hlayer=tf.keras.layers.Conv2D(int(filter_list_enc[-depth]/2), residual_module_par['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Activation_Func'],name=name+'_CNV2D_DEC_output_layer_1')(hlayer)
        #hlayer=tf.keras.layers.Dense(int(filter_list_enc[-depth+1]/2), activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_CNV2D_DEC_dense_output_layer_1')(hlayer)
            #hlayer=tf.keras.layers.Conv2D(1, 1, strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Out_Activation_Func'],name=name+'_CNV2D_DEC_output_layer_0')(hlayer)
        #hlayer=tf.keras.layers.Dense(width['Dense_Latent_Layer'], activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_DEC_output_layer_CNV2D_1')(hlayer)

        hlayer=tf.keras.layers.Conv2D(int((filter_list_enc[-1-i]*residual_module_par['Decoder_Filter_Fac'])/2), residual_module_par['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Activation_Func'],name=name+'_CNV2D_DEC_output_layer_0')(hlayer)
        #hlayer=tf.keras.layers.Conv2D(int((filter_list_enc[-1-i]*residual_module_par['Decoder_Filter_Fac'])/1), residual_module_par['Kernel_Size'], strides=1, padding='same',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Activation_Func'],name=name+'_CNV2D_DEC_output_layer_1')(hlayer)

        # Add Skip Connection layer from input - a kind of noise to the output
        if residual_module_par['Skip_Connections']['Add_Input'][nstack_idx-1]:
            hlayer=tf.keras.layers.Dense(int(filter_list_enc[-1-i]*residual_module_par['Decoder_Filter_Fac']), activation=None, kernel_initializer=residual_module_par['Kernel_Init'], name=name+'CNV2D_DEC_Dense_output_layer_0')(hlayer)
            #skip_input_layer=tf.keras.layers.Conv2D(filter_list_enc[-1-i], 1, strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=None,name=name+'_CNV2D_DEC_skip_input_layer_1')(inputs)
            skip_conn_proj_1=pad_stack_skip_conn(skip_conn=skip_conn[1], conv2d_hlayer=hlayer, name=name+'l1_output', depth_idx=1,residual_module_par=residual_module_par)
            
            hlayer=tf.keras.layers.Add()([skip_conn_proj_1,hlayer])
            hlayer=tf.keras.layers.Activation(residual_module_par['Activation_Func'],name=name+'CNV2D_DEC_Dense_activation_output_layer_0')(hlayer)
        else:
            for dj in range(1):
                hlayer=tf.keras.layers.Dense(int(filter_list_enc[-1-i]*residual_module_par['Decoder_Filter_Fac']), activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'CNV2D_DEC_Dense_output_layer_0'+str(dj))(hlayer)

            #hlayer=tfa.layers.NoisyDense(units=filter_list_enc[-1-i], sigma=0.5,activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'CNV2D_DEC_Dense_output_layer_0')(hlayer)
        hlayer=tf.keras.layers.Conv2D(1, 1, strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=residual_module_par['Kernel_Init'],activation=residual_module_par['Out_Activation_Func'],name=name+'_CNV2D_DEC_final_output_layer')(hlayer)

    return hlayer

def plain_network(inputs=None,depth=None,width=None,activation_func=None,kernel_init=None,kernel_regu=None,nstack_idx=None,name=None,residual_module_par={}):
    # FLatten the 2D if used 
    #if dnn_arch=='plain2D':
    #    hlayer=tf.unstack(inputs, axis=-1,name=name+'_unstack_layer_'+str(i+1))
     
    width_list=network_width_list(depth=depth,width=width['Bottom_Size'],ngens=width['No_Gens'][nstack_idx],growth_rate=width['Growth_Rate'],growth_type=width['Growth_Type'],network_type='plain')
    # breakpoint()
    for i in range(0,depth):
        if i==0:
            hlayer=tf.keras.layers.Dense(width_list[i], activation=None, kernel_initializer=kernel_init,kernel_regularizer=kernel_regu, name=name+'_hlayer_'+str(i+1))(inputs)
        else:
            if i!=depth-1:
                hlayer=tf.keras.layers.Dense(width_list[i], activation=None, kernel_initializer=kernel_init,kernel_regularizer=kernel_regu, name=name+'_hlayer_'+str(i+1))(hlayer)
            else:
                hlayer=tf.keras.layers.Dense(width_list[i], activation=None, kernel_initializer=kernel_init, kernel_regularizer=kernel_regu,name=name+'_hlayer_'+str(i+1))(hlayer)
        # Adds a Batch Normalization Layer:
        if residual_module_par['Batch_Norm']['Use_Batch_Norm']:
            if residual_module_par['Batch_Norm']['Before_Activation']:
                hlayer=tf.keras.layers.BatchNormalization(axis=1, momentum=residual_module_par['Batch_Norm']['Momentum'],epsilon=1e-6, name=name+'_batch_norm_'+str(i+1))(hlayer)
                hlayer=tf.keras.layers.Activation(activation_func,name=name+'_activation_'+str(i+1))(hlayer)
            else:
                hlayer=tf.keras.layers.Activation(activation_func,name=name+'_activation_'+str(i+1))(hlayer)
                hlayer=tf.keras.layers.BatchNormalization(axis=1, momentum=residual_module_par['Batch_Norm']['Momentum'], epsilon=1e-6, name=name+'_batch_norm_'+str(i+1))(hlayer)
        else:
            hlayer=tf.keras.layers.Activation(activation_func,name=name+'_activation_'+str(i+1))(hlayer)
        # Adds a Drop Out Layer (if active)
        if residual_module_par['Dropout']['Add'] and residual_module_par['Dropout']['Layer'][i] in [True,1] and len(residual_module_par['Dropout']['Layer'])>=depth:
            hlayer=tf.keras.layers.Dropout(residual_module_par['Dropout']['Rate'], noise_shape=None, seed=None)(hlayer)
        
    return hlayer
def dnn_sub_block(inputs=None,width={},depth=None,activation_func=None,kernel_init='glorot_normal',kernel_regu=None, name=None,residual_module_par={},layer_LSTM={'Add':False},layer_CNN={'Add':False}):
    # Residual module is/not contained in the dnn sub-block
    nstack_name=['pre_sat','pre','gsat','osat']
    if name[:-6] in nstack_name:
        nstack_idx=nstack_name.index(name[:-6])
    else:
        nstack_idx=1  # Set to pressure index
        
    if depth<=0:
        hlayer = inputs
    else:
        if residual_module_par['Network_Type']=='RESN':
            # Create the stack list

            stack_list=sparse_pad_list(depth=depth,nstacks=residual_module_par['NStacks'][nstack_idx])
            width_list=network_width_list(depth=depth,width=width['Bottom_Size'],ngens=residual_module_par['NStacks'][nstack_idx],growth_rate=width['Growth_Rate'],growth_type=width['Growth_Type'],network_type='resn')
            stack_list_nonzero=tf.where(tf.constant(stack_list)!=0).numpy()
            for i in range(0,depth):
                # Define the dropout stack configuration
                if residual_module_par['Dropout']['Add']:
                    if i==stack_list_nonzero[0]:
                        dropout={'Add':residual_module_par['Dropout']['Add'],'Dropout_Idx_Stack':residual_module_par['Dropout']['Dropout_Stack'][0],'Rate':residual_module_par['Dropout']['Rate'][0]}
                    elif i==stack_list_nonzero[-1]:
                        dropout={'Add':residual_module_par['Dropout']['Add'],'Dropout_Idx_Stack':residual_module_par['Dropout']['Dropout_Stack'][-1],'Rate':residual_module_par['Dropout']['Rate'][-1]}
                    elif i in stack_list_nonzero[1:-1]:
                        dropout={'Add':residual_module_par['Dropout']['Add'],'Dropout_Idx_Stack':residual_module_par['Dropout']['Dropout_Stack'][1],'Rate':residual_module_par['Dropout']['Rate'][1]}
                    else:
                        dropout={'Add':residual_module_par['Dropout']['Add'],'Dropout_Idx_Stack':0,'Rate':0}
                else:
                    dropout={'Add':residual_module_par['Dropout']['Add'],'Dropout_Idx_Stack':0,'Rate':0}
                    
                if i==0:
                    # Check if residual layer is to be added at index from stack_list
                    if stack_list[i]!=0:
                        hlayer=residual_module(inputs=inputs, width=width_list[i], depth=stack_list[i], kernel_init=residual_module_par['Kernel_Init'], kernel_regu=residual_module_par['Kernel_Regu'], batch_norm=residual_module_par['Batch_Norm'], activation_func=residual_module_par['Activation_Func'],dropout=dropout, block_name=name+'_res_block_'+str(i+1))
                    else:
                        continue
                else:
                    # Check if residual layer is to be added at index from stack_list
                    if stack_list[i]!=0:
                        hlayer=residual_module(inputs=hlayer, width=width_list[i], depth=stack_list[i], kernel_init=residual_module_par['Kernel_Init'], kernel_regu=residual_module_par['Kernel_Regu'], batch_norm=residual_module_par['Batch_Norm'], activation_func=residual_module_par['Activation_Func'],dropout=dropout,block_name=name+'_res_block_'+str(i+1))
                    else:
                        continue

        elif residual_module_par['Network_Type']=='LSTM':
            # Check if Dense layers are to be added inbetween the LSTM
            stack_list=LSTM_pad_list(depth=depth,dense_layers_inbetween=residual_module_par['Add_Dense_Inbetween_LSTM'])
            width_list=network_width_list(depth=depth,width=width['Bottom_Size'],ngens=0,growth_rate=width['Growth_Rate'],growth_type=width['Growth_Type'],network_type='plain')  # Plain Network Type still used for LSTM
            for i in range(0,depth):
                if i==0:
                    if stack_list[i]!=0:
                        hlayer=tf.keras.layers.LSTM(width_list[i], activation=residual_module_par['Activation_Func'], recurrent_activation=residual_module_par['LSTM_Activation_Func'],use_bias=True, kernel_initializer=residual_module_par['Kernel_Init'],name=name+'_LSTM_layer_'+str(i+1))(tf.expand_dims(inputs,-1))
                    else:
                        hlayer=tf.keras.layers.Dense(width_list[i], activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_layer_LSTM_'+str(i+1))(inputs)
                else:
                    if stack_list[i]!=0:
                        hlayer=tf.keras.layers.LSTM(width_list[i], activation=residual_module_par['Activation_Func'], recurrent_activation=residual_module_par['LSTM_Activation_Func'],use_bias=True, kernel_initializer=residual_module_par['Kernel_Init'],name=name+'_LSTM_layer_'+str(i+1))(tf.expand_dims(hlayer,-1))
                    else:
                        hlayer=tf.keras.layers.Dense(width_list[i], activation=residual_module_par['Activation_Func'], kernel_initializer=residual_module_par['Kernel_Init'], name=name+'_Dense_layer_LSTM_'+str(i+1))(hlayer)
        elif residual_module_par['Network_Type']=='CNN2D':
            stack_list=LSTM_pad_list(depth=depth,dense_layers_inbetween=False)
            #width_list=network_width_list(depth=depth,width=width['Bottom_Size'],ngens=0,growth_rate=width['Growth_Rate'],growth_type=width['Growth_Type'],network_type='plain')  # Plain Network Type still used for LSTM
            hlayer=encoder_decoder(inputs=inputs,depth=depth,width=width,name=name,nstack_idx=nstack_idx,residual_module_par=residual_module_par)

        else:  #Plain Network
            hlayer=plain_network(inputs=inputs,depth=depth,width=width,activation_func=activation_func,kernel_init=kernel_init,kernel_regu=kernel_regu,nstack_idx=nstack_idx,name=name,residual_module_par=residual_module_par)
        # ===============================================================================================================================
        # Add a Memory/CNN layer before the output
        if layer_LSTM['Add']:
            hlayer=tf.keras.layers.Reshape((1,hlayer.shape[-1]))(hlayer)
            #batch_input_shape=(841, hlayer.shape[1],hlayer.shape[2])
            hlayer=tf.keras.layers.LSTM(layer_LSTM['Units'], activation=layer_LSTM['Activation_Func'], recurrent_activation=layer_LSTM['Recur_Activation_Func'],use_bias=layer_LSTM['Bias'], kernel_initializer=kernel_init,stateful=layer_LSTM['Stateful'],name=name+'_LSTM_layer_'+str(i+1))(hlayer)
        if layer_CNN['Add'] and layer_CNN['Type']=='1D':
            hlayer=tf.keras.layers.Reshape((hlayer.shape[-1],1))(hlayer)
            hlayer=tf.keras.layers.Conv1D(layer_CNN['Filter'], layer_CNN['Kernel_Size'], strides=1, padding='valid',data_format='channels_last', dilation_rate=1, groups=1,kernel_initializer=kernel_init,activation=layer_CNN['Activation_Func'],name=name+'_CNV1D_layer_'+str(i+1))(hlayer)
            hlayer=tf.keras.layers.Flatten()(hlayer)
        #hlayer=tf.keras.layers.GaussianNoise(0.005)(hlayer)
        #===============================================================================================================================
    return hlayer
         
def sparse_pad_list(depth=None,nstacks=None):
    if nstacks>depth:
        nstacks=depth
    elif nstacks==0:
        nstacks=1
    no_per_stack=int(depth/nstacks)
    rem_stack=int(depth%nstacks)
    new_list=[]
    for i in range(int(nstacks)):
        if i==0:
            stack=[no_per_stack+rem_stack]+(no_per_stack+rem_stack-1)*[0]
        else:
            stack=[no_per_stack]+(no_per_stack-1)*[0]
        new_list=new_list+stack
    return new_list

def LSTM_pad_list(depth=None,dense_layers_inbetween=True):
    pad_list=depth*[1]
    if dense_layers_inbetween:
        for i in range(1,depth,2):
            pad_list[i]=0
    pad_list[depth-1]=0
    return pad_list
            
def network_width_list(width=None,depth=None,ngens=None,network_type='plain',growth_type='smooth',growth_rate=0.5):
    import numpy as np
    # network_type: 'plain' | 'resn'
    # growth_type: 'smooth' | 'cross'
    # resnet usually dont have a cross growth
    def create_even(num):
        return int(num/2)*2
    if ngens==None or ngens==0:
        ngens=1
    elif ngens>depth:
        ngens=depth

    no_per_gen=int(depth/ngens)
    rem_gen=int(depth%ngens)
    new_list=[] 
    for i in range(int(ngens)):
        if i==0:
            if network_type=='plain':
                gen=(no_per_gen+rem_gen)*[(1*growth_rate**(i))]
            else:
                gen=[(1*growth_rate**(i))]+(no_per_gen+rem_gen-1)*[0]
        else:
            if network_type=='plain':
                if growth_type=='smooth':
                    gen=(no_per_gen)*[(1*growth_rate**(i))]
                else:
                    if i<=int(ngens/2):
                        gen=(no_per_gen)*[(1*growth_rate**(i))] 
                    else:
                        gen=(no_per_gen)*[(1*(growth_rate)**(2*int(ngens/2)-i))]
            else:
                if growth_type=='smooth':
                    gen=[(1*growth_rate**(i))]+(no_per_gen-1)*[0]
                else:
                    if i<=int(ngens/2):
                        gen=[(1*growth_rate**(i))]+(no_per_gen-1)*[0]
                    else:
                        gen=[(1*(growth_rate)**(2*int(ngens/2)-i))]+(no_per_gen-1)*[0]
        new_list=new_list+gen
    new_list=[int(create_even(np.ceil(i*width))) for i in new_list]
    return new_list
#==============================================================================================================================================================================================================================
# Randomly Initialize variables
def make_rand_variables(initializer='Random_Normal',var_shape=(),dist_mean=1.0,dist_std=0.2,norm_output=True,var_trainable=False):
    if initializer=='Random_Normal':
        rand_var=tf.random_normal_initializer(mean=tf.cast(dist_mean,dt_type),stddev=dist_std)(shape=var_shape,dtype=dt_type)
    else:
        rand_var=dist_mean
    if norm_output==True:
        nrand_var=tf.linalg.normalize(rand_var,ord=1)[0]
    else:
        nrand_var=rand_var
    var=tf.Variable(nrand_var,dtype=dt_type,trainable=var_trainable)
    return var

# Create the model class--inherits the keras.model class
class pinn_Model(tf.keras.Model):
    def __init__(self,ts,cfd_type,*args, **kwargs):
        super().__init__( *args, **kwargs)
        # ts is a 2D tensor representing the training statistics. 
        # ts rows is defined by: ['x_coord', 'y_coord', 'z_coord', 'Time', 'Poro', 'PermX', 'PermZ', 'Mobility', 
                                    # 'Tcompressibility', 'GasFVF','Gas Production Rate (Mscf/D)']
        # ts columns is defined by: ['min','max','mean','std','count']
        
        # Get the CFD type
        self.cfd_type=cfd_type                  # Dictionary of the 'Type':'PINN', 'noPINN'; 'Dimension': '2D', '3D'
        self.ts=tf.Variable(ts[0],trainable=False, dtype=dt_type)           # Training statistics--if value is None, no normalization is done
        self.ts_idx_keys=[ts[1],ts[2]]
        #=========================================================================================================================================
        self.phi_0=self.ts[4,2]                  # Mean porosity of the training data      
        # Compute the rock/formation compressibility using Newman, G. H. (1973) correlation for consolidated sandstones
        self.cf=97.32e-6/(1+55.8721*self.phi_0**1.428586)
        self.grad=[]
        self.sg=1-0.22
        self.loss_func={}   #Loss functions 
        # Create a variable for the cumulative rate
        self.cum={key:tf.Variable(0, dtype=self.dtype, trainable=False) for key in ['Gas_Pred','Gas_Obs','Cum_N']}
        self.batch_seed_no={'numpy':0} #'tf':tf.Variable(0,trainable=False,dtype=self.dtype)
        self.tstep=tf.Variable(cfd_type['Timestep'],trainable=False,dtype=self.dtype)
        
        # Create a ID index stitch for the gradients to used with dynamic stitch. Initialize the gradients accumulator
        self.idx=batch_loss.convert_1D(self).idx
        if self.cfd_type['Accum_Grad']['Add']==True:
            self.n_grad_steps=tf.constant(0, dtype=tf.int32)
            self.accum_step = tf.Variable(0, dtype=tf.int32, trainable=False)
            self.gradient_accumulation = [tf.Variable(tf.zeros_like(v, dtype=dt_type), trainable=False) for v in self.trainable_variables]
        #=========================================================================================================================================
        # Create a dictionary to hold the best model weight-biases based on a selected epoch obseravation range--using callback; also the train time
        self.wbl_epoch=[]
        self.wblt_epoch_ens=[]                          # Best tuning parameters for each realization/perturbation
        self.history_ens=[]
        self.best_ens=0
        #=========================================================================================================================================
        # Define the loss metrics for the non-physics training
        if self.cfd_type['Data_Arr']!=3:
            self.dom_loss = tf.keras.metrics.Mean(name="dom_loss")
            self.dbc_loss = tf.keras.metrics.Mean(name="dbc_loss")
            self.nbc_loss = tf.keras.metrics.Mean(name="nbc_loss")
            self.ibc_loss = tf.keras.metrics.Mean(name="ibc_loss")
            self.ic_loss = tf.keras.metrics.Mean(name="ic_loss")
        self.total_loss = tf.keras.metrics.Mean(name="loss")
        self.mae_metric = tf.keras.metrics.MeanAbsoluteError(name="mae")
        self.val_loss_tracker = tf.keras.metrics.MeanSquaredError(name="val_loss")
        self.val_mae_metric = tf.keras.metrics.MeanAbsoluteError(name="val_mae")
        
        # Use the mean metric to hold norm values
        self.grad_norm=tf.keras.metrics.Mean(name='gradient_norm')
        #=========================================================================================================================================
        # Define a weighting parameter (lm) for each loss and make it trainable. Starting value is given by: lm(i)=1/(no. of losses)
        if self.cfd_type['Type']=='PINN':
            # [DOM, DBC, NBC, IBC, IC, TD]
            self.mbc_loss = tf.keras.metrics.Mean(name="mbc_loss")
            self.cmbc_loss = tf.keras.metrics.Mean(name="cmbc_loss")
            self.loss_func['Batch_Loss']=batch_loss.pinn_batch_sse_grad
            if self.cfd_type['DNN_Arch'] in ['resn','plain','']:
                self.loss_func['Physics_Error']=batch_loss.pinn_error
                self.loss_func['Squeeze_Out']=tf.squeeze
                self.loss_func['Reshape']=lambda x:tf.reshape(x,self.cfd_type['Dimension']['Reshape'])
                self.loss_func['Reduce_Axis']=[1,2,3]
            else:
                self.loss_func['Physics_Error']=batch_loss.pinn_error_2D
                self.loss_func['Squeeze_Out']=lambda x:x # Output is not squeezed
                self.loss_func['Reshape']=lambda x:x
                self.loss_func['Reduce_Axis']=[1,2,3,4]
            self.lbl_idx=15
            if self.cfd_type['Fluid_Type']=='dry-gas':
                self.nwt=make_rand_variables(initializer='Random_Normal',var_shape=[9],dist_mean=cfd_type['Solu_Weights'],dist_std=7*[0.]+[0.,0.],norm_output=True,var_trainable=False)        # DOM, DBC, NBC, IBC, IC
                self.nwt_test=make_rand_variables(initializer='Random_Normal',var_shape=[2],dist_mean=[1.,0.],dist_std=0.,norm_output=True,var_trainable=False)        # DOM, DBC, NBC, IBC, IC
                self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sg':tf.keras.metrics.Mean(name="td_loss_sg")}
            else:
                self.nwt=make_rand_variables(initializer='Random_Normal',var_shape=[10],dist_mean=cfd_type['Solu_Weights'],dist_std=7*[0.]+[0.,0.,0.],norm_output=True,var_trainable=False)        # DOM, DBC, NBC, IBC, IC
                self.nwt_test=make_rand_variables(initializer='Random_Normal',var_shape=[2],dist_mean=[1.,0.,0.],dist_std=0.,norm_output=True,var_trainable=False)        # DOM, DBC, NBC, IBC, IC
                self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sg':tf.keras.metrics.Mean(name="td_loss_sg"),'so':tf.keras.metrics.Mean(name="td_loss_so")}            
        else:
            if self.cfd_type['Data_Arr']==0:
                self.loss_func['Batch_Loss']=batch_loss.nopinn_batch_sse_grad_0
                if self.cfd_type['Fluid_Type']=='dry-gas':
                    # Set a label index for the input--18 for dry gas and 21 for gas-condensate data
                    self.lbl_idx=16
                    # Constitutive relationship and QoIs--pressure, gas saturation
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[1],dist_mean=1.0,dist_std=0.0,norm_output=True,var_trainable=False)  
                    self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sg':tf.keras.metrics.Mean(name="td_loss_sg")}
                else:
                    self.lbl_idx=17
                    # Constitutive relationship and QoIs--pressure, gas saturation, oil saturation
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[3],dist_mean=1.0,dist_std=0.0,norm_output=True,var_trainable=False)  
                    self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sg':tf.keras.metrics.Mean(name="td _loss_sg"),'so':tf.keras.metrics.Mean(name="td_loss_so")}
            elif self.cfd_type['Data_Arr']==1:
                if self.cfd_type['DNN_Arch']=='cnn2d':
                    self.loss_func['Batch_Loss']=batch_loss.nopinn_batch_sse_grad_0
                else:
                    self.loss_func['Batch_Loss']=batch_loss.nopinn_batch_sse_grad_1
                self.lbl_idx=15
                if self.cfd_type['Fluid_Type']=='dry-gas':
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[2],dist_mean=1*[1.]+1*[1.],dist_std=0.0,norm_output=True,var_trainable=False)
                    # Create additional metrics for other labels 
                    self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sg':tf.keras.metrics.Mean(name="td_loss_sg")}
                    if self.cfd_type['Aux_Layer']['Bu']:
                        nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[4],dist_mean=1*[1.]+1*[1.]+2*[0.],dist_std=0.0,norm_output=True,var_trainable=False)
                        self.td_loss.update({'Bg':tf.keras.metrics.Mean(name="td_loss_Bg"),'ug':tf.keras.metrics.Mean(name="td_loss_ug")})
                else:
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[3],dist_mean=1*[1.]+2*[1.],dist_std=0.0,norm_output=True,var_trainable=False)
                    # Create additional metrics for other labels 
                    self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sg':tf.keras.metrics.Mean(name="td_loss_sg"),'so':tf.keras.metrics.Mean(name="td_loss_so")}
                    if self.cfd_type['Aux_Layer']['Bu']:
                        nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[7],dist_mean=1*[1.]+2*[1.]+4*[0.],dist_std=0.0,norm_output=True,var_trainable=False)
                        self.td_loss.update({'Bg':tf.keras.metrics.Mean(name="td_loss_Bg"),'Bo':tf.keras.metrics.Mean(name="td_loss_Bo"),\
                                   'ug':tf.keras.metrics.Mean(name="td_loss_ug"),'uo':tf.keras.metrics.Mean(name="td_loss_uo")})

            elif self.cfd_type['Data_Arr']==2:
                self.loss_func['Batch_Loss']=batch_loss.nopinn_batch_sse_grad_1
                self.lbl_idx=15
                if self.cfd_type['Fluid_Type']=='dry-gas':
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[2],dist_mean=1.0,dist_std=0.0,norm_output=True,var_trainable=False)
                    # Create additional metrics for other labels 
                    self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sbu_g':tf.keras.metrics.Mean(name="td_loss_sbu_g")}
                else:
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[3],dist_mean=1.0,dist_std=0.0,norm_output=True,var_trainable=False)
                    # Create additional metrics for other labels 
                    self.td_loss={'p':tf.keras.metrics.Mean(name="td_loss_p"),'sbu_g':tf.keras.metrics.Mean(name="td_loss_sbu_g"),'sbu_o':tf.keras.metrics.Mean(name="td_loss_sbu_o")}

            elif self.cfd_type['Data_Arr']==3:                      # Special Kind of arrangement for pretraining the PVT data
                self.loss_func['Batch_Loss']=batch_loss.nopinn_batch_sse_grad_pvt
                self.lbl_idx=15
                if self.cfd_type['Fluid_Type']=='dry-gas':
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[2],dist_mean=cfd_type['Solu_Weights'],dist_std=0.0,norm_output=True,var_trainable=False)
                    # Create additional metrics for other labels 
                    self.td_loss={'Bg':tf.keras.metrics.Mean(name="td_loss_Bg"),'ug':tf.keras.metrics.Mean(name="td_loss_ug")}
                else:
                    nrwt=make_rand_variables(initializer='Random_Normal',var_shape=[4],dist_mean=cfd_type['Solu_Weights'],dist_std=0.0,norm_output=True,var_trainable=False)
                    # Create additional metrics for other labels 
                    self.td_loss={'Bg':tf.keras.metrics.Mean(name="td_loss_Bg"),'Bo':tf.keras.metrics.Mean(name="td_loss_Bo"),\
                                   'ug':tf.keras.metrics.Mean(name="td_loss_ug"),'uo':tf.keras.metrics.Mean(name="td_loss_uo")}
              
            # Pad with zero-based vector of shape=5 to represent the empty DOM, DBC, NBC, IBC, IC solution sets.
            self.nwt=tf.concat([tf.zeros([5],dtype=dt_type),nrwt],axis=0)
        
        #=========================================================================================================================================
        # Solution label index settings        
        self.solu_idx={'DOM':0,'DBC':1,'NBC':2,'IBC':3,'IC':4,'TD':5,'TDA':6} 
        if self.cfd_type['Fluid_Type']=='dry-gas':        
            self.nT=2                   # Number of predictor terms
            self.aux_models={'sg':None}
        else:
            self.nT=3
            self.models={'sg':None,'so':None}
        
            
    # Override the __train_step__ method
    def train_step(self, data):
        # Unpack the data. Its structure depends on your model and
        # on what you pass to `fit()`.
        x, y = data
        
        # Set the batch seed number and set for any random distribution -- adding noising effect
        tf.random.set_seed(self.batch_seed_no['numpy'])
                
        # Perform batch PINN calculation using the pinn_batch_sse_gradfunction
        #batch_sse_grad=tf.cond(tf.math.equal(self.cfd_type['Type'],'PINN'),lambda: batch_loss.pinn_batch_sse_grad(self,x,y),lambda: batch_loss.nopinn_batch_sse_grad_0(self,x,y))
        batch_sse_grad=self.loss_func['Batch_Loss'](self,x,y)
        
        # Update the batch seed number
        #self.batch_seed_no['tf'].assign_add((self.cfd_type['Seed'])*0.5)
    
        # The return value using the nopinn_batch_sse_grad function is a list with indexing:
        # [0]: Weighted SSE loss list=[batch,DOM,DBC,NBC,IBC,IC,TD]
        # [1]: Weighted SSE gradient list=[batch,DOM,DBC,NBC,IBC,IC,TD]
        # [2]: Error count list=[batch,DOM,DBC,NBC,IBC,IC,TD]
        # [3]: Weighted MSE loss list=[batch,DOM,DBC,NBC,IBC,IC,TD]
        # [4]: Model's output
        
        # Compute the individual solution gradient based on MSE
        #Training data is at the nth list
        no_terms=len(batch_sse_grad[2])
               
        # Compute the PINN (if any) MSE gradients
        _wmse_grad=[[gradients/batch_loss.zeros_to_ones(batch_sse_grad[2][i+1]) for gradients in batch_sse_grad[1][i+1]] for i in range(no_terms-1)]
        """
        if self.cfd_type['Data_Arr']!=3:
            batch_wmse_grad=[(a+b+c+d+e+f+g) for a,b,c,d,e,f,g in zip(_wmse_grad[0],_wmse_grad[1],_wmse_grad[2],_wmse_grad[3],_wmse_grad[4],_wmse_grad[5],_wmse_grad[6])] 
        else:
            batch_wmse_grad=_wmse_grad[0]"""
        batch_wmse_grad=[tf.reduce_sum(i,axis=0) for i in zip(*_wmse_grad)] 

        aggregate_grads_outside_optimizer = (
        self.optimizer._HAS_AGGREGATE_GRAD and  # pylint: disable=protected-access
        not isinstance(self.distribute_strategy.extended,tf.distribute.StrategyExtended))
        
        #if aggregate_grads_outside_optimizer:
            # We aggregate gradients before unscaling them, in case a subclass of
            # LossScaleOptimizer all-reduces in fp16. All-reducing in fp16 can only be
            # done on scaled gradients, not unscaled gradients, for numeric stability.
            #batch_rgl_mse_grad = self.optimizer._aggregate_gradients(zip(batch_rgl_mse_grad, self.trainable_variables))    # pylint: disable=protected-access    
        
        #if isinstance(self.optimizer, tf.keras.mixed_precision.experimental.LossScaleOptimizer):
            #batch_rgl_mse_grad = self.optimizer.get_unscaled_gradients(batch_rgl_mse_grad)
        
        # Clips the gradient
        #_norm=tf.math.divide(tf.norm(tf.dynamic_stitch(self.idx,batch_wmse_grad),ord='euclidean'),tf.math.sqrt(tf.cast(len(batch_wmse_grad),dtype=dt_type)))
        #batch_wmse_grad=tf.cond(tf.math.greater_equal(_norm, self.cfd_type['Gradient_Norm']),\
                                  #lambda: [tf.clip_by_norm(gradients,self.cfd_type['Gradient_Norm']) for gradients in batch_wmse_grad],\
                                                           #lambda: batch_wmse_grad)
        #batch_rgl_mse_grad = self.optimizer._clip_gradients(batch_rgl_mse_grad)  
        
        # Accumulate batch gradients
        if self.cfd_type['Accum_Grad']['Add']==True:
            self.accum_grad(batch_wmse_grad)
        else:
            self.optimizer.apply_gradients(zip(batch_wmse_grad, self.trainable_variables)) 
        
        # Model's output --pressure and/or saturation 
        y_pred=batch_sse_grad[4]

        self.total_loss.update_state(batch_sse_grad[3][0])
        # Compute the global norm
        self.grad_norm.update_state(tf.math.divide(tf.norm(tf.dynamic_stitch(self.idx,batch_wmse_grad),ord='euclidean'),tf.math.sqrt(tf.cast(len(batch_wmse_grad),dtype=dt_type))))

        # MAE on the pressure and saturation (QoIs) and [permeability (Constitutive relationship)]
        dict_map={"loss": self.total_loss.result(), "mae": self.mae_metric.result()} 
        
        # Compute PINN-defined metrics--MSE        
        if self.cfd_type['Data_Arr']!=3:
            self.dom_loss.update_state(batch_sse_grad[3][1])
            self.dbc_loss.update_state(batch_sse_grad[3][2])
            self.nbc_loss.update_state(batch_sse_grad[3][3])
            self.ibc_loss.update_state(batch_sse_grad[3][4])
            self.ic_loss.update_state(batch_sse_grad[3][5])
            dict_map.update({"dom_loss": self.dom_loss.result(),"dbc_loss": self.dbc_loss.result(),\
                "nbc_loss": self.nbc_loss.result(),"ibc_loss": self.ibc_loss.result(),"ic_loss": self.ic_loss.result()})
            
        if self.cfd_type['Type']=='PINN' or self.cfd_type['Data_Arr']==0:
            # OUTPUTS: p,sg and/or so
            self.mbc_loss.update_state(batch_sse_grad[3][6])
            self.cmbc_loss.update_state(batch_sse_grad[3][7])
            dict_map.update({"mbc_loss":self.mbc_loss.result(),"cmbc_loss":self.cmbc_loss.result()})
            if self.cfd_type['Fluid_Type']=='dry-gas': 
                self.mae_metric.update_state([y[0],y[1]],[y_pred[0],y_pred[1]],sample_weight=self.nwt[7:9])
                self.td_loss['p'].update_state(batch_sse_grad[3][8][0])
                self.td_loss['sg'].update_state(batch_sse_grad[3][8][1])
                dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sg": self.td_loss['sg'].result(),"grad_norm":self.grad_norm.result()})
            else: 
                self.mae_metric.update_state([y[0],y[1],y[2]],[y_pred[0],y_pred[1],y_pred[2]],sample_weight=self.nwt[7:10])
                self.td_loss['p'].update_state(batch_sse_grad[3][8][0])
                self.td_loss['sg'].update_state(batch_sse_grad[3][8][1])
                self.td_loss['so'].update_state(batch_sse_grad[3][8][2])
                dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sg": self.td_loss['sg'].result(),"td_loss_so": self.td_loss['so'].result(),"grad_norm":self.grad_norm.result()})
        else:
            if self.cfd_type['Data_Arr']==1:
                nT=tf.shape(y_pred)[0]
                if self.cfd_type['Fluid_Type']=='dry-gas': 
                    # OUTPUTS: p,sg,Bg,ug ...[qg]
                    self.td_loss['p'].update_state(batch_sse_grad[3][6][0])
                    self.td_loss['sg'].update_state(batch_sse_grad[3][6][1])
                    self.mae_metric.update_state(tf.stack(y)[0:nT],tf.stack(y_pred,0),sample_weight=self.nwt[5:5+nT])
                    #self.mae_metric.update_state([y[0],y[1],y[2],y[3]],[y_pred[0],y_pred[1],y_pred[2],y_pred[3]],sample_weight=self.nwt[5:nT])
                    if self.cfd_type['Aux_Layer']['Bu']:
                        self.td_loss['Bg'].update_state(batch_sse_grad[3][6][2])
                        self.td_loss['ug'].update_state(batch_sse_grad[3][6][3])
                        dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sg": self.td_loss['sg'].result(),"td_loss_Bg": self.td_loss['Bg'].result(),\
                                     "td_loss_ug": self.td_loss['ug'].result(),"grad_norm":self.grad_norm.result()})
                    else:
                        dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sg": self.td_loss['sg'].result(),"grad_norm":self.grad_norm.result()})
                else:
                    # OUTPUTS: p,so,sg,Bg,Bo,ug,uo, ...[qg,qo]
                    self.td_loss['p'].update_state(batch_sse_grad[3][6][0])
                    self.td_loss['sg'].update_state(batch_sse_grad[3][6][1])
                    self.td_loss['so'].update_state(batch_sse_grad[3][6][2])
                    self.mae_metric.update_state(tf.stack(y)[0:nT],tf.stack(y_pred,0),sample_weight=self.nwt[5:5+nT])
                    if self.cfd_type['Aux_Layer']['Bu']:
                        self.td_loss['Bg'].update_state(batch_sse_grad[3][6][3])
                        self.td_loss['Bo'].update_state(batch_sse_grad[3][6][4])
                        self.td_loss['ug'].update_state(batch_sse_grad[3][6][5])
                        self.td_loss['uo'].update_state(batch_sse_grad[3][6][6])
                        dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sg": self.td_loss['sg'].result(),"td_loss_so": self.td_loss['so'].result(),"td_loss_Bg": self.td_loss['Bg'].result(),\
                                     "td_loss_Bo": self.td_loss['Bo'].result(),"td_loss_ug": self.td_loss['ug'].result(),"td_loss_uo": self.td_loss['uo'].result(),"grad_norm":self.grad_norm.result()})
                    else:
                        dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sg": self.td_loss['sg'].result(),"td_loss_so": self.td_loss['so'].result(),"grad_norm":self.grad_norm.result()})

            elif self.cfd_type['Data_Arr']==2:
                if self.cfd_type['Fluid_Type']=='dry-gas':  
                    # OUTPUTS: p,sbu_g
                    self.mae_metric.update_state([y[0],y[1]],[y_pred[0],y_pred[1]],sample_weight=self.nwt[5:7])
                    self.td_loss['p'].update_state(batch_sse_grad[3][6][0])
                    self.td_loss['sbu_g'].update_state(batch_sse_grad[3][6][1])
                    dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sbu_g": self.td_loss['sbu_g'].result(),"grad_norm":self.grad_norm.result()})
                else:
                    # OUTPUTS: p,sbu_g,sbu_o
                    self.mae_metric.update_state([y[0],y[1],y[2]],[y_pred[0],y_pred[1],y_pred[2]],sample_weight=self.nwt[5:8])
                    self.td_loss['p'].update_state(batch_sse_grad[3][6][0])
                    self.td_loss['sbu_g'].update_state(batch_sse_grad[3][6][1])
                    self.td_loss['sbu_o'].update_state(batch_sse_grad[3][6][2])
                    dict_map.update({"td_loss_p": self.td_loss['p'].result(),"td_loss_sbu_g": self.td_loss['sbu_g'].result(),"td_loss_sbu_o": self.td_loss['sbu_o'].result(),"grad_norm":self.grad_norm.result()})
            elif self.cfd_type['Data_Arr']==3:               # Special form for PVT pretraining
                nT=tf.shape(y_pred)[0]
                if self.cfd_type['Fluid_Type']=='dry-gas': 
                    # OUTPUTS: Bg,ug
                    self.td_loss['Bg'].update_state(batch_sse_grad[3][1][0])
                    self.td_loss['ug'].update_state(batch_sse_grad[3][1][1])
                    self.mae_metric.update_state(tf.stack(y)[0:nT],tf.stack(y_pred,0),sample_weight=self.nwt[5:5+nT])
                    dict_map.update({"td_loss_Bg": self.td_loss['Bg'].result(),"td_loss_ug": self.td_loss['ug'].result(),"grad_norm":self.grad_norm.result()})
                else:
                    # OUTPUTS: Bg,Bo,ug,uo
                    self.td_loss['Bg'].update_state(batch_sse_grad[3][1][0])
                    self.td_loss['Bo'].update_state(batch_sse_grad[3][1][1])
                    self.td_loss['ug'].update_state(batch_sse_grad[3][1][2])
                    self.td_loss['uo'].update_state(batch_sse_grad[3][1][3])
                    self.mae_metric.update_state(tf.stack(y)[0:nT],tf.stack(y_pred,0),sample_weight=self.nwt[5:5+nT])
                    dict_map.update({"td_loss_Bg": self.td_loss['Bg'].result(),"td_loss_Bo": self.td_loss['Bo'].result(),"td_loss_ug": self.td_loss['ug'].result(),"td_loss_uo": self.td_loss['uo'].result(),"grad_norm":self.grad_norm.result()})
   
        # Return a dict mapping metric names to current value--i.e., Mean
        return dict_map
    
    def accum_grad(self, grad):
        self.accum_step.assign_add(1)
        for i in range(len(self.gradient_accumulation)):
            self.gradient_accumulation[i].assign_add(grad[i])
        
        # If accum_step has reached the n_grad_steps, then we apply accumulated gradients to update the variables otherwise do nothing
        tf.cond(tf.math.equal(self.accum_step, self.n_grad_steps), self.apply_accu_gradients, lambda: None)
        
    def apply_accu_gradients(self):
        # Apply accumulated gradients
        self.optimizer.apply_gradients(zip(self.gradient_accumulation, self.trainable_variables))
        # Reset the step and accumulated gradient values, and other cumulative variables 
        self.accum_step.assign(0)
        [self.cum[key].assign(0) for key in ['Gas_Pred','Gas_Obs','Cum_N']]

        for i in range(len(self.gradient_accumulation)):
            self.gradient_accumulation[i].assign(tf.zeros_like(self.trainable_variables[i], dtype=dt_type))    
    
    def test_step(self, data):
        # Unpack the data
        x, y = data
        # Compute predictions
        
        # Updates the metrics tracking the loss--could be scaled further/cleaner
        if self.cfd_type['Type']=='PINN' or self.cfd_type['Data_Arr']==0:
            if self.cfd_type['Fluid_Type']=='dry-gas':
                nT=tf.shape(self.outputs)[0]._inferred_value[0]-5  # Exclude gsat,1/Bg,1/ug,qg,s1--tf.shape is zero indexed
            else:
                nT=tf.shape(self.outputs)[0]._inferred_value[0]-10  # Exclude gsat,osat,1/Bg,1/Bo,1/ug,1/uo,qg,qo,s1,s2
            
            if self.cfd_type['Val_Data_Label']:
                y_pred = self(x, training=False)
                self.val_loss_tracker.update_state(tf.stack(y)[0:nT],tf.stack(y_pred[0:nT],0),sample_weight=self.nwt_test[0:nT])
                self.val_mae_metric.update_state(tf.stack(y)[0:nT],tf.stack(y_pred[0:nT],0),sample_weight=self.nwt_test[0:nT])
            else:
                #=====================================IC Solution======================================================= 
                # Forward pass is used as it still the model solution but at initial condition (t=0) 
                xn_t0=list(x)
                xn_t0[3]=self.cfd_type['Norm_Limits'][0]*tf.ones_like(xn_t0[0])

                y_pred=self(xn_t0, training=False)
               
                pi=tf.ones_like(tf.stack(y_pred[0:nT],0))*self.cfd_type['Pi']
                self.val_loss_tracker.update_state(pi,tf.stack(y_pred[0:nT],0),sample_weight=self.nwt_test[0:nT])
                self.val_mae_metric.update_state(pi,tf.stack(y_pred[0:nT],0),sample_weight=self.nwt_test[0:nT]) 
        else:
            y_pred = self(x, training=False)
            if self.cfd_type['Data_Arr'] in [1,3]:
                nT=tf.shape(y_pred)[0]
                self.val_loss_tracker.update_state(tf.stack(y)[0:nT],tf.stack(y_pred,0),sample_weight=self.nwt[5:5+nT])
                self.val_mae_metric.update_state(tf.stack(y)[0:nT],tf.stack(y_pred,0),sample_weight=self.nwt[5:5+nT])
            elif self.cfd_type['Data_Arr']==2:
                if self.cfd_type['Fluid_Type']=='dry-gas': 
                    self.val_loss_tracker.update_state([y[0],y[1]],[y_pred[0],y_pred[1]],sample_weight=self.nwt[5:7])
                    self.val_mae_metric.update_state([y[0],y[1]],[y_pred[0],y_pred[1]],sample_weight=self.nwt[5:7])
                else:
                    self.val_loss_tracker.update_state([y[0],y[1],y[2]],[y_pred[0],y_pred[1],y_pred[2]],sample_weight=self.nwt[5:8])
                    self.val_mae_metric.update_state([y[0],y[1],y[2]],[y_pred[0],y_pred[1],y_pred[2]],sample_weight=self.nwt[5:8])
        # Return a dict mapping metric names to current value--i.e., Mean
        return {"loss": self.val_loss_tracker.result(), "mae": self.val_mae_metric.result()}
        
    @property
    def metrics(self):
        # We list our `Metric` objects here so that `reset_states()` can be
        # called automatically at the start of each epoch
        # or at the start of `evaluate()`.
        # If you don't implement this property, you have to call
        # `reset_states()` yourself at the time of your choosing.
        if self.cfd_type['Type']=='PINN' or self.cfd_type['Data_Arr']==0:
            data_reset=[self.total_loss,self.dom_loss,self.dbc_loss,self.nbc_loss,self.ibc_loss,self.ic_loss,self.mbc_loss,self.cmbc_loss,self.td_loss['p'],self.td_loss['sg'],self.mae_metric,self.val_loss_tracker,self.val_mae_metric,self.grad_norm]
            if self.cfd_type['Fluid_Type']!='dry-gas':
                data_reset=data_reset+[self.td_loss['so']]
        else:
            if self.cfd_type['Data_Arr']==1:
                data_reset=[self.total_loss,self.dom_loss,self.dbc_loss,self.nbc_loss,self.ibc_loss,self.ic_loss,self.td_loss['p'],self.td_loss['sg'],self.mae_metric,self.val_loss_tracker,self.val_mae_metric,self.grad_norm]
                if self.cfd_type['Aux_Layer']['Bu']:
                    data_reset=data_reset+[self.td_loss['Bg'],self.td_loss['ug']]
                    if self.cfd_type['Fluid_Type']!='dry-gas':
                        data_reset=data_reset+[self.td_loss['so'],self.td_loss['Bo'],self.td_loss['uo']]      
                               
            elif self.cfd_type['Data_Arr']==2:
                data_reset=[self.total_loss,self.dom_loss,self.dbc_loss,self.nbc_loss,self.ibc_loss,self.ic_loss,self.td_loss['p'],self.td_loss['sbu_g'],self.mae_metric,self.val_loss_tracker,self.val_mae_metric,self.grad_norm]
                if self.cfd_type['Fluid_Type']!='dry-gas':
                    data_reset=data_reset+[self.td_loss['sbu_o']]
            elif self.cfd_type['Data_Arr']==3:       # Special data arrangement for PVT pretraining
                data_reset=[self.total_loss,self.mae_metric,self.val_loss_tracker,self.val_mae_metric,self.grad_norm,self.td_loss['Bg'],self.td_loss['ug']]
                if self.cfd_type['Fluid_Type']!='dry-gas':
                    data_reset=data_reset+[self.td_loss['Bo'],self.td_loss['uo']] 
        return data_reset

# Custom Layer class for the viscosity-compressibility function
class viscosity_FVF_inverse(tf.keras.layers.Layer):
    # Order of function: invBg,invug,d/dp(invBg),d/dp(invug) + invBo,invuo,d/dp(invBo),d/dp(invuo)
    # +...+(Fx**5)+(Ex**4)+(Dx**3)+(Cx**2)+(Bx**1)+(A**0)
    def __init__(self,units=1,pweights=[],cname=''):
        super(viscosity_FVF_inverse, self).__init__(name=cname)
        self.units=units
        self.pweights=pweights
        self.cname=cname

    def build(self,input_shape):
        '''
        if len(self.pweights)==0:
            w_init = tf.random_normal_initializer()
            self.w = tf.Variable(initial_value=w_init(shape=(tf.shape(self.pweights)[0],self.units)),trainable=False,)
            self.b= tf.Variable(initial_value=w_init(shape=(tf.shape(self.pweights)[0],self.units)),trainable=False,}'''
           
        self.w = self.add_weight(name=self.cname+'_weights',shape=(tf.shape(self.pweights)[0],self.units),initializer=tf.constant_initializer(value=self.pweights),trainable=False)
        self.b = self.add_weight(name=self.cname+'_bias',shape=(self.units,),initializer='zeros',trainable=False)
        
    def call(self, inputs):
        inputs=tf.squeeze(inputs,-1)
        inv_inputs=tf.squeeze(tf.transpose([tf.map_fn(lambda j: tf.math.pow(tf.cast(inputs,dt_type),j),tf.cast(tf.map_fn(lambda i:i,tf.range(tf.shape(self.pweights)[0]-1,-1,-1)),dt_type))]),-1)
        #X_invu=tf.squeeze(tf.transpose([tf.map_fn(lambda j: tf.math.pow(tf.cast(inputs,dt_type),j),tf.cast(tf.map_fn(lambda i:i,tf.range(self.poly_order[1],-1,-1)),dt_type))]),-1)

        # Derivative--invB*, invu*  *: could be for gas or condensate
        #X_dinvB=tf.stack([(tf.math.pow(tf.cast(inputs,dt_type),tf.cast(j,dt_type))*tf.cast(j+1,dt_type)) for j in tf.map_fn(lambda i:i,tf.range(self.poly_order[0]-1,-1,-1))],axis=1)
        #X_dinvu=tf.stack([(tf.math.pow(tf.cast(inputs,dt_type),tf.cast(j,dt_type))*tf.cast(j+1,dt_type)) for j in tf.map_fn(lambda i:i,tf.range(self.poly_order[1]-1,-1,-1))],axis=1)

        #X_dinvB=tf.squeeze(tf.transpose([tf.map_fn(lambda j: tf.math.pow(tf.cast(inputs,dt_type),j)*(j+1.),tf.cast(tf.map_fn(lambda i:i,tf.range(self.poly_order[0]-1,-1,-1)),dt_type))]),-1)
        #X_dinvu=tf.squeeze(tf.transpose([tf.map_fn(lambda j: tf.math.pow(tf.cast(inputs,dt_type),j)*(j+1.),tf.cast(tf.map_fn(lambda i:i,tf.range(self.poly_order[1]-1,-1,-1)),dt_type))]),-1)

        out=tf.matmul(inv_inputs,self.w)+self.b

        return out 

    #def custom_function(self):
     #   return self.custom_function
    
# Layer class activation function wrapper
def act_func_name_wrapper(act_func):
    if not hasattr(act_func,'__name__') and hasattr(act_func,'_instrumented_keras_layer_class'):
        act_func.__name__=act_func.name[:3]+str(act_func.alpha).replace('.','.')
    return act_func
     
# Swish activation function with beta adjustment
def swish_beta(beta=None):
    @tf.custom_gradient
    def swish(features):
        features=tf.convert_to_tensor(features, name='features')
        beta_=tf.convert_to_tensor(beta, dtype=features.dtype, name='beta') 
        def grad(dy):
            "Gradient for the swish activation function"
            with tf.control_dependencies([dy]):
                sigmoid_features = tf.math.divide(1.0,1.0+tf.math.exp(-beta_*features))
                activation_grad = (sigmoid_features * (1.0 + (features*beta_) * (1.0 - sigmoid_features)))
            return dy * activation_grad

        return tf.math.divide(features,1.0+tf.math.exp(-beta_*features)),grad
    
    swish.__name__='swish'+str(beta).replace('.','_')
    return swish

# Hard limit activation function
def hard_limit_func(lower_limit=14.7,upper_limit=5000., alpha=0.0):
    @tf.custom_gradient
    def hard_limit(features):
        features=tf.convert_to_tensor(features, name='features')
        lower_limit_=tf.convert_to_tensor(lower_limit, dtype=features.dtype, name='lower_limit') 
        upper_limit_=tf.convert_to_tensor(upper_limit, dtype=features.dtype, name='upper_limit') 
        alpha_=tf.convert_to_tensor(alpha, dtype=features.dtype, name='alpha') 
        #breakpoint()
        def f1(): return lower_limit_
        def f2(): return upper_limit_
        def f3(): return features

        def grad(dy):
            "Gradient for the swish activation function"
            with tf.control_dependencies([dy]):
                #activation_grad = tf.case([(tf.less(features, lower_limit_), lambda: tf.zeros_like(features)), (tf.greater(features, upper_limit_), lambda: tf.zeros_like(features))],
                #default=lambda: tf.ones_like(features), exclusive=False)
                activation_grad=tf.where(tf.less(features, lower_limit_),tf.ones_like(features)*alpha_,tf.where(tf.greater(features, upper_limit_),tf.ones_like(features)*alpha,tf.ones_like(features)))
            return dy * activation_grad
        
        #tf.case([(tf.less(features, lower_limit_), f1), (tf.greater(features, upper_limit_), f2)],default=f3, exclusive=False),grad
        r1=tf.where(tf.less(features, lower_limit_),lower_limit_+tf.math.abs(features-lower_limit_)*alpha_,tf.where(tf.greater(features, upper_limit_),upper_limit_+(features-upper_limit_)*alpha_,features))
        return r1,grad
    
    hard_limit.__name__='hard_limit'+str(lower_limit)+'_'+str(upper_limit).replace('.','_')
    return hard_limit

# Sigmoid activation function with pressure adjustment
def sigmoidp_func(lower_limit=14.7,upper_limit=5000.):
    @tf.custom_gradient
    def sigmoidp(features):
        features=tf.convert_to_tensor(features, name='features')
        lower_limit_=tf.convert_to_tensor(lower_limit, dtype=features.dtype, name='lower_limit') 
        upper_limit_=tf.convert_to_tensor(upper_limit, dtype=features.dtype, name='upper_limit') 
        def grad(dy):
            "Gradient for the swish activation function"
            with tf.control_dependencies([dy]):
                sigmoid_features = tf.math.divide(1.0,1.0+tf.math.exp(-features))
                activation_grad = (upper_limit_-lower_limit_)*(sigmoid_features * (1.0 - sigmoid_features))
            return dy * activation_grad

        return lower_limit_+(upper_limit_-lower_limit_)*tf.math.divide(1.0,1.0+tf.math.exp(-features)),grad
    
    sigmoidp.__name__='sigmoidp'+str(lower_limit)+'_'+str(upper_limit).replace('.','_')
    return sigmoidp

# Sine activation function with pressure adjustment
def sinep_func(lower_limit=14.7,upper_limit=5000.):
    @tf.custom_gradient
    def sinep(features):
        features=tf.convert_to_tensor(features, name='features')
        lower_limit_=tf.convert_to_tensor(lower_limit, dtype=features.dtype, name='lower_limit') 
        upper_limit_=tf.convert_to_tensor(upper_limit, dtype=features.dtype, name='upper_limit') 
        def grad(dy):
            "Gradient for the swish activation function"
            with tf.control_dependencies([dy]):
                activation_grad = (upper_limit_-lower_limit_)*tf.math.cos(features)*(0.5)
            return dy * activation_grad

        return lower_limit_+((upper_limit_-lower_limit_)*(tf.math.sin(features)+1)*0.5),grad
    
    sinep.__name__='sinep'+str(lower_limit)+'_'+str(upper_limit).replace('.','_')
    return sinep

# tanh activation function with pressure adjustment
def tanhp_func(lower_limit=14.7,upper_limit=5000.):
    @tf.custom_gradient
    def tanhp(features):
        features=tf.convert_to_tensor(features, name='features')
        lower_limit_=tf.convert_to_tensor(lower_limit, dtype=features.dtype, name='lower_limit') 
        upper_limit_=tf.convert_to_tensor(upper_limit, dtype=features.dtype, name='upper_limit') 
        def grad(dy):
            "Gradient for the swish activation function"
            with tf.control_dependencies([dy]):
                activation_grad = (upper_limit_-lower_limit_)*(1-(tf.math.tanh(features))**2)*(0.5)
            return dy * activation_grad

        return lower_limit_+((upper_limit_-lower_limit_)*(tf.math.tanh(features)+1)*0.5),grad
    
    tanhp.__name__='tanhp'+str(lower_limit)+'_'+str(upper_limit).replace('.','_')
    return tanhp

@tf.function
def normalize_diff(model,diff,stat_idx=0,compute=False):
    # Train statistics tensor: INDEX: {'x_coord', 'y_coord', 'z_coord', 'time', 'poro', 'permx', 'permz', 'grate',...}
    #                           KEYS: {'min', 'max', 'mean', 'std', 'count'}
    #                           Nonnormalized function: Linear scaling (a,b)= (xmax-xmin)*((x_norm-a)/(b-a))+xmin
    #                           Nonnormalized function: z-score= (x_norm*xstd)+xmean
    diff=tf.convert_to_tensor(diff, dtype=model.dtype, name='diff')
    
    def _lnk_linear_scaling():
        lin_scale_no_log=((model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0])/(model.ts[stat_idx,1]-model.ts[stat_idx,0]))*diff
        lin_scale_log=((model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0])/tf.math.log(model.ts[stat_idx,1]/model.ts[stat_idx,0]))*tf.math.log(diff)

        return tf.cond(tf.logical_and(tf.math.not_equal(stat_idx,5),tf.math.not_equal(stat_idx,6)),lambda: lin_scale_no_log, lambda: lin_scale_log)

    def _linear_scaling():
        return ((model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0])/(model.ts[stat_idx,1]-model.ts[stat_idx,0]))*diff
    
    def _z_score():
        return (1/model.ts[stat_idx,3])*diff
    
    norm=tf.cond(tf.math.equal(compute,True),lambda: tf.cond(tf.math.equal(model.cfd_type['Input_Normalization'],'linear-scaling'),lambda: _linear_scaling(),lambda: tf.cond(tf.math.equal(model.cfd_type['Input_Normalization'],'lnk-linear-scaling'),lambda: _lnk_linear_scaling(),lambda: _z_score())),lambda: diff)
    
    # Dropsout the derivative in an event of a nan number--when the min and max statistics are constant or standard deviation is zero
    norm=tf.where(tf.logical_or(tf.math.is_nan(norm), tf.math.is_inf(norm)),tf.zeros_like(norm), norm)
    return norm

@tf.function
def normalize(model,nonorm_input,stat_idx=0,compute=False):
    # Train statistics tensor: INDEX: {'x_coord', 'y_coord', 'z_coord', 'time', 'poro', 'permx', 'permz', 'grate',...}
    #                           KEYS: {'min', 'max', 'mean', 'std', 'count'}
    #                           Nonnormalized function: Linear scaling (a,b)= (xmax-xmin)*((x_norm-a)/(b-a))+xmin
    #                           Nonnormalized function: z-score= (x_norm*xstd)+xmean
    nonorm_input=tf.convert_to_tensor(nonorm_input, dtype=model.dtype, name='nonorm_input')
    
    def _lnk_linear_scaling():
        lin_scale_no_log=(((nonorm_input-model.ts[stat_idx,0])/(model.ts[stat_idx,1]-model.ts[stat_idx,0]))*(model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0]))+model.cfd_type['Norm_Limits'][0]
        lin_scale_log=((tf.math.log(nonorm_input/model.ts[stat_idx,0])/tf.math.log(model.ts[stat_idx,1]/model.ts[stat_idx,0]))*(model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0]))+model.cfd_type['Norm_Limits'][0]

        return tf.cond(tf.logical_and(tf.math.not_equal(stat_idx,5),tf.math.not_equal(stat_idx,6)),lambda: lin_scale_no_log, lambda: lin_scale_log)

    def _linear_scaling():
        return (((nonorm_input-model.ts[stat_idx,0])/(model.ts[stat_idx,1]-model.ts[stat_idx,0]))*(model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0]))+model.cfd_type['Norm_Limits'][0]
    
    def _z_score():
        return ((nonorm_input-model.ts[stat_idx,2])/model.ts[stat_idx,3])
    
    norm=tf.cond(tf.math.equal(compute,True),lambda: tf.cond(tf.math.equal(model.cfd_type['Input_Normalization'],'linear-scaling'),lambda: _linear_scaling(),lambda: tf.cond(tf.math.equal(model.cfd_type['Input_Normalization'],'lnk-linear-scaling'),lambda: _lnk_linear_scaling(),lambda: _z_score())),lambda: nonorm_input)
    
    # Dropsout the derivative in an event of a nan number--when the min and max statistics are constant or standard deviation is zero
    norm=tf.where(tf.logical_or(tf.math.is_nan(norm), tf.math.is_inf(norm)),tf.zeros_like(norm), norm)
    return norm