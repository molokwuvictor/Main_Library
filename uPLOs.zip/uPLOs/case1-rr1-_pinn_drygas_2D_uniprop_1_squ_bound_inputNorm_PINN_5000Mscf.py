# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0" #Disable GPU -1: Disable GPU

import tensorflow as tf
tf.config.list_physical_devices('GPU')

import pandas as pd
import numpy as np
import tensorflow_datasets as tfds
from tensorflow import keras
from tensorflow.keras import backend as K
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, BatchNormalization, Lambda
from tensorflow.keras.regularizers import l2
import matplotlib as mpl
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib.colors import LogNorm
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.stats import lognorm

import time
from datetime import datetime
#================================================================================================================================================
# Import aux files
aux_file_path=r'C:\Users\vcm1\Documents\PHD_HW_Machine_Learning\ML_Cases\Main_Library'
import sys; sys.path.insert(0,aux_file_path)
import batch_loss as batch_loss 
import DNN_models as dnn
import training_m as trn
import plot_func as plot_func
#================================================================================================================================================
from pickle import load
open_folder_path=r'C:/Users/vcm1/Documents/PHD_HW_Machine_Learning/ML_Cases/Training_Data/PINN_Data_Dumps'

tf.keras.backend.set_floatx('float64')
#dt_type=tf.float64
full_dom_samp=True
ml_type='DNN'                               # Options: 'random-forest' | 'DNN'
dim_model='/2D'
arr_type=1; aux_layer={'Bu':True,'ko':False}
training_type='nonphysics'
fluid_type='dry-gas'
fluid_comp='mult-comp'
static_prop_type='uni-prop_1'
numeric_type='implicit'

#==============================================================================================================
kfunc='lognormal'                                           # 'linear'|'power'|'lognormal'
nrealz=12  #13 50 30 30 30 20 50
m=2.5                                # The mean of the distribution
sd=1.                               # The standard deviation of the distribution
sigma=np.sqrt(np.log(((sd/m)**2)+1)) # The standard deviation of the unique normal distribution of the log variables
mu=np.log(m)-0.5*sigma**2            # The mean of the unique normal distribution of the log variable 

k=lambda x:1.16**(x)
ks=lambda x:1.15**(x)

if kfunc=='power' : sen_realz_end=int(np.log(k(nrealz-1))/np.log(ks(1)))+1
elif kfunc=='lognormal': sen_realz_end=int(np.log(lognorm.ppf(0.99,sigma,loc=0.,scale=np.exp(mu)))/np.log(ks(1)))+1
    
sen_realz_start=int(1); sen_realz_step=int(5)
train_realz_start=int(0); train_realz_step=int(1)           #1 3 1 3 2 1 2
sen_realz=list(range(sen_realz_start,sen_realz_end,sen_realz_step))    # Realizations to which labels are attached using 10
train_realz=list(range(train_realz_start,nrealz+len(sen_realz),train_realz_step))  
train_realz=sorted(list(set(train_realz)-set(sen_realz)))           
# Note: This excludes the initial timestep t==0 

data_frac=1.0                                      # Fraction of raw data used for surrogate modelling (timestep is used as an indicator)
tstep_samp=10.                                   # Timestep interval at which the training, validation and test data is sampled
train_frac=0.5                                    # Fraction of the data used for training-testing
FVTDS_bool=True                                    # Full Val_Test Data Sampling (FVTDS) 
input_norm='lnk-linear-scaling'                                 # linear-scaling, lnk-linear-scaling, z-score
output_norm=None
lscale={'Min':-1.,'Max':1}
val_data_label=True

nrealz_train=len(train_realz)
open_folder_fullpath = f'{open_folder_path}{dim_model}_{fluid_type.replace("-","").upper()}[{fluid_comp.replace("-","").upper()}_{static_prop_type.replace("-","").upper()}]_K[{kfunc.upper()[:2]}]_ART[{arr_type}_{numeric_type.upper()[:3]}]_SPI[{train_realz_start}_{train_realz_step}_{sen_realz_start}_{sen_realz_step}_{nrealz}]_TRF[{train_frac}_{tstep_samp}D_{data_frac}E]_FVTDS[{str(FVTDS_bool)[0]}]_INPN[{str(input_norm).upper()[0:2]}]_OUTN[{str(output_norm).upper()[0:2]}]'

save_model_folder_path =f'{open_folder_fullpath}/Model_Weights_Biases'
from os import path
if not path.exists(save_model_folder_path):
    os.mkdir(save_model_folder_path)

# Initial Parameters
init_pressure=5000.
init_rate=5000                                                      # Initial rate of well (MScf/D)
min_bhp=100.         #100                                           # Min Bottomhole Pressure (psia)
invBg_t0=1.387723355                                                # Initial Inverse Gas Formation Volume Factor (bbl/MScf)
invug_t0=40.32258065                                                # Initial Inverse Gas Viscosity (cp)
conn_idx=[(14,14,0),]

train_fdata = load(open(f'{open_folder_fullpath}/train_fdata','rb'))
train_fdata_list = load(open(f'{open_folder_fullpath}/train_fdata_list','rb'))
val_fdata_list = load(open(f'{open_folder_fullpath}/val_fdata_list','rb'))
test_fdata_list = load(open(f'{open_folder_fullpath}/test_fdata_list','rb'))
sen_fdata_list = load(open(f'{open_folder_fullpath}/sen_fdata_list','rb'))

train_ldata = load(open(f'{open_folder_fullpath}/train_ldata','rb'))
train_ldata_list = load(open(f'{open_folder_fullpath}/train_ldata_list','rb'))
val_ldata_list = load(open(f'{open_folder_fullpath}/val_ldata_list','rb'))
test_ldata_list = load(open(f'{open_folder_fullpath}/test_ldata_list','rb'))
sen_ldata_list = load(open(f'{open_folder_fullpath}/sen_ldata_list','rb'))

# Polynomial Coefficients for the FVF, Viscosity Model
winvBg=[2.4627480655E-28,-6.4399302767E-23, 5.5094014188E-18,1.2254376244E-13,-5.5167756622E-09,2.8246759702E-04,7.9732737345E-02]
winvug=[5.7142809443E-27,-1.9458761937E-21, 2.5972947014E-16,1.7201966728E-11,5.9074773926E-07,-1.0097825344E-02,7.8921857654E+01]
poly_coeff_Bu={'InvBg':winvBg,'Invug':winvug}

#============================================================BASIC SETTINGS=======================================================================
dnn_arch='cnn2d'#'resn'         # Options: 'plain' | 'resn' | 'lstm' | 'cnn2d'
solution_type='PINN'                      # Options: 'noPINN'|'PINN'

solu_weights=[1.,0.,0.,1.,2.,1.,0.]+[0.,0.]                               #[1.,0.,1.,1.,1.,1.,0.]+[0.,0.] solu_weights (PINN):[1.,0.,1.,1.,1.,1.,1.]+[0.,0.] Last two weights under PINN is the Material Balance and Cumulative Material Balance Checks weight
tstep=tstep_samp                                                          # Time step for the PINN iteration
tstep_fac=1.0
 
leaky_relu=tf.keras.layers.LeakyReLU(alpha=0.01)
olayer_act_func={'p':'linear','s':'linear','phi':'linear','k':'linear','invB':tf.math.abs,'invu':tf.math.abs,'qr':'linear','sl':'linear'}              #tf.keras.layers.ELU(alpha=0.5), {'p':'linear','s':'linear','phi':'linear','k':'linear','invB':'linear','invu':'linear'}
#dnn.hard_limit_func(lower_limit=14.7, upper_limit=5000.)
#dnn.sinep_func(lower_limit=14.7, upper_limit=5000.)

optimizer_type='first-order'                        # Options: 'first-order'|'second-order'
optimizer={'Name':['AdamW'],'Multi':True,'Eps':1e-7,'AmsGrad':False,'LookAhead':True,'Rectify':False,'WarmUp':10000,'WarmUp_Fac':100, 'LookAhead_Step':0.5,'Sync_Period':12}   # Options: 'Adam'|'Adamax'|'SGD'|'Nadam'|'LazyAdam'|'RectAdam'|'AdaBelief'
#optimizer={'Name':['AdaBelief'],'Multi':True,'Eps':1e-7,'AmsGrad':False,'LookAhead':True,'Rectify':False,'WarmUp':10000,'WarmUp_Fac':100, 'LookAhead_Step':0.5,'Sync_Period':6}   # Options: 'Adam'|'Adamax'|'SGD'|'Nadam'|'LazyAdam'|'RectAdam'|'AdaBelief'
accum_grad={'Add':False,'No_Steps':6}                                  # Accumulate the gradients
 
iteration={'Number':1, 'Seq_Ratio':0.1, 'Restarts':{'WBias':False,'LRate':False},'DRate':{'Wt':1.0,'Ep':1.0}} # 0.9 0.7:4; Sequence Ratio is used when the iteration is greater than 1, DRate['Wt'] is used to alter the base value (decline rate) of the weights; DRate['Ep'] for the epoch factor. 
lr_rate=[0.001,0.000,0.001,0.01]                       # [pressure,saturation,pressure-dependent,rate] 0.0005,0.0003,0.0003,0.0005 0.001*10 works for CNN
wt_decay=[50.0e-1,1e-1,1e-1,1e-1]                           # 3.5 (0.0005) 5.5 (0.001) step 80
#wt_decay=dnn.make_rand_variables(initializer='Random_Normal',var_shape=[3],dist_mean=[3.0,3.0,3.0],dist_std=[0.5,0.5,0.5],norm_output=False,var_trainable=False)        # DOM, DBC, NBC, IBC, IC

#decay_type=[{'Type':'constant-exponential','Use_Weight_Decay':'constant-exponential'},{'Type':'exponential','Use_Weight_Decay':'exponential'},{'Type':None,'Use_Weight_Decay':None},{'Type':'constant-exponential','Use_Weight_Decay':'constant-exponential'}]                                     # Options: None | 'constant' | 'exponential' | 'piecewise' | 'tricyclic' | 'expcyclic' | 'None'
decay_type=[{'Type':'exponential','Use_Weight_Decay':'exponential'},{'Type':'exponential','Use_Weight_Decay':'exponential'},{'Type':None,'Use_Weight_Decay':None},{'Type':'exponential','Use_Weight_Decay':'exponential'}]                                     # Options: None | 'constant' | 'exponential' | 'piecewise' | 'tricyclic' | 'expcyclic' | 'None'
if decay_type[0]['Type'] in ['exponential','constant-exponential','cosine-restarts']: lr_rate[0]=lr_rate[0]*10;          # For exponential learning rate, scaled by a factor of 10
if decay_type[1]['Type'] in ['exponential','constant-exponential','cosine-restarts']: 
    for i in range(1,len(lr_rate)-2):lr_rate[i]=lr_rate[i]*10
if decay_type[-2]['Type'] in ['exponential','constant-exponential','cosine-restarts']: lr_rate[-2]=lr_rate[-2]*10;
if decay_type[-1]['Type'] in ['exponential','constant-exponential','cosine-restarts']: lr_rate[-1]=lr_rate[-1]*10;
no_epochs=600
epoch_fac=20                                     # Number of epochs that make up a decay or cyclic step interval
lstacks=28+8 #+10  #24 #28
BS = [841*lstacks,32,841,841,841,841]                       # Training 2Batch size|  2048 used in previous training
rseed=50

exp_decay_wt=dnn.make_rand_variables(initializer='Random_Normal',var_shape=[4],dist_mean=[0.90,0.9,0.9,0.9],dist_std=[0.000,0.000,0.0,0.000],norm_output=False,var_trainable=False)        # DOM, DBC, NBC, IBC, IC

exp_decay_rate_base={'Lr':[0.90,0.9,0.9,0.9],'Wt':exp_decay_wt}  # 'Lr': [0.93,0.90,1.0] [0.9,0.725,1.0],'Wt':[0.9,0.725,1.0] Exponential decay Pressure, Saturation and Visco sity-FVF
cosine_decay_restarts_par={'Tmul':[1.5,1.5,1.5,1.5],'Mmul':[0.85,0.65,0.65,0.65],'Alpha':[0.05,0.05,0.05,0.05]}      # Alpha: 0.05
stair_case=True
exp_decay_rate={'Lr':[0.1,0.1,0.1,0.1],'Wt':[0.07,0.07,0.07,0.07]}                                      # 0.075 Constant-Exponential 0.00005; 0.0004; 0.00013; 0.0037
#decay_ep={'Start_Ep':[0.4,1.0,],'End_Ep':[0.8,1.0,],'Step_Fac':[20,20,]}  
#decay5_ep={'Start_Ep':[0.04,0.625,],'End_Ep':[0.425,0.95,],'Step_Fac':[20,20,],'Decay_Fac':[1,0.5,],'Stair_Case':[True,True,]}                                        # Fraction of total epoch after which exponential decay of the learning starts
decay_ep={'Start_Ep':[0.2,1.0,],'End_Ep':[1.0,1.0,],'Step_Fac':[15,20,],'Decay_Fac':[1.0,1.0,],'Stair_Case':[True,True,]}                                        # Fraction of total epoch after which exponential decay of the learning starts  [0.5 20]


BNPAR={'Use_Batch_Norm_After_Pressure':False,'Momentum':0.9999,'Pre_Rect':{'Use_Pre_Rect':False, 'Act_Func':dnn.hard_limit_func(lower_limit=14.7, upper_limit=5000.,alpha=0.)}}          # Momentum, usually 0.9 - 0.9999                                                                                 # Batch Normalization in Plain Deep Networks
hl_act_func={'ps':tf.nn.swish,'Bu':dnn.act_func_name_wrapper(tf.keras.layers.ELU(alpha=0.5)),'ko':tf.nn.swish,'qr':tf.nn.swish,'sl':tf.nn.swish}
krn={'Init':tf.keras.initializers.GlorotNormal(seed=rseed),'Regu':{'p':None,'sg':None,'so':None,'Bu':None,'phik':None,'qr':None,'sl':None}}

if dnn_arch=='plain' or dnn_arch=='plain2D':
    
    hl_config={'ps':['plain','plain','plain','plain'],'Bu':['plain','plain','plain','plain','plain']}        # 'Bu':['polynomial',6,6,6,6], INDEX: 0 -- FVF and viscosity combined layers; 1 -- Bg layer; 2 -- Bo layer; 3 -- ug layer; 4 -- uo layer
    hl_width={'ps':{'Bottom_Size':30,'No_Gens':[0,5,10,10],'Growth_Type':'cross','Growth_Rate':0.5,'Network_Type':'plain'},'Bu':{'Bottom_Size':32,'No_Gens':[0,2,2,2],'Growth_Type':'smooth','Growth_Rate':1.0,'Network_Type':'plain'}}
    hl_depth={'ps':[0,10,2,2],'Bu':[0,2,2,2,2],\
              'LSTM':{'Add':False,'Units':1,'Activation_Func':'tanh','Recur_Activation_Func':'sigmoid','Bias':True,'Stateful':False},\
              'CNN':{'Add':False,'Type':'1D','Filter':4,'Kernel_Size':3,'Activation_Func':'swish'}}         # Residual Module Parameters for a Deep Residual Network}                                                            # [6,6,12] INDEX: 0 -- p and s combined layers; 1 -- pressure layer; 2 -- gas saturation layer; 3 -- oil saturation layer
    dnn_type=f'PLN-BN[{str(BNPAR["Use_Batch_Norm"]).upper()[0:1]}]-ACF[{hl_act_func["ps"].__name__.upper()[0]}{hl_act_func["ps"].__name__.upper()[-2:]}]-{str(optimizer_type).upper()[0:2]}[{str(optimizer["Name"][0]).upper()[0:2]}{str(optimizer["Name"][0]).upper()[-1]}-M{str(optimizer["Multi"]).upper()[0]}]-LR[{lr_rate[0]}-{exp_decay_rate["Lr"][0]}-{decay_ep["Start_Ep"][0]}]-BS[{BS[0]}]-EP[{no_epochs}]-SPI[{train_realz_start}_{train_realz_step}_{sen_realz_start}_{sen_realz_step}_{nrealz}]-TRF[{train_frac}]-FDS[{str(full_dom_samp).upper()[0]}]'
    input_shape={'Type':'1D','Dim':(1,),'Reshape':(29,29,1),}    
    RMPAR={'Network_Type':'PLN','Batch_Norm':{'Use_Batch_Norm':False,'Before_Activation':True,'Momentum':0.9999},'Dropout':{'Add':False, 'Layer':1*[1]+9*[0]+[0],'Rate':0.1}}                           # Grid block Dimension
else:
    if dnn_arch=='resn':
        hl_config={'ps':['resn','resn','resn','resn'],'Bu':['plain','plain','plain','plain','plain'],'ko':['plain']}   # 
        #hl_config={'ps':['resn','resn','resn','resn'],'Bu':['poly6','poly6','poly6','poly6','poly6'],'ko':['plain']}   #['plain','plain','plain','plain','plain'] 
        hl_width={'ps':{'Bottom_Size':30,'No_Gens':[0,5,10,10],'Growth_Type':'smooth','Growth_Rate':1.0,'Network_Type':'resn'},'Bu':{'Bottom_Size':32,'No_Gens':[0,2,2,2],'Growth_Type':'smooth','Growth_Rate':1.0,'Network_Type':'plain'}}   #0.705; 32-0.91  4 -32 at a growth rate of 2 for 4 gens. hl_width={'Bottom_Size':32,'No_Gens':8,'Growth_Type':'smooth','Growth_Rate':0.825}
        #hl_width={'ps':{'Bottom_Size':30,'No_Gens':[0,5,10,10],'Growth_Type':'cross','Growth_Rate':1.0,'Network_Type':'resn'},'Bu':{'Bottom_Size':32,'No_Gens':[0,2,2,2],'Growth_Type':'smooth','Growth_Rate':1.0,'Network_Type':'plain'}}   #0.705; 32-0.91  4 -32 at a growth rate of 2 for 4 gens. hl_width={'Bottom_Size':32,'No_Gens':8,'Growth_Type':'smooth','Growth_Rate':0.825}
        hl_depth={'ps':[0,10,2,2], 'Bu':[0,2,2,2,2],'ko':4,\
                  'LSTM':{'Add':False,'Units':1,'Activation_Func':'tanh','Recur_Activation_Func':'sigmoid','Bias':True,'Stateful':False},\
                  'CNN':{'Add':False,'Type':'1D','Filter':4,'Kernel_Size':3,'Activation_Func':tf.nn.swish}}         # Residual Module Parameters for a Deep Residual Network}  # dnn.swish_beta(beta=2.0)
        RMPAR={'Network_Type':'RESN','NStacks':[0,5,10,10],'Batch_Norm':{'Use_Batch_Norm':False,'Before_Activation':True,'Momentum':0.9999},\
               'Activation_Func':tf.nn.swish,'Kernel_Init':'glorot_normal','Kernel_Regu':None,'Dropout':{'Add':False, 'Dropout_Stack':[1,1,1],'Rate':[0.,0.,0.5]}}
               
        dnn_type=f'{RMPAR["NStacks"]}REN-BN[{str(RMPAR["Batch_Norm"]["Use_Batch_Norm"]).upper()[0:1]}]-ACF[{RMPAR["Activation_Func"].__name__.upper()[0]}{RMPAR["Activation_Func"].__name__.upper()[-2:]}]-{str(optimizer_type).upper()[0:2]}[{str(optimizer["Name"][0]).upper()[0:2]}{str(optimizer["Name"][0]).upper()[-1]}-M{str(optimizer["Multi"]).upper()[0]}]-LR[{lr_rate[0]}-{exp_decay_rate["Lr"][0]}-{decay_ep["Start_Ep"][0]}]-BS[{BS[0]}]-EP[{no_epochs}]-BS[{BS[0]}]-SPI[{train_realz_start}_{train_realz_step}_{sen_realz_start}_{sen_realz_step}_{nrealz}]-TRF[{train_frac}]-FDS[{str(full_dom_samp).upper()[0]}]'                 # NB: No Batch Normalization; YB: Yes Batch Normalization
        input_shape={'Type':'1D','Dim':(1,),'Reshape':(lstacks,29,29,1)}                               # Grid block Dimension
    elif dnn_arch=='lstm':
        hl_width={'Bottom_Size':48,'No_Gens':8,'Growth_Type':'smooth','Growth_Rate':0.5}   # 4 -32 at a growth rate of 2 for 4 gens. hl_width={'Bottom_Size':32,'No_Gens':8,'Growth_Type':'smooth','Growth_Rate':0.825}
        RMPAR={'Network_Type':'LSTM','NStacks':8,'Batch_Norm':{'Use_Batch_Norm':False,'Before_Activation':True,'Momentum':0.9999},'Activation_Func':tf.nn.tanh,'Add_Dense_Inbetween_LSTM':True,'LSTM_Activation_Func':'sigmoid'}          # Residual Module Parameters for a Deep Residual Network
        dnn_type=f'{RMPAR["Network_Type"]}-DB[{str(RMPAR["Add_Dense_Inbetween_LSTM"]).upper()[0:1]}]-ACF[{RMPAR["Activation_Func"].__name__.upper()[0]}{RMPAR["Activation_Func"].__name__.upper()[-2:]}]-{str(optimizer_type).upper()[0:2]}[{str(optimizer["Name"][0]).upper()[0:2]}{str(optimizer["Name"][0]).upper()[-1]}-M{str(optimizer["Multi"]).upper()[0]}]-LR[{lr_rate[0]}-{exp_decay_rate["Lr"][0]}-{decay_ep["Start_Ep"][0]}]-BS[{BS[0]}]-EP[{no_epochs}]-BS[{BS[0]}]-SPI[{train_realz_start}_{train_realz_step}_{sen_realz_start}_{sen_realz_step}_{nrealz}]-TRF[{train_frac}]-FDS[{str(full_dom_samp).upper()[0]}]'                                   # ND: No Dense between layers
        input_shape={'Type':'1D','Dim':(1,)}  
    elif dnn_arch=='cnn2d':
        hl_config={'ps':['cnn2d','cnn2d','resn','resn'],'Bu':['poly6','poly6','poly6','poly6','poly6'],'ko':['plain'],'qs':['plain','plain']}  
        hl_width={'ps':{'Bottom_Size':32,'No_Gens':[0,5,10,10],'Growth_Type':'smooth','Growth_Rate':2.0},'Bu':{'Bottom_Size':32,'No_Gens':[0,2,2,2],'Growth_Type':'smooth','Growth_Rate':1.0,'Network_Type':'plain'},\
                  'qs':{'Bottom_Size':2,'No_Gens':[4,4],'Growth_Type':'smooth','Growth_Rate':1.0}}  # 4 -32 at a growth rate of 2 for 4 gens. hl_width={'Bottom_Size':32,'No_Gens':8,'Growth_Type':'smooth','Growth_Rate':0.825}
        hl_depth={'ps':[0,3,0,0], 'Bu':[0,2,2,2,2],'qs':[0,0],'LSTM':{'Add':False},'CNN':{'Add':False,'Type':'1D'}}          # RMPAR: Skip connection list corresponds to depth
        RMPAR={'Network_Type':'CNN2D','NStacks':[0,5,2,2],'Kernel_Size':3,'Kernel_Init':krn['Init'],'Kernel_Regu':krn['Regu'],'Batch_Norm':{'Use_Batch_Norm':False,'Before_Activation':True,'Momentum':0.99,'Type':'batch'},\
               'Dropout':{'Add':False, 'Layer':[1,1,1,0],'Rate':0.05},'Activation_Func':tf.nn.swish, 'Out_Activation_Func':olayer_act_func['p'],'Skip_Connections':{'Add':[True,True,True,],'Layers':[[1,1,1,1],[0,0,0,0],[0,0,0,0]],'Add_Input':[False,False,False]},\
                 'Decoder_Filter_Fac':1.,'Dense_Latent_Layer': {'Flatten':False,'Depth':1,'Width':128,'Growth_Rate':1.0,'Growth_Type':'cross','Skip_Conn':False,'NStacks':[1,1,1],'Activation':tf.nn.swish}}          # Residual Module Parameters for a Deep Residual Network; Normalization Type: batch or layer
        dnn_type=f'{RMPAR["Network_Type"]}-LSTM[{str(hl_depth["LSTM"]).upper()[0:1]}]-ACF[{RMPAR["Activation_Func"].__name__.upper()[0]}{RMPAR["Activation_Func"].__name__.upper()[-2:]}]-{str(optimizer_type).upper()[0:2]}[{str(optimizer["Name"][0]).upper()[0:2]}{str(optimizer["Name"][0]).upper()[-1]}-M{str(optimizer["Multi"]).upper()[0]}]-LR[{lr_rate[0]}-{exp_decay_rate["Lr"][0]}-{decay_ep["Start_Ep"][0]}]-BS[{BS[0]}]-EP[{no_epochs}]-BS[{BS[0]}]-SPI[{train_realz_start}_{train_realz_step}_{sen_realz_start}_{sen_realz_step}_{nrealz}]-TRF[{train_frac}]-FDS[{str(full_dom_samp).upper()[0]}]'                                   # ND: No Dense between layers
        input_shape={'Type':'2D','Dim':(29,29,1),'Reshape':(29,29,1),'Reshape_Func':tf.transpose}                               # Grid block Dimension
        BS = [int(tf.math.divide(lstacks,1)),32,32,32,32,32] #[nrealz_train]*6                       # Training Batch size|  2048 used in previous training

# Tensorboard callback
logdir="logs/fit/" + datetime.now().strftime("%Y%m%d-%H%M%S")
#tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=logdir)
tensorboard_callback=[]
#=================================================================================================================================================
# Define the batch generator for feeding the neural network
# Batch sizes for the training data is given by: BS=[] ==> DOM,DBC,NBC,IBC,IC,TD
# Create the input and dataset lists
val_input_shape={'Type':'2D','Dim':(29,29,1)}
BS_val=np.prod(val_input_shape['Dim'])*2
nrealz_val=len(sen_realz)

xdataset=[train_fdata_list];
ydataset=[train_ldata_list]
#=================================================================================================================================================
# Get the statistics (e.g., mean, std, etc.) of the training data.  

columns_stats=['min','max','mean','std','count']
index_lstats=[]

index_fstats=['x_coord','y_coord','z_coord','time','poro','permx','permz']
index_lstats=index_lstats+['pressure','gsat','grate','cum_gprod']

ts_f=train_fdata.describe().transpose().loc[index_fstats,columns_stats]
ts_l=train_ldata.describe().transpose().loc[index_lstats,columns_stats]
ts=[tf.concat([ts_f,ts_l],axis=0),(index_fstats+index_lstats),columns_stats]
#=================================================================================================================================================

#Building model function    Note: methods are supposed to be associated with the instance of a class as against a function
def nophy_ANN_Model(train_stats=None,input_shape=None, width=None, depth={},config={}, kernel=None, hlayer_activation_func={}, olayer_activation_func={}, batch_norm={}, residual_module_par={}, cfd_type={}):
    # Set the ANN at input --special input arguments for x, y, z and t   to ease Automatic Differentiation
    
    x = tf.keras.Input(shape=input_shape, name='x_coord') 
    y = tf.keras.Input(shape=input_shape, name='y_coord') 
    z = tf.keras.Input(shape=input_shape, name='z_coord') 
    t = tf.keras.Input(shape=input_shape, name='time') 
    phi = tf.keras.Input(shape=input_shape, name='poro') 
    kx = tf.keras.Input(shape=input_shape, name='permX')
    kz = tf.keras.Input(shape=input_shape, name='permZ') 
    
    # Bg = tf.keras.Input(shape=input_shape, name='gas_FVF')
    # Bo = tf.keras.Input(shape=input_shape, name='oil_FVF') 
    # ug = tf.keras.Input(shape=input_shape, name='gas_visc') 
    # uo = tf.keras.Input(shape=input_shape, name='oil_visc') 
    
    qg = tf.keras.Input(shape=input_shape, name='grate_inp')
    qo = tf.keras.Input(shape=input_shape, name='orate_inp') 
    
    # Add grid block dimensions and harmonic average capacity (kh)-- needed for computing the IBC
    dx = tf.keras.Input(shape=input_shape, name='dx') 
    dy = tf.keras.Input(shape=input_shape, name='dy') 
    dz = tf.keras.Input(shape=input_shape, name='dz') 
    
    # Add labels for the Domain, DBC, NBC, IBC, IC and Train + Train Lb2
    input_shape_1=tf.cond(tf.math.logical_or(tf.math.equal(cfd_type['DNN_Arch'],'cnn2d'),tf.math.equal(cfd_type['DNN_Arch'],'plain2d')),lambda:(*input_shape,2),lambda:(2,))
    label = tf.keras.Input(shape=input_shape_1, name='Train_label')  

    coord=tf.cond(tf.math.equal(cfd_type['DNN_Arch'],'conn2d'),lambda: tf.cond(tf.math.equal(cfd_type['Dimension']['Type'],'2D'),lambda:[],lambda: []),lambda: tf.cond(tf.math.logical_or(tf.math.equal(cfd_type['Dimension']['Type'],'1D'),tf.math.equal(cfd_type['Dimension']['Type'],'2D')),lambda:[x,y],lambda: [x,y,z]))  # lambda : [x,y]

    concat_inputs=tf.cond(tf.math.logical_or(tf.math.equal(cfd_type['Dimension']['Type'],'1D'),tf.math.equal(cfd_type['Dimension']['Type'],'2D')),lambda: tf.cond(tf.math.equal(cfd_type['Data_Arr'],0),\
                                                        lambda: tf.cond(tf.math.equal(cfd_type['Fluid_Type'],'dry-gas'),\
                                                lambda: tf.keras.layers.Concatenate(axis=-1)(coord+[t,phi,kx]+[qg]),\
                                        lambda: tf.keras.layers.Concatenate(axis=-1)(coord+[t,phi,kx]+[qg,qo])),\
                                lambda: tf.keras.layers.Concatenate(axis=-1)(coord+[t,kx])),\
                                        lambda: tf.cond(tf.math.equal(cfd_type['Data_Arr'],0),\
                                                lambda: tf.cond(tf.math.equal(cfd_type['Fluid_Type'],'dry-gas'),\
                                                        lambda: tf.keras.layers.Concatenate(axis=-1)(coord+[t,phi,kx,kz]+[qg]),\
                                                                lambda: tf.keras.layers.Concatenate(axis=-1)(coord+[t,phi,kx,kz]+[qg,qo])),\
                                                                        lambda: tf.keras.layers.Concatenate(axis=-1)(coord+[t,phi,kx,kz])))    
                                                                                   # [Bg,Bo,ug,uo,qg,qo]

    outputs_=dnn.plain_modular_model(cfd_type=cfd_type,inputs=concat_inputs,width=width,depth=depth,config=config,kernel=kernel, hlayer_activation_func=hlayer_activation_func,\
                                     olayer_activation_func=olayer_activation_func, batch_norm=batch_norm, residual_module_par=residual_module_par,poly_coeff_Bu=poly_coeff_Bu,grid_dim=[dx,dy,dz],train_stats=ts)

    inputs_=tf.cond(tf.math.equal(cfd_type['Data_Arr'],0),lambda: tf.cond(tf.math.equal(cfd_type['Fluid_Type'],'dry-gas'),\
                                                lambda: [x,y,z,t,phi,kx,kz,qg,dx,dy,dz,label],\
                                        lambda: [x,y,z,t,phi,kx,kz,qg,qo,dx,dy,dz,label]),\
                                                lambda: [x,y,z,t,phi,kx,kz,dx,dy,dz,label])
    # Add a Lambda Layer to compute the BHP for PINN network
    model=tf.cond(tf.math.equal(cfd_type['Separate_Models'],True),lambda: [dnn.pinn_Model(train_stats,cfd_type,inputs=inputs_, outputs=(outputs_[i],), name=cfd_type['Type']) for i in range(len(outputs_))],\
                  lambda:dnn.pinn_Model(train_stats,cfd_type,inputs=inputs_, outputs=outputs_, name=cfd_type['Type']))
    # Inspect  model
    #[model[i].summary() for i in range(len(model))]
    return model
# Build the model
# Build the model
model=nophy_ANN_Model(train_stats=ts,input_shape=input_shape['Dim'],width=hl_width,depth=hl_depth,config=hl_config,\
                      kernel=krn,hlayer_activation_func=hl_act_func,olayer_activation_func=olayer_act_func,batch_norm=BNPAR, residual_module_par=RMPAR,\
                      cfd_type={'Type':solution_type,'Fluid_Type':fluid_type,'Dimension':input_shape,'Input_Normalization':input_norm,'Output_Normalization':output_norm,'Norm_Limits':list(lscale.values()),\
                                'PINN_Activation_RMSE':3000.0,'Gradient_Norm':100000,'Train_Data':False,'Val_Data_Label':val_data_label,'Data_Arr':arr_type,'Solu_Weights':solu_weights,'Pi':init_pressure,'Init_Grate':init_rate,\
                                'Min_BHP':min_bhp,'Init_InvBg':invBg_t0,'Init_Invug':invug_t0,'Timestep':tstep,'Timestep_Fac':tstep_fac,'Init_Timestep_Fac':0.1,'K_Timestep':5.0,'Timestep_Log_Fac':4.,'Max_Train_Time':270.,'Conn_Idx':conn_idx,'Seed':rseed,\
                                'Spatial_DSampling':None,'Separate_Models':False,'DNN_Type':dnn_type,'DNN_Arch':dnn_arch,'Aux_Layer':aux_layer,'Accum_Grad':accum_grad,'Optimizer':optimizer_type})
#Depth in nophy_ANN_Model func doesnt include the output layer 
model.summary()

# Update the 'Bu' layers with pretrained weights and biases
# PVT File: Use file if a DNN PVT auxillary network exists
if hl_config['Bu'][0][:4]!='poly':
    pvt_open_folder_path=r'C:/Users/vcm1/Documents/PHD_HW_Machine_Learning/ML_Cases/Training_Data/PINN_Data_Dumps'
    pvt_arr_type=3
    pvt_save_model_folder_path = f'{pvt_open_folder_path}{dim_model}_PVTMODEL[{fluid_type.replace("-","").upper()}]_ART[{pvt_arr_type}]/Model_Weights_Biases'
    plot_func.load_model_weights(model,pvt_save_model_folder_path,dname=hl_depth['Bu'],layer_wise=True,use_dnn_type=False) 

#sys.exit()
#=================================================================================================================================================
# Train the sub NN simultaneously. Create the batch generator
BG=trn.batch_generator(xdataset,ydataset,batch_size=BS,shape=len(BS)*[input_shape['Dim']],reshape=input_shape['Reshape'],reshuffle_data=True,no_perturbations=nrealz_train,seed=rseed)
BG_val=trn.batch_generator([val_fdata_list],[val_ldata_list],batch_size=[BS[0]*2],shape=[input_shape['Dim']],no_perturbations=None)

# Sets the model's number of batches for gradient accumulation
if isinstance(model,list):
    model[0].n_grad_steps=accum_grad['No_Steps']
else:
    model.n_grad_steps=accum_grad['No_Steps']
#===================================================================================================================================================
if model.cfd_type['Optimizer']=='first-order':
    # Train using the Adaptive Estimation of Moments (ADAM) optimizer
    # train_ensembles(model=model,no_iter=1,batch_xy=BG,epochs_=200,learning_rate_=0.001,lr_decay_start=0.1,validation_data_=val_data, verbose_=1, callbacks_=[adaptiveRegularizer,tf.keras.callbacks.LearningRateScheduler])  #validation_split can be used when the split fraction is known
    trn.train_ensembles(model=model,iteration=iteration,batch_xy=BG,optimizer=optimizer,lrate={'Init_Rate':lr_rate,'Decay_Type':decay_type,'Decay_Weight':wt_decay,'Decay_Ep':decay_ep,'Exp_Decay_Rate':exp_decay_rate,'Exp_Decay_Rate_Base':exp_decay_rate_base,'Cosine_Decay_Restarts_Par':cosine_decay_restarts_par,'Stair_Case':stair_case,'Epoch_Fac':epoch_fac,'Epochs':no_epochs,'Saved_Epochs':0.25},validation_data_=BG_val, validation_steps_=len(BG_val),verbose_=1, callbacks_=[trn.adaptiveRegularizer,tf.keras.callbacks.LearningRateScheduler,tensorboard_callback])  #validation_split can be used when the split fraction is known
#===============================================================================================================================
if model.cfd_type['Optimizer']=='first-order':
    plot_func.plot_history(model,func=None,dname=hl_depth['ps'],tr_time=None)

#===============================================================================================================================
#Evaluaion with the standalone Keras accuracy class
#pred_ldata=model.predict(test_dom_fdata_list)  #use type() tc check datatype--it's a list of ndarrays

#plot_func.save_model_weights(model,save_model_folder_path,dname=hl_depth['ps']) 
#plot_func.load_model_weights(model,save_model_folder_path,dname=hl_depth['ps'])
#lbl_plt=['ResNet: Without Regularization','ResNet: With Regularization','FCDNN: Without Regularization','FCDNN: With Regularization']
#plot_func.plot_files(folder_path=save_model_folder_path,plot_key=['td_loss_p','val_loss'],label=lbl_plt,use_label=False)
#===============================================================================================================================
# Launch tensorboard
# %load_ext tensorboard
# %tensorboard --logdir logs
#===============================================================================================================================
def change_wbt(loss_no=None):       #zero-based
    idx=model.wbl_epoch[0]['epoch'].index(loss_no)
    model.set_weights(model.wbl_epoch[0]['weight_bias'][idx])
    _,_,_=plot_func.predict_range_score(model, obs_fdata=test_fdata_list, obs_ldata=test_ldata_list)
    return

 
nrealz_test=len(sen_realz)

if fluid_type=='dry-gas':
    output_keys=['Pressure','Gas Saturation']
else:
    output_keys=['Pressure','Gas Saturation','Condensate Saturation']
    
if dnn_arch!='cnn2d':
    plot_func.img_plot(model,obs_fdata=test_fdata_list, obs_ldata=test_ldata_list, plot_title=output_keys,tstep_idx=[0,10,20,40,80],timestep=tstep_samp,no_perturbations=nrealz_test)
    avg_pred_ldata,avg_obs_ldata=plot_func.predict_plot_avgout(model, obs_fdata=test_fdata_list,obs_ldata=test_ldata_list,output_keys=output_keys,no_perturbations=nrealz_test)
    well_pred_ldata,well_obs_ldata,mae=plot_func.predict_plot_wells(model, obs_fdata=test_fdata_list,obs_ldata=test_ldata_list,wells_idx=[(14,14,1)],output_keys=output_keys,no_perturbations=nrealz_test,plot_range=[0,1,2,3,4,5])

    avg_sen_pred_ldata,avg_sen_obs_ldata,mae=plot_func.predict_plot_avgout(model, obs_fdata=sen_fdata_list,obs_ldata=sen_ldata_list,output_keys=output_keys,no_perturbations=nrealz_test,plot_range=[0,1,2,3])
    well_sen_pred_ldata,well_sen_obs_ldata,mae=plot_func.predict_plot_wells(model, obs_fdata=sen_fdata_list,obs_ldata=sen_ldata_list,wells_idx=[(14,14,1)],output_keys=output_keys,no_perturbations=nrealz_test,plot_range=[0,1,2,3])
    plot_func.img_plot_2D(model,obs_fdata=sen_fdata_list, obs_ldata=sen_ldata_list, plot_title=output_keys,tstep_idx=[0,10,20,40,80],timestep=tstep_samp,no_perturbations=nrealz_test)

else:
    # Set a batch size to use the batch generator for plotting 2D results
    batch_size_test=int(len(test_fdata_list[0])/(np.prod(input_shape['Dim'])*nrealz_test))
    batch_size_sen=int(len(sen_fdata_list[0])/(np.prod(input_shape['Dim'])*nrealz_test))
    BG_test=trn.batch_generator([test_fdata_list],[test_ldata_list],batch_size=[batch_size_test],shape=[input_shape['Dim']],data_type='test',no_perturbations=nrealz_test)
    BG_sen=trn.batch_generator([sen_fdata_list],[sen_ldata_list],batch_size=[batch_size_sen],shape=[input_shape['Dim']],data_type='test',no_perturbations=nrealz_test)

    avg_pred_ldata,avg_obs_ldata,mae=plot_func.predict_plot_avgout_2D(model, BG_test,output_keys=['pressure'],no_perturbations=nrealz_test,perm=[1.15,2.31,4.65],xy_label_size=9.0)
    avg_pred_ldata,avg_obs_ldata,mae=plot_func.predict_plot_avgout_2D(model, BG_sen,output_keys=['pressure'],no_perturbations=nrealz_test,perm=[1.15,2.31,4.65],xy_label_size=9.0)

    plot_func.img_plot_2D(model, BG_test,plot_title=['Pressure'],timestep=[330,tstep],no_perturbations=nrealz_test,max_error=5.,perm=[1.15,2.31,4.65],xy_label_size=8.0)
    well_pred_ldata,well_obs_ldata,mae=plot_func.predict_plot_wells_2D(model,BG_sen,tstep=10,tstep_idx=[0,20,40,60],bound_int=50,wells_idx=[(14,14,0)],plot_title=['Pressure'],no_perturbations=6,perm=[1.15,2.31,4.65],xy_label_size=9.0)

#_,_,_=predict_range_score(model, obs_fdata=test_dom_fdata_list, obs_ldata=test_dom_ldata_list)
#avg_pred_ldata,avg_obs_ldata=predict_plot_avgout(model, obs_fdata=test_dom_fdata_list,obs_ldata=test_dom_ldata_list,no_perturbations=nrealz_train)
#img_plot(obs_fdata=test_dom_fdata_list,obs_ldata=test_dom_ldata_list, cum_tstep=0)   
   


        
 
           
 
    