# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 14:22:44 2021

@author: User
"""
import os
import batch_loss
os.environ["CUDA_VISIBLE_DEVICES"] = "-1" #Disable GPU: -1

import tensorflow as tf

