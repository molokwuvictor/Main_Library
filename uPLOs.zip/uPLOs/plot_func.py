# -*- coding: utf-8 -*-
"""
Created on Tue Nov 16 21:15:06 2021

@author: User
"""

import os
import batch_loss
os.environ["CUDA_VISIBLE_DEVICES"] = "-1" #Disable GPU: -1

import pandas as pd
import numpy as np
import tensorflow as tf
import matplotlib as mpl
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib.colors import LogNorm
import matplotlib.pyplot as plt

def plot_history(model,func=None,dname=None,tr_time=None):
    if model.cfd_type['Optimizer']=='first-order':
        tr_loss=model.history_ens[model.best_ens]
        dic_keys_list=list(tr_loss)
        for i in range(0,len(dic_keys_list)):
            if dic_keys_list[i]=='val_loss':
                plt.plot(tr_loss[dic_keys_list[i]], label='MSE: '+dic_keys_list[i],linewidth=2.0)
                continue
            plt.plot(tr_loss[dic_keys_list[i]], label='MSE: '+dic_keys_list[i])
                
        # Prints the best epoch using the saved best model parameters
        best_epoch=model.wblt_epoch_ens[model.best_ens]['epoch']
        total_ens_train_time=sum([model.wblt_epoch_ens[j]['train_time'] for j in range(len(model.wblt_epoch_ens))])/60.
        best_ens_train_time=model.wblt_epoch_ens[model.best_ens]['train_time']/60.
        
        str1=model.cfd_type['DNN_Type'][0:int((3/5)*len(model.cfd_type['DNN_Type']))]
        str2=model.cfd_type['DNN_Type'][int((3/5)*len(model.cfd_type['DNN_Type'])):]
        if tr_time==None:
            train_time_text='Total ens. training time: {:.2f} mins \nBest ens. training time: {:.2f} mins \nBest epoch: {}  Best ens.: {} \nHLayer config.: {}\n{}'.\
            format(total_ens_train_time,best_ens_train_time,best_epoch+1,model.best_ens+1,str(dname)+'-'+str1,str2)
        else:
            train_time_text='Total ens. training time: {:.2f} mins \nBest ens. training time: {:.2f} mins \nBest epoch: {}  Best ens.: {} \nHLayer config.: {}\n{}'.\
            format(tr_time,tr_time,best_epoch+1,model.best_ens+1,str(dname)+'-'+str1,str2)

    else:
        labels_list=func.hist_loss['loss_keys']
        tr_loss=func.hist_loss['loss_values']
        for i in range(0,len(tr_loss[0])):
        # Plot history: MSE
            if labels_list[i]=='loss':
                plt.plot([tr_loss[j][i] for j in range(len(tr_loss))], label='MSE: '+labels_list[i])      # linewidth=2.0, color='black', zorder=len(tr_loss)-1
                continue       
            plt.plot([tr_loss[j][i] for j in range(len(tr_loss))], label='MSE: '+labels_list[i])
        # Print the total train time on plot
        train_time_text='Total ens. training time: {:.2f} mins'.\
        format(tr_time)
    axis=plt.gca()
    plt.text(0.525, 0.90,train_time_text, size=7.0, ha='center', va='center', transform=axis.transAxes, zorder=100)
    try:
        fldr_name=os.path.basename(__file__)[0:4]
    except:
        fldr_name=''
    plt.title(fldr_name+'_MSE for Non Physics-Informed Training')
    plt.ylabel('MSE value')
    plt.xlabel('No. Iterations/Epoch')
    plt.yscale('log')
    plt.legend(loc="upper left",  prop={'size': 8},ncol=1,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(1, 1))  
    plt.rc('grid', linestyle="--", color='grey',linewidth=0.5)
    plt.grid(True)
   
    plt.show()

#===============================================================================================================================
#Evaluaion with the standalone Keras accuracy class
#pred_ldata=model.predict(test_dom_fdata_list)  #use type() tc check datatype--it's a list of ndarrays

def predict_range_score(model=None, obs_fdata=None,obs_ldata=None):
    # Both observed features and labels are lists of input and output parameters respectively
    if model.cfd_type['Data_Arr']==2:
        output_keys=['pressure','sbu_gas','sbu_oil']
    else:
        output_keys=['pressure','sgas','soil']
    
    if model.cfd_type['Optimizer']=='first-order':
        # Prediction with the model using the test data
        score=model.evaluate(obs_fdata,obs_ldata,verbose=1)
        print(score)
    
    mae={key:[] for key in output_keys}
    def abs_error(x_pred,x_obs):
        return tf.math.abs((x_pred-x_obs)/x_obs)
    #Evaluaion with the standalone Keras accuracy class
    pred_ldata=model.predict(obs_fdata)  #use type() tc check datatype--it's a list of ndarrays 
    
    print('Pred. {}  Observed {}  ==  Predicted {}  Observed {}  ==  Predicted {}  Observed {}\n'\
          .format(output_keys[0],output_keys[0],output_keys[1],output_keys[1],output_keys[2],output_keys[2]))
    for i in range(0,len(pred_ldata[0]),int(len(pred_ldata[0])/30)):
        for j in range(3):
            mae[output_keys[j]].append(abs_error(pred_ldata[j][i],obs_ldata[j][i]))
        print(pred_ldata[0][i], ' ', obs_ldata[0][i],'==', pred_ldata[1][i], ' ', obs_ldata[1][i],'==',pred_ldata[2][i], ' ', obs_ldata[2][i] )
       
    nonorm_obs_ldata=[]
    nonorm_pred_ldata=[]
    if model.cfd_type['Output_Normalization']!=None:
        a=model.cfd_type['Norm_Limits'][0]
        b=model.cfd_type['Norm_Limits'][1]
        ts=pd.DataFrame(model.ts.numpy(),index=model.ts_idx_keys[0],columns=model.ts_idx_keys[1])
        mae={key:[] for key in output_keys}
        for key in output_keys:
            if model.cfd_type['Output_Normalization']=='linear-scaling':
                nonorm_obs=((obs_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
                nonorm_pred=((pred_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
            else:
                nonorm_obs=obs_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
                nonorm_pred=pred_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
            nonorm_obs_ldata.append(nonorm_obs)
            nonorm_pred_ldata.append(nonorm_pred)
        
        # Output un normalized values to console
        print('\n**********NON NORMALIZED VALUES**********\n\
              Pred. {}  Observed {}  ==  Predicted {}  Observed {}  ==  Predicted {}  Observed {}\n'\
                  .format(output_keys[0],output_keys[0],output_keys[1],output_keys[1],output_keys[2],output_keys[2]))
        for i in range(0,len(nonorm_pred_ldata[0]),int(len(nonorm_pred_ldata[0])/20)):
            for j in range(3):
                mae[output_keys[j]].append(abs_error(nonorm_pred_ldata[j][i],nonorm_obs_ldata[j][i]))
            print(nonorm_pred_ldata[0][i], ' ', nonorm_obs_ldata[0][i],'==', nonorm_pred_ldata[1][i], ' ', nonorm_obs_ldata[1][i],'==', nonorm_pred_ldata[2][i], ' ', nonorm_obs_ldata[2][i])
    
    print(f'MAE {output_keys[0]}: {tf.math.reduce_mean(mae[output_keys[0]])}\nMAE {output_keys[1]}: {tf.math.reduce_mean(mae[output_keys[1]])}\nMAE {output_keys[2]}: {tf.math.reduce_mean(mae[output_keys[2]])}')
    return pred_ldata, nonorm_obs_ldata, nonorm_pred_ldata

# Predict range of test data and the score

#predict_range_score(model, obs_fdata=test_dom_fdata_list, obs_ldata=test_dom_ldata_list)

def predict_plot_avgout(model=None, obs_fdata=None,obs_ldata=None,shape=(29,29),bound_int=50,output_keys=['Pressure','Gas Saturation','Condensate Saturation'],output_colours=['lightcoral','limegreen','orange'],output_linestyles=['dashed','dotted','dashdot'],no_perturbations=6,plot_range=[0,1,2,3,4,5]):
    def abs_error(x_pred,x_obs):
        return tf.math.abs((x_pred-x_obs)/x_obs)
    full_shape=(no_perturbations,-1,*shape)
    import time
    start_time=time.time()
    pred_ldata=model.predict(obs_fdata)
    end_time=time.time()
    tr_time=print((end_time-start_time))
    # Un normalize if outputs are normalized prior to training
    if model.cfd_type['Output_Normalization']!=None:
        a=model.cfd_type['Norm_Limits'][0]
        b=model.cfd_type['Norm_Limits'][1]
        ts=pd.DataFrame(model.ts.numpy(),index=model.ts_idx_keys[0],columns=model.ts_idx_keys[1])
        for key in output_keys:
            if model.cfd_type['Output_Normalization']=='linear-scaling':
                 nonorm_pred=((pred_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
                 nonorm_obs=((obs_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
            else:
                nonorm_pred=pred_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
                nonorm_obs=obs_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
            pred_ldata[output_keys.index(key)]=nonorm_pred
            obs_ldata[output_keys.index(key)]=nonorm_obs
    
    nonflat_pred_ldata=[np.reshape(pred_ldata[i],full_shape) for i in range(len(output_keys))]
    nonflat_obs_ldata=[np.reshape(obs_ldata[i],full_shape) for i in range(len(output_keys))]
    
    avg_pred_ldata=[]
    avg_obs_ldata=[]
    mae=[]
    # Using the weighted volume to determine the average pressure, gas and condensate saturations
    # Porosity is index index 4
    nonflat_phi=np.reshape(obs_fdata[4],full_shape)
    
    # Un normalized the porosity values as inputs are always normalized
    # Training statistics column: ['min','max','mean','std','count']
    if model.cfd_type['Input_Normalization']=='linear-scaling':
        a=model.cfd_type['Norm_Limits'][0]
        b=model.cfd_type['Norm_Limits'][1]
        phi_min=model.ts[4,0]
        phi_max=model.ts[4,1]
        nonorm_nonflat_phi=((nonflat_phi-a)/float(b-a))*(phi_max-phi_min)+phi_min
    elif model.cfd_type['Input_Normalization']=='z-score':
        phi_mean=model.ts[4,2]
        phi_std=model.ts[4,3]
        nonorm_nonflat_phi=nonflat_phi*phi_std+phi_mean
    
    for i in range(nonflat_pred_ldata[0].shape[0]):
        avg_pred_ldata_per_pert={key:[] for key in output_keys}
        avg_obs_ldata_per_pert={key:[] for key in output_keys}
        for j in range(nonflat_pred_ldata[0].shape[1]):
            for k in range(len(output_keys)):
                # Volumetric weighted average
                avg_pred_ldata_per_pert[output_keys[k]].append(np.sum(nonflat_pred_ldata[k][i,j,:,:]*nonorm_nonflat_phi[i,j,:,:])/np.sum(nonorm_nonflat_phi[i,j,:,:]))
                avg_obs_ldata_per_pert[output_keys[k]].append(np.sum(nonflat_obs_ldata[k][i,j,:,:]*nonorm_nonflat_phi[i,j,:,:])/np.sum(nonorm_nonflat_phi[i,j,:,:]))
        avg_pred_ldata.append(avg_pred_ldata_per_pert)  
        avg_obs_ldata.append(avg_obs_ldata_per_pert) 
        
    # Print output on screen
    print('Pred_Avg {}  Obs_Avg {}  ==  Pred_Avg {}  Obs_Avg {}\n'\
          .format(output_keys[0],output_keys[0],output_keys[1],output_keys[1]))
   
    for i in range(len(avg_pred_ldata)):
        mae_per_pert={key:[] for key in output_keys}
        for j in range(0,len(avg_pred_ldata[i][output_keys[0]]),int(np.ceil(len(avg_pred_ldata[i][output_keys[0]])*0.1))):
            for k in output_keys:
                mae_per_pert[k].append(abs_error(avg_pred_ldata[i][k][j],avg_obs_ldata[i][k][j]))
            print(avg_pred_ldata[i][output_keys[0]][j], ' ', avg_obs_ldata[i][output_keys[0]][j],'==', avg_pred_ldata[i][output_keys[1]][j], ' ', avg_obs_ldata[i][output_keys[1]][j] )
        mae.append(mae_per_pert)
    
    for i in range(len(mae)):
        print(f'MAE {output_keys[0]}: {tf.math.reduce_mean(mae[i][output_keys[0]])}\nMAE {output_keys[1]}: {tf.math.reduce_mean(mae[i][output_keys[1]])})')

    # Plot the predicted and observed averages for all the metrics
        # Create the subplots
    plt_height=len(len(avg_pred_ldata))
    plt_width=2+(len(avg_pred_ldata)-1)
    fig, ax = plt.subplots(plt_height,plt_width)
    fig.subplots_adjust(left=0.02, bottom=0.06, right=0.95, top=0.95, hspace=0.95, wspace=0.4)
    fig.suptitle('Average '+', '.join(output_keys),fontsize=8,y=1.02,weight='bold')
    
    for i in range(len(plot_range)):
        for j in range(len(output_keys)):
            ax[i,j].plot(avg_pred_ldata[plot_range[i]][output_keys[j]], label='Predicted Average '+output_keys[j], color='#0343DF', linestyle=output_linestyles[j],linewidth=1.5,zorder=100)      # Color azure
            ax[i,j].plot(avg_obs_ldata[plot_range[i]][output_keys[j]], label='Observed Average '+output_keys[j], linestyle='', marker='s', markerfacecolor=output_colours[j],markeredgecolor='#A9561E',markersize=4,markeredgewidth=0.75) #CB9978 #A9561E
            
            if i==0:
                ax[i,j].set_title(f'Avg. {output_keys[j][0:5]}, Realiz.({i+1})',fontsize=7.5, y=0.95)
                if j==2:
                    fig.legend(loc="upper left",  prop={'size': 6},ncol=3,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -0.01))  
            else:
                ax[i,j].set_title(f'Realiz. ({i+1})',fontsize=7.5, y=0.95)
            
            if output_keys[j].lower()=='pressure': 
                units='(psia)'
            else: 
                units=''           
            
            ax[i,j].set_ylabel(f'{output_keys[j][0:3]} {units}',fontsize=6)
            if i==len(plot_range)-1:
                ax[i,j].set_xlabel('Timesteps',fontsize=6)
            
            ax[i,j].grid(True,which='major', axis='both', linestyle="--", color='grey',linewidth=0.5)
            ax[i,j].set_xticks(np.linspace(0,len(avg_pred_ldata[plot_range[i]][output_keys[j]]),6))
            if output_keys[j].lower()[0:3]=='pre':
                round_fac=100
            elif output_keys[j].lower()[0:3]=='gas':
                round_fac=0.05
            else:
                round_fac=0.025
                #ax[i,j].set_yticks(np.round_(np.linspace(0.5,1,7),2))

            # Get the min and max values for the plot. The min and max is scaled by a factor 0f 0.9 and 1.10 respectively, then rounded to the nearest 50
            y_min=np.floor((0.9*np.min([np.min(avg_pred_ldata[plot_range[i]][output_keys[j]]),np.min(avg_obs_ldata[plot_range[i]][output_keys[j]])]))/round_fac)*round_fac
            y_max=np.ceil((1.1*np.max([np.max(avg_pred_ldata[plot_range[i]][output_keys[j]]),np.max(avg_obs_ldata[plot_range[i]][output_keys[j]])]))/round_fac)*round_fac
            n_ticks=5
        
            ax[i,j].set_yticks(np.linspace(y_min,y_max,n_ticks))
            
            if j==0:
                ax[i,j].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.0f'))
            elif j==1:
                ax[i,j].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.2f'))
            else:
                ax[i,j].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'))
            
            ax[i,j].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
            ax[i,j].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
            
            #plt.text(0.800, 0.95,f'Number of Perturbations: {no_perturbations}', size=7.0, ha='center', va='center', transform=axes1.transAxes, zorder=100)
    #[ax[len(plot_range)-1,k].legend(loc="lower left",  prop={'size': 8},ncol=1,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -2.25)) for k in range(len(output_keys))] 
    #from matplotlib.legend import _get_legend_handles_labels
 
    plt.show()
    
    return avg_pred_ldata,avg_obs_ldata

def predict_plot_wells(model=None, obs_fdata=None,obs_ldata=None,wells_idx=[(14,14)],shape=(29,29),bound_int=50,output_keys=['Pressure','Gas Saturation','Condensate Saturation'],output_colours=['lightcoral','limegreen','orange'],output_linestyles=['dashed','dotted','dashdot'],no_perturbations=6,plot_range=[0,1,2,3,4,5]):
    def abs_error(x_pred,x_obs):
        return tf.math.abs((x_pred-x_obs)/x_obs)
    full_shape=(no_perturbations,-1,*shape)
    pred_ldata=model.predict(obs_fdata)
    # Un normalize if outputs are normalized prior to training
    if model.cfd_type['Output_Normalization']!=None:
        a=model.cfd_type['Norm_Limits'][0]
        b=model.cfd_type['Norm_Limits'][1]
        ts=pd.DataFrame(model.ts.numpy(),index=model.ts_idx_keys[0],columns=model.ts_idx_keys[1])
        for key in output_keys:
            if model.cfd_type['Output_Normalization']=='linear-scaling':
                 nonorm_pred=((pred_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
                 nonorm_obs=((obs_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
            else:
                nonorm_pred=pred_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
                nonorm_obs=obs_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
            pred_ldata[output_keys.index(key)]=nonorm_pred
            obs_ldata[output_keys.index(key)]=nonorm_obs
    
    nonflat_pred_ldata=np.stack([np.reshape(pred_ldata[i],full_shape) for i in range(len(output_keys))],axis=-1)
    nonflat_obs_ldata=np.stack([np.reshape(obs_ldata[i],full_shape) for i in range(len(output_keys))],axis=-1)
    mae=[]
    # Print output on screen
    print('Pred_Well {}  Obs_Well {}  ==  Pred_Well {}  Obs_Well {}\n'\
          .format(output_keys[0],output_keys[0],output_keys[1],output_keys[1]))
   
    for i in range(np.shape(nonflat_pred_ldata)[0]):
        mae_per_pert={key:[] for key in output_keys}
        for j in range(0,np.shape(nonflat_pred_ldata)[1],int(np.ceil(np.shape(nonflat_pred_ldata)[1]*0.1))):
            for k in wells_idx:
                for kk in range(len(output_keys)):
                    mae_per_pert[output_keys[kk]].append(abs_error(nonflat_pred_ldata[i,j,k[0],k[1],kk],nonflat_obs_ldata[i,j,k[0],k[1],kk]))
                    if kk!=0:
                        print('==',end='')
                    print(nonflat_pred_ldata[i,j,k[0],k[1],kk], ' ', nonflat_obs_ldata[i,j,k[0],k[1],kk], end='')
                print('\r')
        mae.append(mae_per_pert)
        
    for i in range(len(mae)):
        for j in range(len(output_keys)):
            print(f'MAE {output_keys[j]}: {tf.math.reduce_mean(mae[i][output_keys[j]])}\n',end='')
        

    # Plot the predicted and observed averages for all the metrics
        # Create the subplots
    fig, ax = plt.subplots(len(plot_range),len(output_keys))
    fig.subplots_adjust(left=0.02, bottom=0.06, right=0.95, top=0.95, hspace=0.95, wspace=0.4)
    fig.suptitle('Wells '+', '.join(output_keys),fontsize=8,y=1.02,weight='bold')
    
    for i in range(len(plot_range)):
        for k in wells_idx:
            for kk in range(len(output_keys)):
                ax[i,kk].plot(list(nonflat_pred_ldata[i,:,k[0],k[1],kk]), label='Predicted Well '+output_keys[kk], color='#0343DF', linestyle=output_linestyles[kk],linewidth=1.5,zorder=100)      # Color azure
                ax[i,kk].plot(list(nonflat_obs_ldata[i,:,k[0],k[1],kk]), label='Observed Well '+output_keys[kk], linestyle='', marker='s', markerfacecolor=output_colours[kk],markeredgecolor='#A9561E',markersize=4,markeredgewidth=0.75) #CB9978 #A9561E
                
                if i==0:
                    ax[i,kk].set_title(f'Well. {output_keys[kk][0:5]}, Realiz.({i+1})',fontsize=7.5, y=0.95)
                    if j==2:
                        fig.legend(loc="upper left",  prop={'size': 6},ncol=3,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -0.01))  
                else:
                    ax[i,kk].set_title(f'Realiz. ({i+1})',fontsize=7.5, y=0.95)
                
                if output_keys[kk].lower()=='pressure': 
                    units='(psia)'
                else: 
                    units=''           
                
                ax[i,kk].set_ylabel(f'{output_keys[kk][0:3]} {units}',fontsize=6)
                if i==len(plot_range)-1:
                    ax[i,kk].set_xlabel('Timesteps',fontsize=6)
                
                ax[i,kk].grid(True,which='major', axis='both', linestyle="--", color='grey',linewidth=0.5)
                ax[i,kk].set_xticks(np.linspace(0,nonflat_obs_ldata[i,:,k[0],k[1],kk].shape[0],6))
                if output_keys[kk].lower()[0:3]=='pre':
                    round_fac=100
                elif output_keys[kk].lower()[0:3]=='gas':
                    round_fac=0.05
                else:
                    round_fac=0.025
                    #ax[i,kk].set_yticks(np.round_(np.linspace(0.5,1,7),2))
    
                # Get the min and max values for the plot. The min and max is scaled by a factor 0f 0.9 and 1.10 respectively, then rounded to the nearest 50
                y_min=np.floor((0.9*np.min([np.min(nonflat_pred_ldata[i,:,k[0],k[1],kk]),np.min(nonflat_obs_ldata[i,...,k[0],k[1],kk])]))/round_fac)*round_fac
                y_max=np.ceil((1.1*np.max([np.max(nonflat_pred_ldata[i,:,k[0],k[1],kk]),np.max(nonflat_obs_ldata[i,...,k[0],k[1],kk])]))/round_fac)*round_fac
                n_ticks=5
            
                ax[i,kk].set_yticks(np.linspace(y_min,y_max,n_ticks))
                
                if j==0:
                    ax[i,kk].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.0f'))
                elif j==1:
                    ax[i,kk].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.2f'))
                else:
                    ax[i,kk].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'))
                
                ax[i,kk].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
                ax[i,kk].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
                
                #plt.text(0.800, 0.95,f'Number of Perturbations: {no_perturbations}', size=7.0, ha='center', va='center', transform=axes1.transAxes, zorder=100)
        #from matplotlib.legend import _get_legend_handles_labels
    #fig=plt.gcf()
    #size = fig.get_size_inches()
    #[ax[len(plot_range)-1,k].legend(loc="lower left",  prop={'size': 8},ncol=1,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -2.25)) for k in range(len(output_keys))] 
    plt.show()
    
    return nonflat_pred_ldata,nonflat_obs_ldata    
#pred_accuracy = tf.keras.metrics.Accuracy()
#===============================================================================================================================
# Save model weights
from pickle import dump
from pickle import load
import re
def save_model_weights(model,folder_path=None,dname=None,layer_wise=False):
    pattern_1='\,|\['
    pattern_2='\]'
    file_name_wb_best=r'/DNN_Weight_Bias_Best'+re.sub(pattern_2,'',re.sub(pattern_1,'_',str(dname)))
    file_name_wb_full=r'/DNN_Weight_Bias_Full'+re.sub(pattern_2,'',re.sub(pattern_1,'_',str(dname)))
    file_name_history=r'/DNN_History'+re.sub(pattern_2,'',re.sub(pattern_1,'_',str(dname)))
    file_path_wb_best=folder_path+file_name_wb_best+'_'+model.cfd_type['DNN_Type']
    file_path_wb_full=folder_path+file_name_wb_full+'_'+model.cfd_type['DNN_Type']
    file_path_history=folder_path+file_name_history+'_'+model.cfd_type['DNN_Type']
    breakpoint()
    if not layer_wise:
        model_weights_list=model.get_weights()
    else:
        model_weights_list={}
        for ix, layer in enumerate(model.layers):
            if hasattr(model.layers[ix], 'kernel_initializer') and (hasattr(model.layers[ix], 'bias_initializer') or hasattr(model.layers[ix],'recurrent_initializer')) :
                if not layer.name in model_weights_list:
                    model_weights_list[layer.name]=model.layers[ix].get_weights()
                else:
                    model_weights_list[layer.name].update(model.layers[ix].get_weights())
    dump(model_weights_list, open(file_path_wb_best,'wb'))  
    #dump(model.wbl_epoch,open(file_path_wb_full,'wb'))      
    # Add the best ensemble training time (mins) to the dictionary. Useful for later reporting
    model.history_ens[model.best_ens]['train_time']=model.wblt_epoch_ens[model.best_ens]['train_time']/60
    dump(model.history_ens[model.best_ens],open(file_path_history,'wb'))
    return

#save_model_weights(model,save_model_folder_path)      
def load_model_weights(model,folder_path=None,dname=None,layer_wise=False,use_dnn_type=True):
    pattern_1='\,|\['
    pattern_2='\]'    
    if use_dnn_type:
        file_name_wb_best=r'/DNN_Weight_Bias_Best'+re.sub(pattern_2,'',re.sub(pattern_1,'_',str(dname)))
        file_path_wb_best=folder_path+file_name_wb_best+'_'+model.cfd_type['DNN_Type']
    else:
        # load the first file with pattern
        pattern_1='DNN_Weight_Bias_Best'
        for file in os.listdir(folder_path):
            if file.startswith(pattern_1):
                file_path_wb_best=folder_path+f'/{file}'
                break
    model_weights_list = load(open(file_path_wb_best,'rb'))
    if not layer_wise:
        model.set_weights(model_weights_list)
    else:
        for ix, layer in enumerate(model.layers):
            if hasattr(model.layers[ix], 'kernel_initializer') and (hasattr(model.layers[ix], 'bias_initializer') or hasattr(model.layers[ix],'recurrent_initializer')) :
                if not layer.name in model_weights_list:
                    continue
                else:
                    model.layers[ix]=model.layers[ix].set_weights(model_weights_list[layer.name])   
    return 

#===============================================================================================================================================================
def plot_files(folder_path=None,plot_key=['td_loss_p','val_loss'],color=['blue','green','brown','orange',],label=['Without_Regularization','With_Regularization'], use_label=True):
    # Create a list for loading saving the opened file
    # Loop through the folder to get the file
    fig, ax= plt.subplots(1,2,figsize=(8,4),sharey=True)          #gridspec_kw={'height_ratios':height_ratios,'width_ratios':width_ratios,'wspace':0.4}
    fig.subplots_adjust(left=0.01, bottom=0.06, right=0.95, top=0.95, hspace=0.4, wspace=0.2)
    fig.suptitle('Loss (MSE) for Non Physics-Informed Training',fontsize=8,y=1.025,weight='bold')

    pattern_1='DNN_History_'
    axis=plt.gca()
    
    # Define a random colour map
    cmap=plt.cm.get_cmap(name='hsv',lut=10)
    num_colors=8
    import random
    cmap = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
             for i in range(num_colors)]
    
    # Add the default colours
    cmap=color+cmap
    col_idx=0
    train_time_text='Train Time (mins.):'+'\n'
    for file in os.listdir(folder_path):
        if file.startswith(pattern_1):
            # Load file with pickle
            file_path=folder_path+f'/{file}'
            history = load(open(file_path,'rb'))
            #history['train_time']=0.99
            plt_label=re.sub(pattern_1,'',file)
            for key in plot_key:
                ax[plot_key.index(key)].set_title(key,fontsize=8)
                ax[plot_key.index(key)].set_yscale('log')
                ax[plot_key.index(key)].set_ylabel('MSE value')
                ax[plot_key.index(key)].set_xlabel('No. Iterations/Epoch')
                ax[plot_key.index(key)].grid(True)
                if key=='td_loss_p':
                    line_style='solid'
                else:
                    line_style='dashed'
                if use_label:
                    lbl=label[col_idx]
                else:
                    lbl_full='[{}]-{} min'.format(plt_label,'{0:.2f}'.format(history['train_time']))
                    if 'REN'.upper() in lbl_full and 'ADM-MT' in lbl_full: lbl='ResNet: Without Regularization'
                    elif 'REN'.upper() in lbl_full and 'ADW-MT' in lbl_full: lbl='ResNet: With Regularization'
                    elif 'PLN'.upper() in lbl_full and 'ADM-MT' in lbl_full: lbl='FCDNN: Without Regularization'
                    elif 'PLN'.upper() in lbl_full and 'ADW-MT' in lbl_full: lbl='FCDNN: With Regularization'
                ax[plot_key.index(key)].plot(history[key], label=lbl,color=cmap[col_idx],linestyle=line_style)
            train_time_text=train_time_text+str('{0:.2f}'.format(history['train_time']))+'\n'
            #ax1.legend(loc="upper left",  prop={'size': 8},ncol=1,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(1, 1))  
            col_idx+=1
    ax[1].text(0.825, 0.850,train_time_text, size=8.0, ha='center', va='center', transform=axis.transAxes, zorder=100)    
    plt.rc('grid', linestyle="--", color='grey',linewidth=0.5)
    ax[0].legend(loc="lower left",  prop={'size': 8},ncol=2,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -0.25))  
    plt.show()
    return

# Launch tensorboard
# %load_ext tensorboard
# %tensorboard --logdir logs

def rank_losses(losses=[],weights=[],normalization={'Type':'linear-scaling','Limits':[0,1]}):
    # Weights is a two-item list of [train_weights:['DOM','DBC','NBC','IBC','IC'], validation_weight]
    wt_pinn=weights[0][0:5]
    nwt_pinn=wt_pinn/np.linalg.norm(wt_pinn,ord=1)
    wt=np.append(nwt_pinn,weights[1])
    nwt=wt/np.linalg.norm(wt,ord=1)
    
    if len(losses)!=nwt.shape[-1]:
        return print('Error: Check loss outer dimension is not equal to the inner dimension of the weights')
        
    # Create a normalized loss data array
    nloss_array_shape=(len(losses[0]),len(losses))
    norm_losses=np.zeros(nloss_array_shape,dtype=np.float32)
    
    # Define a normalization function
    def norm_func(values_list=None,normalization={'Type':'linear-scaling','Limits':[0,1]} ):
        # Compute statistics
        if normalization['Type']=='linear-scaling':
            a=normalization['Limits'][0]
            b=normalization['Limits'][1]
            values_min=np.min(values_list,axis=0)
            values_max=np.max(values_list,axis=0)
            return [((i-values_min)/(values_max-values_min))*(b-a)+a for i in values_list]
        else:
            values_mean=np.mean(values_list,axis=0)
            values_std=np.std(values_list,axis=0)
            return [(i-values_mean)/values_std for i in values_list]
    
    def rank_list(value_list=None):
        array = np.array(value_list)
        idx_array_sort = array.argsort()
        ranks = np.empty_like(idx_array_sort)
        ranks[idx_array_sort] = np.arange(len(array))  
        return ranks
    
    # Get the number of losses
    for i in range(len(losses)):
        norm_losses[:,i]=rank_list(norm_func(values_list=losses[i],normalization=normalization))
    
    wnorm_losses=np.sum(np.multiply(norm_losses,nwt),axis=1)
    wnorm_losses_rank=rank_list(wnorm_losses)
    idx_minrank=np.where(wnorm_losses_rank==min(wnorm_losses_rank))
    
    return wnorm_losses_rank,idx_minrank

def img_plot(model,obs_fdata=None, obs_ldata=None, tstep_idx=[0,10,20,40,80],shape=(29,29),bound_int=50,plot_title=['Pressure','Gas Saturation','Condensate Saturation'],cmap=[plt.cm.Reds,plt.cm.Greens,plt.cm.Oranges,plt.cm.Blues],no_perturbations=6,timestep=10):
    full_shape=(no_perturbations,-1,*shape)
    max_tstep_idx=int(obs_fdata[0].shape[0]/(shape[0]*shape[1]*no_perturbations))
    
    for val in tstep_idx:
        if int(val) > 100:
            tstep_idx.remove(val)
    tstep_idx=[int(tstep_idx[i]*max_tstep_idx/100.) for i in range(len(tstep_idx))]
    x_mgrid=np.reshape(obs_fdata[0],full_shape)
    y_mgrid=np.reshape(obs_fdata[1],full_shape) 
    extent_ =[[x_mgrid[i].min(), x_mgrid[i].max(), y_mgrid[i].min(), y_mgrid[i].max()] for i in range(x_mgrid.shape[0])]                 
    
    pred_ldata=model.predict(obs_fdata)
    if model.cfd_type['Output_Normalization']!=None:
        a=model.cfd_type['Norm_Limits'][0]
        b=model.cfd_type['Norm_Limits'][1]
        ts=pd.DataFrame(model.ts.numpy(),index=model.ts_idx_keys[0],columns=model.ts_idx_keys[1])
        output_keys=['pressure','sgas']
        for key in output_keys:
            if model.cfd_type['Output_Normalization']=='linear-scaling':
                nonorm_obs=((obs_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
                nonorm_pred=((pred_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
            else:
                nonorm_obs=obs_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
                nonorm_pred=pred_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
            pred_ldata[output_keys.index(key)]=nonorm_pred
            obs_ldata[output_keys.index(key)]=nonorm_obs
    
    pred_ldata_mgrid=[np.reshape(pred_ldata[i],full_shape) for i in range(len(plot_title))]  
    obs_ldata_mgrid=[np.reshape(obs_ldata[i],full_shape) for i in range(len(plot_title))]    
    res_mgrid=[(tf.math.abs((obs_ldata_mgrid[i]-pred_ldata_mgrid[i]))/obs_ldata_mgrid[i])*100 for i in range(len(plot_title))]

    res_min=[tf.constant(0.,dtype=res_mgrid[i].dtype) for i in range(len(plot_title))]
    res_max=[tf.constant(10.,dtype=res_mgrid[i].dtype) for i in range(len(plot_title))]

    # Reshape the predicted data.
    # cmap = mpl.colors.ListedColormap(['yellow','orange','red'])
    # Create the subplots
    import matplotlib.gridspec as gridspec 
    for i in range(no_perturbations):
        
        # z=+/-5% observed value
        #z_min = [1.00*np.min(obs_ldata_mgrid[l][i,0:np.max(tstep_idx),:,:]) for l in range(len(plot_title))]    
        #z_max = [1.00*np.max(obs_ldata_mgrid[l][i,0:np.max(tstep_idx),:,:]) for l in range(len(plot_title))]
        
        for k in range(len(plot_title)):
            height_ratios=[1]*len(tstep_idx); width_ratios=[1]*3
            fig, ax = plt.subplots(len(tstep_idx),3,figsize=(5,7))                  #gridspec_kw={'height_ratios':height_ratios,'width_ratios':width_ratios,'wspace':0.4}
            fig.subplots_adjust(left=0.02, bottom=0.06, right=0.95, top=0.95, hspace=0.4, wspace=0.4)
            fig.suptitle(f'Predicted and Observed {plot_title[k]}; Residual Maps - Realization ({i+1})',fontsize=7,y=1.01,weight='bold')

            for j in range(len(tstep_idx)):
                #res_min=[1.00*np.min(res_mgrid[l][i,tstep_idx[j],:,:]) for l in range(len(plot_title))]
                #res_max=[1.00*np.max(res_mgrid[l][i,tstep_idx[j],:,:]) for l in range(len(plot_title))]

                z_min = [1.00*np.min(obs_ldata_mgrid[l][i,tstep_idx[j],:,:]) for l in range(len(plot_title))]    
                z_max = [1.00*np.max(obs_ldata_mgrid[l][i,tstep_idx[j],:,:]) for l in range(len(plot_title))]
                
                img1=ax[j,0].imshow(pred_ldata_mgrid[k][i,tstep_idx[j],:,:],cmap =cmap[k], vmin = z_min[k], vmax = z_max[k],interpolation='nearest',origin='lower')
                img2=ax[j,1].imshow(obs_ldata_mgrid[k][i,tstep_idx[j],:,:],cmap =cmap[k], vmin = z_min[k], vmax = z_max[k],interpolation='nearest',origin='lower')
                img3=ax[j,2].imshow(res_mgrid[k][i,tstep_idx[j],:,:],cmap =cmap[-1], vmin = res_min[k], vmax = res_max[k],interpolation='nearest',origin='lower')
                
                if j==0:
                    ax[j,0].set_title(f'Pred. {plot_title[k][0:5]} Time={(tstep_idx[j]+1)*timestep} D',fontsize=7,y=0.95)
                    ax[j,1].set_title(f'Obs. {plot_title[k][0:5]} Time={(tstep_idx[j]+1)*timestep} D',fontsize=7,y=0.95)
                    ax[j,2].set_title(f'%Residual. {plot_title[k][0:5]} Time={(tstep_idx[j]+1)*timestep} D',fontsize=7,y=0.95)
                else:
                    ax[j,0].set_title(f'Time={(tstep_idx[j]+1)*timestep} D',fontsize=7,y=0.95)
                    ax[j,1].set_title(f'Time={(tstep_idx[j]+1)*timestep} D',fontsize=7,y=0.95)
                    ax[j,2].set_title(f'Time={(tstep_idx[j]+1)*timestep} D',fontsize=7,y=0.95)
                
                ax[j,0].tick_params(axis='both', which='major', length=2, width=1,labelsize=2)
                ax[j,1].tick_params(axis='both', which='major', length=2, width=1,labelsize=2)
                ax[j,2].tick_params(axis='both', which='major', length=2, width=1,labelsize=2)
                
                divider=[make_axes_locatable(ax[j,l]) for l in range(3)]
                cax = [divider[l].append_axes("right", size="8%", pad=0.05) for l in range(3)]
                
                cax[0].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
                cax[1].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
                cax[2].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
    
                if k==1:
                    cbar_fmt=mpl.ticker.FormatStrFormatter('%.3f')
                else:
                    cbar_fmt=None
                    
                fig.colorbar(img1,cax=cax[0],format=cbar_fmt)
                fig.colorbar(img2,cax=cax[1],format=cbar_fmt)
                fig.colorbar(img3,cax=cax[2],format=cbar_fmt)
            
            plt.show()
    return

def unnormalize_2D(model=None,pred_ldata=None,obs_ldata=None,inputs={'time':None,'phi':None,'permx':None},output_keys=['pressure','gsat','osat']):
    a=model.cfd_type['Norm_Limits'][0]
    b=model.cfd_type['Norm_Limits'][1]
    def_output_keys=['pressure','gsat','osat',]
    ts=pd.DataFrame(model.ts.numpy(),index=model.ts_idx_keys[0],columns=model.ts_idx_keys[1])
    if model.cfd_type['Input_Normalization']!=None:
        if model.cfd_type['Input_Normalization']=='linear-scaling':
            time_=((inputs['time']-a)/float(b-a))*(ts.loc['time','max']-ts.loc['time','min'])+ts.loc['time','min']
            permx_=(ts.loc['permx','max']-ts.loc['permx','min'])*((inputs['permx']-b)/(b-a))+tf.math.log(ts.loc['permx','min'])
            phi_=((inputs['phi']-a)/float(b-a))*(ts.loc['poro','max']-ts.loc['poro','min'])+ts.loc['poro','min']
        elif model.cfd_type['Input_Normalization']=='lnk-linear-scaling':
            time_=((inputs['time']-a)/float(b-a))*(ts.loc['time','max']-ts.loc['time','min'])+ts.loc['time','min']
            permx_=tf.math.exp(tf.math.log(ts.loc['permx','max']/ts.loc['permx','min'])*((inputs['permx']-b)/(b-a))+tf.math.log(ts.loc['permx','min']))
            phi_=((inputs['phi']-a)/float(b-a))*(ts.loc['poro','max']-ts.loc['poro','min'])+ts.loc['poro','min']
        elif model.cfd_type['Input_Normalization']=='z-score':
            time_=inputs['time']*ts.loc['time','std']+ts.loc['time','mean']
            permx_=tf.math.exp(inputs['permx']*ts.loc['poro','std']+ts.loc['poro','mean'])
            phi_=inputs['phi']*ts.loc['poro','std']+ts.loc['poro','mean']
    else:
        time_=inputs['time']
        phi_=inputs['phi']
        permx_=inputs['permx']
    
    if model.cfd_type['Output_Normalization']!=None:
        pred_ldata_=[]
        obs_ldata_=[]
        for key in def_output_keys[:len(output_keys)]:
            if model.cfd_type['Output_Normalization']=='linear-scaling':
                 nonorm_pred=((pred_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
                 nonorm_obs=((obs_ldata[output_keys.index(key)]-a)/float(b-a))*((ts.loc[key,'max'])-(ts.loc[key,'min']))+(ts.loc[key,'min'])
            else:
                nonorm_pred=pred_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
                nonorm_obs=obs_ldata[output_keys.index(key)]*ts.loc[key,'std']+ts.loc[key,'mean']
            pred_ldata_.append(nonorm_pred)
            obs_ldata_.append(nonorm_obs)
    else:
        pred_ldata_=pred_ldata
        obs_ldata_=obs_ldata
    return pred_ldata_,obs_ldata_,time_,phi_,permx_

def nonormalize(model,norm_input,stat_idx=0,compute=False):
    # Train statistics tensor: INDEX: {'x_coord', 'y_coord', 'z_coord', 'time', 'poro', 'permx', 'permz', 'grate',...}
    #                           KEYS: {'min', 'max', 'mean', 'std', 'count'}
    #                           Nonnormalized function: Linear scaling (a,b)= (xmax-xmin)*((x_norm-a)/(b-a))+xmin
    #                           Nonnormalized function: z-score= (x_norm*xstd)+xmean
    def _lnk_linear_scaling():
        lin_scale_no_log=(model.ts[stat_idx,1]-model.ts[stat_idx,0])*((norm_input-model.cfd_type['Norm_Limits'][0])/(model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0]))+model.ts[stat_idx,0]
        lin_scale_log=tf.math.exp(tf.math.log(model.ts[stat_idx,1]/model.ts[stat_idx,0])*((norm_input-model.cfd_type['Norm_Limits'][0])/(model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0]))+tf.math.log(model.ts[stat_idx,0]))

        return tf.cond(tf.logical_or(tf.math.not_equal(stat_idx,5),tf.math.not_equal(stat_idx,6)),lambda: lin_scale_no_log, lambda: lin_scale_log)
    
    def _linear_scaling():
        return (model.ts[stat_idx,1]-model.ts[stat_idx,0])*((norm_input-model.cfd_type['Norm_Limits'][0])/(model.cfd_type['Norm_Limits'][1]-model.cfd_type['Norm_Limits'][0]))+model.ts[stat_idx,0]
    
    def _z_score():
        return (norm_input*model.ts[stat_idx,3])+model.ts[stat_idx,2]
    
    nonorm=tf.cond(tf.math.equal(compute,True),lambda: tf.cond(tf.math.equal(model.cfd_type['Input_Normalization'],'linear-scaling'),lambda: _linear_scaling(),lambda: tf.cond(tf.math.equal(model.cfd_type['Input_Normalization'],'lnk-linear-scaling'),lambda: _lnk_linear_scaling,lambda: _z_score())),lambda: norm_input)
    
    # Dropsout the derivative in an event of a nan number--when the min and max statistics are constant or standard deviation is zero
    nonorm=tf.where(tf.logical_or(tf.math.is_nan(nonorm), tf.math.is_inf(nonorm)),tf.zeros_like(nonorm), nonorm)
    return nonorm


def predict_plot_avgout_2D(model=None, BG_test=None,output_keys=['Pressure','Gas Saturation','Condensate Saturation'],output_colours=['lightcoral','limegreen','orange'],output_linestyles=['dashed','dotted','dashdot'],no_perturbations=6,perm=[],xy_label_size=7.5):
    def abs_error(x_pred,x_obs):
        return tf.math.abs((x_pred-x_obs)/x_obs)

    nonflat_pred_ldata=[model(BG_test[i][0]) for i in range(len(BG_test))]                      # Predicts for the entire prediction range
    nonflat_obs_ldata=[[BG_test[i][1][j] for j in range(len(output_keys))] for i in range(len(BG_test))]
    
    # Using the weighted volume to determine the average pressure, gas and condensate saturations
    # Porosity is index index 4
    nonflat_time=[BG_test[i][0][3] for i in range(len(BG_test))]
    nonflat_phi=[BG_test[i][0][4] for i in range(len(BG_test))]
    nonflat_permx=[BG_test[i][0][5] for i in range(len(BG_test))]

    # Un normalize if outputs are normalized prior to training
    
    for i in range(len(nonflat_pred_ldata)):
        nonflat_pred_ldata[i],nonflat_obs_ldata[i],nonflat_time[i],nonflat_phi[i],nonflat_permx[i]=unnormalize_2D(model,nonflat_pred_ldata[i],nonflat_obs_ldata[i],inputs={'time':nonflat_time[i],'phi':nonflat_phi[i],'permx':nonflat_permx[i]},)                
    
    avg_pred_ldata=[]
    avg_obs_ldata=[]
    mae=[]

    for i in range(len(nonflat_pred_ldata)):
        avg_pred_ldata_per_key=[]
        avg_obs_ldata_per_key=[]
        mae_per_key=[]
        for j in range(len(output_keys)):
            avg_pred_ldata_per_tstep=[]
            avg_obs_ldata_per_tstep=[]
            mae_per_tstep=[]
            for k in range(nonflat_pred_ldata[0][0].shape[0]):
                # Volumetric weighted average
                avg_pred=np.sum(nonflat_pred_ldata[i][j][k]*nonflat_phi[i][k])/np.sum(nonflat_phi[i][k])
                avg_obs=np.sum(nonflat_obs_ldata[i][j][k]*nonflat_phi[i][k])/np.sum(nonflat_phi[i][k])
                avg_pred_ldata_per_tstep.append(avg_pred)
                avg_obs_ldata_per_tstep.append(avg_obs)
                mae_per_tstep.append(abs_error(avg_pred,avg_obs))
            avg_pred_ldata_per_key.append(avg_pred_ldata_per_tstep)  
            avg_obs_ldata_per_key.append(avg_obs_ldata_per_tstep)
            mae_per_key.append(mae_per_tstep)
        avg_pred_ldata.append(avg_pred_ldata_per_key)
        avg_obs_ldata.append(avg_obs_ldata_per_key)
        mae.append(mae_per_key)
        
    # Print output on screen
    for i in range(len(output_keys)):
        if i<len(output_keys)-1:
            print('Pred_Avg {}  == Obs_Avg {} ||'.format(output_keys[i],output_keys[i]),end=' ')
        else:
            print('Pred_Avg {}  == Obs_Avg {}'.format(output_keys[i],output_keys[i]))

    for i in range(len(avg_pred_ldata)):
        for j in range(0,len(avg_pred_ldata[i][0]),5):
            for k in range(len(output_keys)):
                if k<len(output_keys)-1:
                    print('{}  {} == '.format(avg_pred_ldata[i][k][j],avg_obs_ldata[i][k][j]),end=' ' )   
                else:
                    print('{}  {}'.format(avg_pred_ldata[i][k][j],avg_obs_ldata[i][k][j]),end='\n' )
    
    for i in range(len(output_keys)):
        print('MAE {}  == {} '.format(output_keys[i],tf.math.reduce_mean(mae,axis=[0,2])[i]),end='\n\n')
    #print(f'MAE {output_keys[0]}: {tf.math.reduce_mean(mae,axis=[0,2])[0]}\nMAE {output_keys[1]}: {tf.math.reduce_mean(mae,axis=[0,2])[1]}\nMAE {output_keys[2]}: {tf.math.reduce_mean(mae,axis=[0,2])[2]}')

    # reduce the time axis
    nonflat_time=np.mean(nonflat_time,axis=(2,3,4))

    # Plot the predicted and observed averages for all the metrics
        # Create the subplots
    fig, ax = plt.subplots(len(avg_obs_ldata),len(output_keys))
    if ax.ndim==1:
        # Reshape the axis to a two dimensional array
        ax=np.reshape(ax,(len(avg_obs_ldata),len(output_keys)))
    fig.subplots_adjust(left=0.02, bottom=0.06, right=0.95, top=0.95, hspace=0.5, wspace=0.3)
    fig.suptitle('Average '+' '.join(output_keys),fontsize=8,y=1.02,weight='bold')
    
    for i in range(len(avg_pred_ldata)):   # Realizations
        for j in range(len(output_keys)):
            ax[i,j].plot(list(nonflat_time[i]),avg_pred_ldata[i][j], label='Average predicted '+output_keys[j], color='#0343DF', linestyle=output_linestyles[j],linewidth=1.0,zorder=100)      # Color azure
            ax[i,j].plot(list(nonflat_time[i]),avg_obs_ldata[i][j], label='Average observed '+output_keys[j], linestyle='', marker='s', markerfacecolor=output_colours[j],markeredgecolor='#A9561E',markersize=4) 
            
            if i==0:
                ax[i,j].set_title(f'Avg. {output_keys[j][0:5]}, Realiz.({i+1}), kavg={perm[i]} mD',fontsize=8.0, y=0.95)
                if j==len(output_keys)-1:
                    fig.legend(loc="upper left",  prop={'size': xy_label_size},ncol=3,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -0.015))  
            else:
                ax[i,j].set_title(f'Realiz. ({i+1}), kavg={perm[i]} mD',fontsize=8.0, y=0.95)
            
            if output_keys[j].lower()=='pressure': 
                units='(psia)'
            else: 
                units=''           
            
            ax[i,j].set_ylabel(f'{output_keys[j][0:3]} {units}',fontsize=xy_label_size)
            if i==len(avg_pred_ldata)-1:
                ax[i,j].set_xlabel('Time (Days)',fontsize=xy_label_size)
            
            ax[i,j].grid(True,which='major', axis='both', linestyle="--", color='grey',linewidth=0.5)
            #ax[i,j].set_xticks(np.linspace(0,len(avg_pred_ldata[i][j]),6))
            if output_keys[j].lower()[0:3]=='pre':
                ax[i,j].set_yticks(np.round_(np.linspace(int(min(avg_obs_ldata[i][j])/model.cfd_type['Min_BHP'])*model.cfd_type['Min_BHP'],model.cfd_type['Pi'],5),))
            if output_keys[j].lower()[0:3]=='gas':
                ax[i,j].set_yticks(np.round_(np.linspace(0.5,1,7),2))
            if j==2:
                ax[i,j].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'))
            
            ax[i,j].tick_params(axis='both', which='major', length=2, width=1,labelsize=(0.8*xy_label_size))
            ax[i,j].tick_params(axis='both', which='major', length=2, width=1,labelsize=(0.8*xy_label_size))
            
            #plt.text(0.800, 0.95,f'Number of Perturbations: {no_perturbations}', size=7.0, ha='center', va='center', transform=axes1.transAxes, zorder=100)
    #from matplotlib.legend import _get_legend_handles_labels
 
    plt.show()
    
    return avg_pred_ldata,avg_obs_ldata,mae

def img_plot_2D(model=None, BG_test=None, tstep_idx=[0,20,40,60],bound_int=50,plot_title=['Pressure','Gas Saturation','Condensate Saturation'],cmap=[plt.cm.Reds,plt.cm.Greens,plt.cm.Oranges,plt.cm.Blues],no_perturbations=6,max_error=5.,timestep=[0,10],perm=[],xy_label_size=7.):
    # Check that tstep_idx exists
    for val in tstep_idx:
        if int(val) > 100:
            tstep_idx.remove(val)
    
    
    tstep_idx=[int(tf.math.ceil(tstep_idx[i]*(len(BG_test[0][0][0]))/100.))for i in range(len(tstep_idx[:len(BG_test[0][0][0])]))]

    x_mgrid=[BG_test[i][0][0] for i in range(len(BG_test))]                      
    y_mgrid=[BG_test[i][0][1] for i in range(len(BG_test))] 
    extent_ =[[x_mgrid[i].min(), x_mgrid[i].max(), y_mgrid[i].min(), y_mgrid[i].max()] for i in range(len(BG_test))]                 

    nonflat_pred_ldata=np.array([model(BG_test[i][0])[0:len(plot_title)] for i in range(len(BG_test))])                     # Predicts for the entire prediction range
    nonflat_obs_ldata=np.array([[BG_test[i][1][j] for j in range(len(plot_title))] for i in range(len(BG_test))])

    res_mgrid=(tf.math.abs((nonflat_obs_ldata-nonflat_pred_ldata))/nonflat_obs_ldata)*100

    res_min=[tf.constant(0.,dtype=res_mgrid[i].dtype) for i in range(len(plot_title))]
    res_max=[tf.constant(max_error,dtype=res_mgrid[i].dtype) for i in range(len(plot_title))]

    nonflat_time=[BG_test[i][0][3] for i in range(len(BG_test))]
    nonflat_phi=[BG_test[i][0][4] for i in range(len(BG_test))]
    nonflat_permx=[BG_test[i][0][5] for i in range(len(BG_test))]
    
    # Un normalize if outputs are normalized prior to training
    for i in range(len(nonflat_pred_ldata)):
        nonflat_pred_ldata[i],nonflat_obs_ldata[i],_,_,_=unnormalize_2D(model,nonflat_pred_ldata[i],nonflat_obs_ldata[i],inputs={'time':nonflat_time[i],'phi':nonflat_phi[i],'permx':nonflat_permx[i]},output_keys=plot_title)                
    
    # Reshape the predicted data.
    # cmap = mpl.colors.ListedColormap(['yellow','orange','red'])
    # Create the subplots
    for i in range(len(BG_test)):  #Indicates the Realizations

        # z=+/-5% observed value
        # z_min = [np.min(nonflat_obs_ldata[i][l][0:np.max(tstep_idx),...]) for l in range(len(plot_title))]
        # z_max = [np.max(nonflat_obs_ldata[i][l][0:np.max(tstep_idx),...]) for l in range(len(plot_title))]

        for k in range(len(plot_title)):
            height_ratios=[1]*len(tstep_idx); width_ratios=[1]*3
            fig, ax = plt.subplots(len(tstep_idx),3,figsize=(5,7))                  #gridspec_kw={'height_ratios':height_ratios,'width_ratios':width_ratios,'wspace':0.4}
            fig.subplots_adjust(left=0.02, bottom=0.06, right=0.95, top=0.95, hspace=0.4, wspace=0.4)
            fig.suptitle(f'Predicted and Observed {plot_title[k]}; Residual Maps - Realization ({i+1}), kavg={perm[i]} mD',fontsize=xy_label_size,y=1.01,weight='bold')

            for j in range(len(tstep_idx)):
                
                z_min = [1.00*np.min(nonflat_obs_ldata[i][l][tstep_idx[j],...]) for l in range(len(plot_title))]    
                z_max = [1.00*np.max(nonflat_obs_ldata[i][l][tstep_idx[j],...]) for l in range(len(plot_title))]
                
                img1=ax[j,0].imshow(nonflat_pred_ldata[i][k][tstep_idx[j],...],cmap =cmap[k], vmin = z_min[k], vmax = z_max[k],interpolation='nearest',origin='lower')
                img2=ax[j,1].imshow(nonflat_obs_ldata[i][k][tstep_idx[j],...],cmap =cmap[k], vmin = z_min[k], vmax = z_max[k],interpolation='nearest',origin='lower')
                img3=ax[j,2].imshow(res_mgrid[i][k][tstep_idx[j],...],cmap =cmap[-1], vmin = res_min[k], vmax = res_max[k],interpolation='nearest',origin='lower')

          
                if j==0:
                    ax[j,0].set_title(f'Pred. {plot_title[k][0:5]} Time={timestep[0]+(tstep_idx[j])*timestep[1]} D',fontsize=7,y=0.95)
                    ax[j,1].set_title(f'Obs. {plot_title[k][0:5]} Time={timestep[0]+(tstep_idx[j])*timestep[1]} D',fontsize=7,y=0.95)
                    ax[j,2].set_title(f'%Residual. {plot_title[k][0:5]} Time={timestep[0]+(tstep_idx[j])*timestep[1]} D',fontsize=7,y=0.95)
                else:
                    ax[j,0].set_title(f'Time={timestep[0]+(tstep_idx[j])*timestep[1]} D',fontsize=7,y=0.95)
                    ax[j,1].set_title(f'Time={timestep[0]+(tstep_idx[j])*timestep[1]} D',fontsize=7,y=0.95)
                    ax[j,2].set_title(f'Time={timestep[0]+(tstep_idx[j])*timestep[1]} D',fontsize=7,y=0.95)
                
                ax[j,0].tick_params(axis='both', which='major', length=2, width=1,labelsize=2)
                ax[j,1].tick_params(axis='both', which='major', length=2, width=1,labelsize=2)
                ax[j,2].tick_params(axis='both', which='major', length=2, width=1,labelsize=2)
                
                divider=[make_axes_locatable(ax[j,l]) for l in range(3)]
                cax = [divider[l].append_axes("right", size="8%", pad=0.05) for l in range(3)]
                
                cax[0].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
                cax[1].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
                cax[2].tick_params(axis='both', which='major', length=2, width=1,labelsize=7)
    
                if k==1:
                    cbar_fmt=mpl.ticker.FormatStrFormatter('%.3f')
                else:
                    cbar_fmt=None
                    
                fig.colorbar(img1,cax=cax[0],format=cbar_fmt)
                fig.colorbar(img2,cax=cax[1],format=cbar_fmt)
                fig.colorbar(img3,cax=cax[2],format=cbar_fmt)
            
            plt.show()           
    return

#_,_,_=predict_range_score(model, obs_fdata=test_dom_fdata_list, obs_ldata=test_dom_ldata_list)
#avg_pred_ldata,avg_obs_ldata=predict_plot_avgout(model, obs_fdata=test_dom_fdata_list,obs_ldata=test_dom_ldata_list,no_perturbations=no_pert_model)
#img_plot(obs_fdata=test_dom_fdata_list,obs_ldata=test_dom_ldata_list, cum_tstep=0)   
   
# Test Times (0.5 frac.):
# 0 = 45 days
# 5 = 165 days
# 10 = 300 days
# 15 = 435 days
# 20 = 585 days
# 30 = 915 days
# 40 = 1320 days

#[0,5,40,80]; [86,91,126,166];[172,177,212,252];[258,263,298,338];[344,349,384,424];[430,435,478,510]
def predict_plot_wells_2D(model=None, BG_test=None, tstep=10,tstep_idx=[0,20,40,60,80],bound_int=50,wells_idx=[(14,14,0)],plot_title=['Pressure','Gas Saturation','Condensate Saturation'],output_colours=['lightcoral','limegreen','orange'],output_linestyles=['dashed','dotted','dashdot'],no_perturbations=6,perm=[],xy_label_size=7.5):
    # Check that tstep_idx exists
    for val in tstep_idx:
        if int(val) > 100:
            tstep_idx.remove(val)
  
    tstep_idx=[int(tstep_idx[i]*(len(BG_test[0][0][0]))/100.) for i in range(len(tstep_idx))]
    x_mgrid=[BG_test[i][0][0] for i in range(len(BG_test))]                      
    y_mgrid=[BG_test[i][0][1] for i in range(len(BG_test))] 
    extent_ =[[x_mgrid[i].min(), x_mgrid[i].max(), y_mgrid[i].min(), y_mgrid[i].max()] for i in range(len(BG_test))]                 

    nonflat_pred_ldata=np.array([model(BG_test[i][0])[0:len(plot_title)] for i in range(len(BG_test))])                     # Predicts for the entire prediction range
    nonflat_obs_ldata=np.array([[BG_test[i][1][j] for j in range(len(plot_title))] for i in range(len(BG_test))])
    
    nonflat_time=[BG_test[i][0][3] for i in range(len(BG_test))]
    nonflat_phi=[BG_test[i][0][4] for i in range(len(BG_test))]
    nonflat_permx=[BG_test[i][0][5] for i in range(len(BG_test))]

    # Un normalize if outputs are normalized prior to training
    for i in range(len(nonflat_pred_ldata)):
        nonflat_pred_ldata[i],nonflat_obs_ldata[i],nonflat_time[i],nonflat_phi[i],nonflat_permx[i]=unnormalize_2D(model,nonflat_pred_ldata[i],nonflat_obs_ldata[i],inputs={'time':nonflat_time[i],'phi':nonflat_phi[i],'permx':nonflat_permx[i]},output_keys=plot_title)                
    
    well_pred_ldata=[]
    well_obs_ldata=[]
    mae=[]

    def abs_error(x_pred,x_obs):
        return tf.math.abs((x_pred-x_obs)/x_obs)

    # Compute the BHP if requested
    for i in range(len(nonflat_pred_ldata)):        # Perturbation
        well_pred_ldata_per_key=[]
        well_obs_ldata_per_key=[]
        mae_per_key=[]
        for j in wells_idx:                        # Wells Connection Index  
            well_pred_ldata_per_wellidx=[]
            well_obs_ldata_per_wellidx=[]
            mae_per_wellidx=[]
            for k in range(nonflat_pred_ldata[0][0].shape[0]): # Timestep
                well_pred_ldata_per_tstep=[]
                well_obs_ldata_per_tstep=[]
                mae_per_tstep=[]
                for kk in range(len(plot_title)):    # Plot Title
                    # Volumetric weighted average
                    well_pred=nonflat_pred_ldata[i][kk][k,j[0],j[1],j[2]]
                    well_obs=nonflat_obs_ldata[i][kk][k,j[0],j[1],j[2]]
                    well_pred_ldata_per_tstep.append(well_pred)
                    well_obs_ldata_per_tstep.append(well_obs)
                    mae_per_tstep.append(abs_error(well_pred,well_obs))
                well_pred_ldata_per_wellidx.append(well_pred_ldata_per_tstep)  
                well_obs_ldata_per_wellidx.append(well_obs_ldata_per_tstep)
                mae_per_wellidx.append(mae_per_tstep)
            well_pred_ldata_per_key.append(well_pred_ldata_per_wellidx)  
            well_obs_ldata_per_key.append(well_obs_ldata_per_wellidx)
            mae_per_key.append(mae_per_wellidx)
        well_pred_ldata.append(well_pred_ldata_per_key)
        well_obs_ldata.append(well_obs_ldata_per_key)
        mae.append(mae_per_key)


    # Print output on screen
    for i in range(nonflat_pred_ldata.shape[0]):  #Perturbation
        print('Realization_*',i+1)
        for j in range(len(wells_idx)):
            for k in tstep_idx:
                for kk in range(len(plot_title)):
                    if tstep_idx.index(k)==0:
                        if kk<len(plot_title)-1:
                            print('Pred_Well_{} {}  == Obs_Avg_{} {} ||'.format(str(wells_idx[j]),plot_title[kk],str(wells_idx[j]),plot_title[kk]),end=' ')
                        else:
                            print('Pred_Well_{} {}  == Obs_Avg_{} {}'.format(str(wells_idx[j]),plot_title[kk],str(wells_idx[j]),plot_title[kk]))

                    if kk<len(plot_title)-1:
                        print('{}  {} == '.format(well_pred_ldata[i][j][k][kk],well_obs_ldata[i][j][k][kk]),end=' ')
                    else:
                        print('{} {}'.format(well_pred_ldata[i][j][k][kk],well_obs_ldata[i][j][k][kk]))
            print('\n')
        
            # Print the average at each realization 
            print('MAE for Realization_*',i+1)
            for jk in range(len(plot_title)):
                print('MAE {}  == {} '.format(plot_title[jk],tf.math.reduce_mean(mae[i],axis=[1])[j][jk]))
        
        print('\n')

    # Split the realizations in blocks subplots of five to allow viewing to scale
    rdiv=5
    rs=int(len(BG_test)/rdiv)*[rdiv]+[len(BG_test)%rdiv]
    

    # reduce the time axis
    nonflat_time=np.mean(nonflat_time,axis=(2,3,4))

    for j in wells_idx:
        for r in rs:
            # Create the subplots
            fig, ax = plt.subplots(r,len(plot_title))
            if ax.ndim==1:
                # Reshape the axis to a two dimensional array
                ax=np.reshape(ax,(r,len(plot_title)))
            fig.subplots_adjust(left=0.02, bottom=0.06, right=0.95, top=0.95, hspace=0.5, wspace=0.4)
            fig.suptitle('Wells Grid Block '+', '.join(plot_title),fontsize=8,y=1.02,weight='bold')    

            for i in range(r):
                for kk in range(len(plot_title)):
                    # Get the realization index 
                    ri=rdiv*rs.index(r)+i
                    
                    # Remove any zero value from the observed data--this could occurs due to sparse sampling of the simulated data
                    x_obs=list(np.compress(nonflat_obs_ldata[ri][kk][:,j[0],j[1],j[2]]>0.,nonflat_time[ri]))
                    y_obs=list(np.compress(nonflat_obs_ldata[ri][kk][:,j[0],j[1],j[2]]>0.,nonflat_obs_ldata[ri][kk][:,j[0],j[1],j[2]]))
                    
                    ax[i,kk].plot(list(nonflat_time[ri]),list(nonflat_pred_ldata[ri][kk][:,j[0],j[1],j[2]]), label='Predicted Well '+plot_title[kk], color='#0343DF', linestyle=output_linestyles[kk],linewidth=1.5,zorder=100)      # Color azure
                    ax[i,kk].plot(x_obs,y_obs, label='Observed Well '+plot_title[kk], linestyle='', marker='s', markerfacecolor=output_colours[kk],markeredgecolor='#A9561E',markersize=4,markeredgewidth=0.75) #CB9978 #A9561E
                    
                    if i==0:
                        ax[i,kk].set_title(f'Well Grid Block {plot_title[kk][0:5]}, Realiz.({ri}), kavg={perm[i]} mD',fontsize=xy_label_size, y=0.95)
                        if kk==len(plot_title)-1:
                            fig.legend(loc="upper left",  prop={'size': xy_label_size},ncol=3,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -0.02))  
                    else:
                        ax[i,kk].set_title(f'Realiz. ({ri}), kavg={perm[i]} mD',fontsize=xy_label_size, y=0.95)
                    
                    if plot_title[kk].lower()=='pressure': 
                        units='(psia)'
                    else: 
                        units=''           
                    
                    ax[i,kk].set_ylabel(f'{plot_title[kk][0:3]} {units}',fontsize=xy_label_size)
                    if i==r-1:
                        ax[i,kk].set_xlabel('Time (Days)',fontsize=xy_label_size)
                    
                    ax[i,kk].grid(True,which='major', axis='both', linestyle="--", color='grey',linewidth=0.5)
                    #ax[i,kk].set_xticks(np.linspace(0,nonflat_obs_ldata[ri][kk].shape[0],6))
                    if plot_title[kk].lower()[0:3]=='pre':
                        round_fac=100
                    elif plot_title[kk].lower()[0:3] in ['gsat','gas']:
                        round_fac=0.05
                    else:
                        round_fac=0.025
                        #ax[i,kk].set_yticks(np.round_(np.linspace(0.5,1,7),2))
                    
                    y_obs_range=np.compress(nonflat_obs_ldata[:,kk,:,j[0],j[1],j[2]].flatten()>0.,nonflat_obs_ldata[:,kk,:,j[0],j[1],j[2]].flatten())
                    
                    # Get the min and max values for the plot. The min and max is scaled by a factor 0f 0.9 and 1.10 respectively, then rounded to the nearest 50
                    y_min=np.floor((0.9*np.min([np.min(nonflat_pred_ldata[:,kk,:,j[0],j[1],j[2]]),np.min(y_obs_range)]))/round_fac)*round_fac
                    y_max=np.ceil((1.1*np.max([np.max(nonflat_pred_ldata[:,kk,:,j[0],j[1],j[2]]),np.max(y_obs_range)]))/round_fac)*round_fac
                    n_ticks=5
                
                    ax[i,kk].set_yticks(np.linspace(y_min,y_max,n_ticks))
                    
                    ax[i,kk].xaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.0f'))
                    if kk==0:
                        ax[i,kk].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.0f'))
                    elif kk==1:
                        ax[i,kk].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.2f'))
                    else:
                        ax[i,kk].yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'))
                    
                    ax[i,kk].tick_params(axis='both', which='major', length=2, width=1,labelsize=(0.8*xy_label_size))
                    ax[i,kk].tick_params(axis='both', which='major', length=2, width=1,labelsize=(0.8*xy_label_size))
                   
                    #plt.text(0.800, 0.95,f'Number of Perturbations: {no_perturbations}', size=7.0, ha='center', va='center', transform=axes1.transAxes, zorder=100)
                    #from matplotlib.legend import _get_legend_handles_labels
            #fig=plt.gcf()
            #size = fig.get_size_inches()
            #[ax[len(plot_range)-1,k].legend(loc="lower left",  prop={'size': 8},ncol=1,handleheight=1, handlelength=1,labelspacing=0.05,bbox_to_anchor=(0, -2.25)) for k in range(len(output_keys))] 
            plt.show()
    
    return well_pred_ldata,well_obs_ldata,mae
        


